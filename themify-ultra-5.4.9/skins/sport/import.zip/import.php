<?php

function themify_do_demo_import() {
$term = array (
  'term_id' => 16,
  'name' => 'Tips',
  'slug' => 'tips',
  'term_group' => 0,
  'taxonomy' => 'category',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 17,
  'name' => 'News',
  'slug' => 'news',
  'term_group' => 0,
  'taxonomy' => 'category',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 18,
  'name' => 'Fans Club',
  'slug' => 'fans-club',
  'term_group' => 0,
  'taxonomy' => 'category',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 19,
  'name' => 'Main Navigation',
  'slug' => 'main-navigation',
  'term_group' => 0,
  'taxonomy' => 'nav_menu',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 20,
  'name' => 'My Account Menu',
  'slug' => 'my-account-menu',
  'term_group' => 0,
  'taxonomy' => 'nav_menu',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 2,
  'name' => 'simple',
  'slug' => 'simple',
  'term_group' => 0,
  'taxonomy' => 'product_type',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 21,
  'name' => 'Skateboard',
  'slug' => 'skateboard',
  'term_group' => 0,
  'taxonomy' => 'product_cat',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$post = array (
  'ID' => 10,
  'post_date' => '2018-05-11 15:38:35',
  'post_date_gmt' => '2018-05-11 15:38:35',
  'post_content' => 'Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus. At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates.

Magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?” repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis.',
  'post_title' => 'Safe and Best Practice Tips From the Pros',
  'post_excerpt' => '',
  'post_name' => 'safe-and-best-practice-tips-from-the-pros',
  'post_modified' => '2021-04-03 15:33:54',
  'post_modified_gmt' => '2021-04-03 15:33:54',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-sport/?p=44',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"cols\\":[{\\"grid_class\\":\\"col-full\\",\\"element_id\\":\\"7gi1500\\"}],\\"element_id\\":\\"kaki428\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'category' => 'tips',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-sport/files/2021/03/skate-park.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 11,
  'post_date' => '2018-05-10 15:19:35',
  'post_date_gmt' => '2018-05-10 15:19:35',
  'post_content' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur.

inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur.',
  'post_title' => 'Ready For The New Tricks',
  'post_excerpt' => '',
  'post_name' => 'ready-for-the-new-tricks',
  'post_modified' => '2021-04-03 15:33:54',
  'post_modified_gmt' => '2021-04-03 15:33:54',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-sport/?p=11',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"cols\\":[{\\"grid_class\\":\\"col-full\\",\\"element_id\\":\\"zqvp707\\"}],\\"element_id\\":\\"74a5006\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'category' => 'fans-club',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-sport/files/2021/03/skating.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 12,
  'post_date' => '2018-05-09 15:26:47',
  'post_date_gmt' => '2018-05-09 15:26:47',
  'post_content' => 'Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus. Et quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus omnis.

At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.',
  'post_title' => 'How to be a Professional Skateboarder',
  'post_excerpt' => '',
  'post_name' => 'how-to-be-a-professional-skateboarder',
  'post_modified' => '2021-03-30 18:48:02',
  'post_modified_gmt' => '2021-03-30 18:48:02',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-sport/?p=33',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"cols\\":[{\\"grid_class\\":\\"col-full\\",\\"element_id\\":\\"w5g7060\\"}],\\"element_id\\":\\"23w7660\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'category' => 'tips',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-sport/files/2021/03/sunset-skate.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 13,
  'post_date' => '2018-05-08 15:22:05',
  'post_date_gmt' => '2018-05-08 15:22:05',
  'post_content' => 'Ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.

Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.

Laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit ess. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.',
  'post_title' => 'Pro Skater',
  'post_excerpt' => '',
  'post_name' => 'pro-skater',
  'post_modified' => '2021-04-03 15:33:54',
  'post_modified_gmt' => '2021-04-03 15:33:54',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-sport/?p=26',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"cols\\":[{\\"grid_class\\":\\"col-full\\",\\"element_id\\":\\"rcwr989\\"}],\\"element_id\\":\\"2ybo077\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'category' => 'fans-club',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-sport/files/2021/03/pro-skater.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 14,
  'post_date' => '2018-05-07 15:23:33',
  'post_date_gmt' => '2018-05-07 15:23:33',
  'post_content' => 'Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat epellendus.  Ton provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae.

<span id="more-133"></span>Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.

Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur? Vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate',
  'post_title' => 'Waiting For Friends',
  'post_excerpt' => '',
  'post_name' => 'waiting-for-friends',
  'post_modified' => '2021-04-03 15:33:54',
  'post_modified_gmt' => '2021-04-03 15:33:54',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-sport/?p=28',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"cols\\":[{\\"grid_class\\":\\"col-full\\",\\"element_id\\":\\"l8o4360\\"}],\\"element_id\\":\\"m3bk444\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'category' => 'news',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-sport/files/2021/03/girl-with-skateboard.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 15,
  'post_date' => '2018-05-06 15:25:21',
  'post_date_gmt' => '2018-05-06 15:25:21',
  'post_content' => 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est. Laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur.

Perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.',
  'post_title' => 'My New Trick',
  'post_excerpt' => '',
  'post_name' => 'my-new-trick',
  'post_modified' => '2021-03-30 18:48:09',
  'post_modified_gmt' => '2021-03-30 18:48:09',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-sport/?p=31',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"cols\\":[{\\"grid_class\\":\\"col-full\\",\\"element_id\\":\\"svd4041\\"}],\\"element_id\\":\\"v95j331\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'category' => 'tips',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-sport/files/2021/03/pro-skater-2.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 16,
  'post_date' => '2018-05-02 15:30:11',
  'post_date_gmt' => '2018-05-02 15:30:11',
  'post_content' => 'Totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur.

Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur. Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae.',
  'post_title' => 'Riding My New Skateboard',
  'post_excerpt' => '',
  'post_name' => 'riding-my-new-skateboard',
  'post_modified' => '2021-04-03 15:33:54',
  'post_modified_gmt' => '2021-04-03 15:33:54',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-sport/?p=36',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"cols\\":[{\\"grid_class\\":\\"col-full\\",\\"element_id\\":\\"7kmh656\\"}],\\"element_id\\":\\"94sl088\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'category' => 'news',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-sport/files/2021/03/skate-zone.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 17,
  'post_date' => '2018-05-01 15:32:48',
  'post_date_gmt' => '2018-05-01 15:32:48',
  'post_content' => 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias at vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis.

quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.

Aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus.',
  'post_title' => 'We Ride With Pride',
  'post_excerpt' => '',
  'post_name' => 'we-ride-with-pride',
  'post_modified' => '2021-03-30 18:48:55',
  'post_modified_gmt' => '2021-03-30 18:48:55',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-sport/?p=6',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"cols\\":[{\\"grid_class\\":\\"col-full\\",\\"element_id\\":\\"3owy066\\"}],\\"element_id\\":\\"tg2e010\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'category' => 'tips',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-sport/files/2021/03/skate-park2.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 18,
  'post_date' => '2018-04-25 15:19:27',
  'post_date_gmt' => '2018-04-25 15:19:27',
  'post_content' => 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias at vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis.

quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.

Aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus.',
  'post_title' => 'Time to Skating',
  'post_excerpt' => '',
  'post_name' => 'time-to-skating',
  'post_modified' => '2021-04-03 15:33:54',
  'post_modified_gmt' => '2021-04-03 15:33:54',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-sport/?p=7',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'hide_post_title' => 'no',
    '_themify_builder_settings_json' => '[{\\"cols\\":[{\\"grid_class\\":\\"col-full\\",\\"element_id\\":\\"xvbc008\\"}],\\"element_id\\":\\"6z27644\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'category' => 'news',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-sport/files/2021/03/girl-ready-to-skate.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 19,
  'post_date' => '2018-04-24 15:31:39',
  'post_date_gmt' => '2018-04-24 15:31:39',
  'post_content' => 'Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus. At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates.

Magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?”  repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis.',
  'post_title' => 'Practice for Perfection',
  'post_excerpt' => '',
  'post_name' => 'practice-for-perfection',
  'post_modified' => '2021-04-03 15:33:54',
  'post_modified_gmt' => '2021-04-03 15:33:54',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-sport/?p=39',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"cols\\":[{\\"grid_class\\":\\"col-full\\",\\"element_id\\":\\"nptf084\\"}],\\"element_id\\":\\"1qx4082\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'category' => 'tips',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-sport/files/2021/03/skate-trick.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 20,
  'post_date' => '2018-04-22 15:39:29',
  'post_date_gmt' => '2018-04-22 15:39:29',
  'post_content' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur.

Inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur.',
  'post_title' => 'First Time Skating',
  'post_excerpt' => '',
  'post_name' => 'first-time-skating',
  'post_modified' => '2021-04-03 15:33:55',
  'post_modified_gmt' => '2021-04-03 15:33:55',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-sport/?p=46',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"cols\\":[{\\"grid_class\\":\\"col-full\\",\\"element_id\\":\\"erm7302\\"}],\\"element_id\\":\\"neoy023\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'category' => 'tips',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-sport/files/2021/03/skate-flip.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 21,
  'post_date' => '2018-04-20 15:41:32',
  'post_date_gmt' => '2018-04-20 15:41:32',
  'post_content' => 'Ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.

Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.

Laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit ess. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.',
  'post_title' => 'Time For Competition',
  'post_excerpt' => '',
  'post_name' => 'time-for-competition',
  'post_modified' => '2021-04-29 05:07:56',
  'post_modified_gmt' => '2021-04-29 05:07:56',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-sport/?p=49',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"cols\\":[{\\"grid_class\\":\\"col-full\\",\\"element_id\\":\\"0xsk404\\"}],\\"element_id\\":\\"27mq888\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'category' => 'news',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-sport/files/2021/03/skate-board.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 22,
  'post_date' => '2018-04-19 15:42:40',
  'post_date_gmt' => '2018-04-19 15:42:40',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.<span id="more-5716"></span>

Magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.

Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt neque porro quisquam.',
  'post_title' => 'Find New Atmosphere',
  'post_excerpt' => '',
  'post_name' => 'find-new-atmosphere',
  'post_modified' => '2021-04-29 05:07:56',
  'post_modified_gmt' => '2021-04-29 05:07:56',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-sport/?p=51',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"cols\\":[{\\"grid_class\\":\\"col-full\\",\\"element_id\\":\\"6hrw566\\"}],\\"element_id\\":\\"4zsy225\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'category' => 'news',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-sport/files/2021/03/skate-at-beach.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 23,
  'post_date' => '2018-05-13 02:56:57',
  'post_date_gmt' => '2018-05-13 02:56:57',
  'post_content' => '<!--themify_builder_static--><h1>About Us</h1>
<h2>Skateboards that make you fly</h2> <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In sit amet mattis sapien. Mauris cursus tellus ut egestas maximus. Aliquam laoreet felis sed porta ultriciese, et eleifend turpis eleifend. lacinia semper. Nulla in lectus non ante efficitur aliquet. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Donec elementum turpis a lacinia semper.</p>
<h3>About Skate free style</h3> <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In sit amet mattis sapien. Mauris cursus tellus ut egestas maximus. Aliquam laoreet felis sed porta ultricies. Aliquam pulvinar erat ut tortor vulputate, et eleifend turpis eleifend. Nam sollicitudin bibendum tellus et consequat. Curabitur ultrices posuere bibendum. Ut a mi lorem. Nunc pulvinar ipsum vitae egestas suscipit. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Donec elementum turpis a lacinia semper. Nulla in lectus non ante efficitur aliquet.</p>
<p>Reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt.</p> <ul> <li>Magna aliqua. Ut enim ad minim veniam</li> <li>Fugiat nulla paria.</li> <li>Officia deserunt mollit ani.</li> <li>Magna aliqua. Ut enim ad minim veniam.</li> <li>Fugiat nulla paria</li> <li>Officia deserunt mollit ani</li> <li>Officia deserunt mollit anim</li> </ul>
<a href="https://themify.me/demo/themes/ultra-sport/shop/" > Shop Now </a>
<h2>Make your uphill battle a breeze</h2> <ul> <li>Magna aliqua Ut enim ad minim veniam.</li> <li>Fugiat nulla paria.</li> <li>Officia deserunt mollit.</li> <li>Ani officia deserunt mollit anim.</li> </ul>
<h2>A Belt Drive System</h2> <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In sit amet mattis sapien. Mauris cursus tellus ut egestas maximus. Aliquam laoreet felis sed porta ultricies. Aliquam pulvinar erat ut tortor vulputate, et eleifend turpis eleifend. Nam sollicitudin bibendum tellus et consequat. Curabitur ultrices posuere bibendum. Ut a mi lorem. Nunc pulvinar ipsum vitae egestas suscipit.</p>
<img loading="lazy" width="1042" height="954" src="https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard-image.png" title="skateboard-image" alt="skateboard-image" srcset="https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard-image.png 1042w, https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard-image-300x275.png 300w, https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard-image-1024x938.png 1024w, https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard-image-768x703.png 768w, https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard-image-600x549.png 600w" sizes="(max-width: 1042px) 100vw, 1042px" />
<h2>Our Team<br/></h2>
<p>You’ve come to the right place! Skate\'s dedicated support and service team is here for you, from diagnosing board issues to answering questions about technical specs–and everything in between. Whether you’re still deciding on a board or have been riding for 2 years, we’ve got your back. Visit our support page or give us a ring at +62 (021) 898999.</p>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-sport/files/2021/03/teenagers-1-1024x535-1024x535.jpg" width="1024" height="535" title="teenagers-1" alt="teenagers-1" srcset="https://themify.me/demo/themes/ultra-sport/files/2021/03/teenagers-1-1024x535-1024x535.jpg 1024w, https://themify.me/demo/themes/ultra-sport/files/2021/03/teenagers-1-300x157.jpg 300w, https://themify.me/demo/themes/ultra-sport/files/2021/03/teenagers-1-768x402.jpg 768w, https://themify.me/demo/themes/ultra-sport/files/2021/03/teenagers-1-600x314.jpg 600w, https://themify.me/demo/themes/ultra-sport/files/2021/03/teenagers-1.jpg 1268w" sizes="(max-width: 1024px) 100vw, 1024px" />
<h3>PACIFIC SKATEBOARD OCEAN</h3> <p>Free delivery over $50 orders</p>
<a href="https://themify.me/demo/themes/ultra-sport/shop/" > Shop Now </a><!--/themify_builder_static-->',
  'post_title' => 'About Us',
  'post_excerpt' => '',
  'post_name' => 'about-us',
  'post_modified' => '2021-03-30 06:50:00',
  'post_modified_gmt' => '2021-03-30 06:50:00',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-sport/?page_id=191',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"cl1o808\\",\\"cols\\":[{\\"element_id\\":\\"hum0888\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"y8k0585\\",\\"mod_settings\\":{\\"background_image-type\\":\\"image\\",\\"background_repeat\\":\\"repeat\\",\\"font_color\\":\\"#ffffff\\",\\"text_align\\":\\"center\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"content_text\\":\\"<h1>About Us<\\\\/h1>\\"}}]}],\\"styling\\":{\\"background_type\\":\\"image\\",\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-sport\\\\/files\\\\/2021\\\\/03\\\\/bg-top-title.png\\",\\"background_repeat\\":\\"fullcover\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"50,50\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"12\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"12\\",\\"padding_bottom_unit\\":\\"%\\",\\"margin_bottom\\":\\"-7\\",\\"margin_bottom_unit\\":\\"%\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"row_width\\":\\"fullwidth\\",\\"background_zoom\\":false,\\"background_slider_speed\\":\\"2000\\"}},{\\"element_id\\":\\"t7o6666\\",\\"cols\\":[{\\"element_id\\":\\"opfd208\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"0s62650\\",\\"mod_settings\\":{\\"background_image-type\\":\\"image\\",\\"background_repeat\\":\\"repeat\\",\\"font_size\\":\\"1.2\\",\\"font_size_unit\\":\\"em\\",\\"line_height\\":\\"1.6\\",\\"line_height_unit\\":\\"em\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"content_text\\":\\"<h2>Skateboards that make you fly<\\\\/h2>\\\\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In sit amet mattis sapien. Mauris cursus tellus ut egestas maximus. Aliquam laoreet felis sed porta ultriciese, et eleifend turpis eleifend. lacinia semper. Nulla in lectus non ante efficitur aliquet. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Donec elementum turpis a lacinia semper.<\\\\/p>\\"}}]},{\\"element_id\\":\\"lf81650\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"rzag867\\",\\"mod_settings\\":{\\"background_image-type\\":\\"image\\",\\"background_repeat\\":\\"repeat\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"margin_top\\":\\"5\\",\\"margin_top_unit\\":\\"%\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"content_text\\":\\"<h3>About Skate free style<\\\\/h3>\\\\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In sit amet mattis sapien. Mauris cursus tellus ut egestas maximus. Aliquam laoreet felis sed porta ultricies. Aliquam pulvinar erat ut tortor vulputate, et eleifend turpis eleifend. Nam sollicitudin bibendum tellus et consequat. Curabitur ultrices posuere bibendum. Ut a mi lorem. Nunc pulvinar ipsum vitae egestas suscipit. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Donec elementum turpis a lacinia semper. Nulla in lectus non ante efficitur aliquet.<\\\\/p>\\"}}]}],\\"styling\\":{\\"background_type\\":\\"image\\",\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-sport\\\\/files\\\\/2021\\\\/03\\\\/bg-about-top.png\\",\\"background_repeat\\":\\"best-fit-image\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"100,0\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"14\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"10\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"row_width\\":\\"fullwidth\\",\\"background_zoom\\":false,\\"background_slider_speed\\":\\"2000\\"}},{\\"element_id\\":\\"f7k6058\\",\\"cols\\":[{\\"element_id\\":\\"gnuo056\\",\\"grid_class\\":\\"col4-2\\"},{\\"element_id\\":\\"mevs861\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"jig1006\\",\\"mod_settings\\":{\\"background_image-type\\":\\"image\\",\\"background_repeat\\":\\"repeat\\",\\"font_color\\":\\"#ffffff\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"margin_bottom\\":\\"1\\",\\"margin_bottom_unit\\":\\"em\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"content_text\\":\\"<p>Reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt.<\\\\/p>\\\\n<ul>\\\\n<li>Magna aliqua. Ut enim ad minim veniam<\\\\/li>\\\\n<li>Fugiat nulla paria.<\\\\/li>\\\\n<li>Officia deserunt mollit ani.<\\\\/li>\\\\n<li>Magna aliqua. Ut enim ad minim veniam.<\\\\/li>\\\\n<li>Fugiat nulla paria<\\\\/li>\\\\n<li>Officia deserunt mollit ani<\\\\/li>\\\\n<li>Officia deserunt mollit anim<\\\\/li>\\\\n<\\\\/ul>\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"v7ff600\\",\\"mod_settings\\":{\\"background_image-type\\":\\"image\\",\\"background_image-gradient-angle\\":\\"0\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"checkbox_padding_link_apply_all\\":\\"1\\",\\"checkbox_link_margin_apply_all\\":\\"1\\",\\"checkbox_link_border_apply_all\\":\\"1\\",\\"buttons_size\\":\\"normal\\",\\"display\\":\\"buttons-horizontal\\",\\"content_button\\":[{\\"label\\":\\"Shop Now\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-sport\\\\/shop\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"icon_alignment\\":\\"left\\"}],\\"buttons_shape\\":\\"normal\\"}}],\\"styling\\":{\\"background_type\\":\\"image\\",\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_repeat\\":\\"repeat\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"center-center\\",\\"background_color\\":\\"#242856\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"5\\",\\"padding_top_unit\\":\\"%\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"breakpoint_mobile\\":{\\"background_type\\":\\"image\\",\\"background_repeat\\":\\"repeat\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"center-center\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"8\\",\\"padding_top_unit\\":\\"%\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"margin_top\\":\\"7\\",\\"margin_top_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\"}}}],\\"styling\\":{\\"background_type\\":\\"image\\",\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-sport\\\\/files\\\\/2021\\\\/03\\\\/bg-features.png\\",\\"background_repeat\\":\\"fullcover\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"50,100\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"20\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"20\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"row_width\\":\\"fullwidth-content\\",\\"background_zoom\\":false,\\"background_slider_speed\\":\\"2000\\"}},{\\"element_id\\":\\"rozd500\\",\\"cols\\":[{\\"element_id\\":\\"g0vy608\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"o5aa000\\",\\"mod_settings\\":{\\"background_image-type\\":\\"image\\",\\"background_repeat\\":\\"repeat\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"margin_bottom\\":\\"5\\",\\"margin_bottom_unit\\":\\"em\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"content_text\\":\\"<h2>Make your uphill battle a breeze<\\\\/h2>\\\\n<ul>\\\\n<li>Magna aliqua Ut enim ad minim veniam.<\\\\/li>\\\\n<li>Fugiat nulla paria.<\\\\/li>\\\\n<li>Officia deserunt mollit.<\\\\/li>\\\\n<li>Ani officia deserunt mollit anim.<\\\\/li>\\\\n<\\\\/ul>\\",\\"custom_parallax_scroll_speed\\":\\"2\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"tpny969\\",\\"mod_settings\\":{\\"background_image-type\\":\\"image\\",\\"background_repeat\\":\\"repeat\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"content_text\\":\\"<h2>A Belt Drive System<\\\\/h2>\\\\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In sit amet mattis sapien. Mauris cursus tellus ut egestas maximus. Aliquam laoreet felis sed porta ultricies. Aliquam pulvinar erat ut tortor vulputate, et eleifend turpis eleifend. Nam sollicitudin bibendum tellus et consequat. Curabitur ultrices posuere bibendum. Ut a mi lorem. Nunc pulvinar ipsum vitae egestas suscipit.<\\\\/p>\\",\\"custom_parallax_scroll_speed\\":\\"1\\"}}],\\"styling\\":{\\"background_type\\":\\"image\\",\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_repeat\\":\\"repeat\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"center-center\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"5\\",\\"padding_top_unit\\":\\"%\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\"}},{\\"element_id\\":\\"dyc1780\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"ry9m808\\",\\"mod_settings\\":{\\"background_image-type\\":\\"image\\",\\"background_repeat\\":\\"repeat\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"style_image\\":\\"image-right\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-sport\\\\/files\\\\/2021\\\\/03\\\\/skateboard-image.png\\",\\"param_image\\":\\"regular\\",\\"image_zoom_icon\\":false,\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false}}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"gutter\\":\\"gutter-none\\",\\"styling\\":{\\"background_type\\":\\"image\\",\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_repeat\\":\\"repeat\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"center-center\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"row_width\\":\\"fullwidth-content\\"}},{\\"element_id\\":\\"udx1556\\",\\"cols\\":[{\\"element_id\\":\\"5c2s868\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"fancy-heading\\",\\"element_id\\":\\"73b1880\\",\\"mod_settings\\":{\\"background_image-type\\":\\"image\\",\\"background_repeat\\":\\"repeat\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"heading\\":\\"Our Team\\",\\"heading_tag\\":\\"h2\\",\\"text_alignment\\":\\"themify-text-center\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"3p1p589\\",\\"mod_settings\\":{\\"background_image-type\\":\\"image\\",\\"background_repeat\\":\\"repeat\\",\\"text_align\\":\\"center\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"content_text\\":\\"<p>You’ve come to the right place! Skate\\\'s dedicated support and service team is here for you, from diagnosing board issues to answering questions about technical specs–and everything in between. Whether you’re still deciding on a board or have been riding for 2 years, we’ve got your back. Visit our support page or give us a ring at +62 (021) 898999.<\\\\/p>\\"}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"qfee900\\",\\"mod_settings\\":{\\"background_image-type\\":\\"image\\",\\"background_repeat\\":\\"repeat\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"style_image\\":\\"image-center\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-sport\\\\/files\\\\/2021\\\\/03\\\\/teenagers-1.jpg\\",\\"param_image\\":\\"regular\\",\\"image_zoom_icon\\":false,\\"auto_fullwidth\\":false,\\"width_image\\":\\"1024\\",\\"appearance_image\\":false,\\"caption_on_overlay\\":false}}]}],\\"styling\\":{\\"background_type\\":\\"image\\",\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-sport\\\\/files\\\\/2021\\\\/03\\\\/bg-text.png\\",\\"background_repeat\\":\\"repeat-none\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"0,0\\",\\"background_color\\":\\"#f6f6f8\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"14\\",\\"padding_top_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"row_width\\":\\"fullwidth\\",\\"background_zoom\\":false,\\"background_slider_speed\\":\\"2000\\"}},{\\"element_id\\":\\"xc84680\\",\\"cols\\":[{\\"element_id\\":\\"v6gn900\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"yhrm956\\",\\"mod_settings\\":{\\"background_image-type\\":\\"image\\",\\"background_repeat\\":\\"repeat\\",\\"font_color\\":\\"#ffffff\\",\\"font_size\\":\\"1.3\\",\\"font_size_unit\\":\\"em\\",\\"text_align\\":\\"center\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"margin_bottom\\":\\"1\\",\\"margin_bottom_unit\\":\\"em\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"content_text\\":\\"<h3>PACIFIC SKATEBOARD OCEAN<\\\\/h3>\\\\n<p>Free delivery over $50 orders<\\\\/p>\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"cmi3085\\",\\"mod_settings\\":{\\"background_image-type\\":\\"image\\",\\"background_image-gradient-angle\\":\\"0\\",\\"text_align\\":\\"center\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"checkbox_padding_link_apply_all\\":\\"1\\",\\"checkbox_link_margin_apply_all\\":\\"1\\",\\"checkbox_link_border_apply_all\\":\\"1\\",\\"buttons_size\\":\\"large\\",\\"display\\":\\"buttons-horizontal\\",\\"content_button\\":[{\\"label\\":\\"Shop Now\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-sport\\\\/shop\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"icon_alignment\\":\\"left\\"}],\\"buttons_shape\\":\\"normal\\"}}]}],\\"styling\\":{\\"background_type\\":\\"image\\",\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-sport\\\\/files\\\\/2021\\\\/03\\\\/bg-skater-1024x410-1.jpg\\",\\"background_repeat\\":\\"fullcover\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"50,50\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"18\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"18\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"row_width\\":\\"fullwidth\\",\\"background_zoom\\":false,\\"background_slider_speed\\":\\"2000\\"}}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 24,
  'post_date' => '2018-05-12 02:51:29',
  'post_date_gmt' => '2018-05-12 02:51:29',
  'post_content' => '<!--themify_builder_static--><h1>News</h1>
<h3>Latest News<br/></h3>
<h3>PACIFIC SKATEBOARD OCEAN</h3> <p>Free delivery over $50 orders</p>
<a href="https://themify.me/demo/themes/ultra-sport/shop/" > Shop Now </a><!--/themify_builder_static-->',
  'post_title' => 'Blog',
  'post_excerpt' => '',
  'post_name' => 'blog',
  'post_modified' => '2021-03-30 18:45:47',
  'post_modified_gmt' => '2021-03-30 18:45:47',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-sport/?page_id=175',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'layout' => 'grid4',
    'image_width' => '280',
    'image_height' => '160',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"34ed033\\",\\"cols\\":[{\\"element_id\\":\\"p0qq067\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"crvy004\\",\\"mod_settings\\":{\\"background_image-type\\":\\"image\\",\\"background_repeat\\":\\"repeat\\",\\"font_color\\":\\"#ffffff\\",\\"text_align\\":\\"center\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"content_text\\":\\"<h1>News<\\\\/h1>\\"}}]}],\\"styling\\":{\\"background_type\\":\\"image\\",\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-sport\\\\/files\\\\/2021\\\\/03\\\\/bg-top-title.png\\",\\"background_repeat\\":\\"fullcover\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"53.66,66.56\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"12\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"12\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"row_width\\":\\"fullwidth\\",\\"background_zoom\\":false,\\"background_slider_speed\\":\\"2000\\"}},{\\"element_id\\":\\"tp5j707\\",\\"cols\\":[{\\"element_id\\":\\"2ul7202\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"fancy-heading\\",\\"element_id\\":\\"yl91032\\",\\"mod_settings\\":{\\"background_image-type\\":\\"image\\",\\"background_repeat\\":\\"repeat\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"margin_bottom\\":\\"20\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"heading\\":\\"Latest News\\",\\"heading_tag\\":\\"h3\\",\\"text_alignment\\":\\"themify-text-center\\"}},{\\"mod_name\\":\\"post\\",\\"element_id\\":\\"97fd440\\",\\"mod_settings\\":{\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"layout_post\\":\\"grid4\\",\\"post_type_post\\":\\"post\\",\\"content_layout\\":\\"boxed\\",\\"masonry_post\\":\\"yes\\",\\"type_query_post\\":\\"category\\",\\"category_post\\":\\"0|single\\",\\"post_tag_post\\":\\"0|multiple\\",\\"product_cat_post\\":\\"0|multiple\\",\\"product_tag_post\\":\\"0|multiple\\",\\"product_shipping_class_post\\":\\"0|multiple\\",\\"post_per_page_post\\":\\"8\\",\\"order_post\\":\\"desc\\",\\"orderby_post\\":\\"date\\",\\"display_post\\":\\"none\\",\\"img_width_post\\":\\"270\\",\\"img_height_post\\":\\"180\\",\\"hide_page_nav_post\\":\\"no\\",\\"hide_post_meta_post\\":\\"no\\",\\"hide_post_date_post\\":\\"no\\",\\"unlink_post_title_post\\":\\"no\\",\\"hide_post_title_post\\":\\"no\\",\\"unlink_feat_img_post\\":\\"no\\",\\"auto_fullwidth_post\\":false,\\"hide_feat_img_post\\":\\"no\\",\\"post_filter\\":\\"no\\",\\"post_content_layout\\":\\"boxed\\",\\"sticky_post\\":\\"no\\",\\"term_type\\":\\"category\\"}}]}],\\"styling\\":{\\"background_type\\":\\"image\\",\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-sport\\\\/files\\\\/2021\\\\/03\\\\/bg-our-blog.png\\",\\"background_repeat\\":\\"best-fit-image\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"100,0\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"10\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"10\\",\\"padding_bottom_unit\\":\\"%\\",\\"margin_top\\":\\"-8\\",\\"margin_top_unit\\":\\"%\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"background_zoom\\":false,\\"background_slider_speed\\":\\"2000\\"}},{\\"element_id\\":\\"b9yo607\\",\\"cols\\":[{\\"element_id\\":\\"tdis724\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"5vqa000\\",\\"mod_settings\\":{\\"background_image-type\\":\\"image\\",\\"background_repeat\\":\\"repeat\\",\\"font_color\\":\\"#ffffff\\",\\"font_size\\":\\"1.3\\",\\"font_size_unit\\":\\"em\\",\\"text_align\\":\\"center\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"margin_bottom\\":\\"1\\",\\"margin_bottom_unit\\":\\"em\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"content_text\\":\\"<h3>PACIFIC SKATEBOARD OCEAN<\\\\/h3>\\\\n<p>Free delivery over $50 orders<\\\\/p>\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"xsi2403\\",\\"mod_settings\\":{\\"background_image-type\\":\\"image\\",\\"background_repeat\\":\\"repeat\\",\\"text_align\\":\\"center\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"button_background_color\\":\\"#242856\\",\\"link_color\\":\\"#ffffff\\",\\"checkbox_padding_link_apply_all\\":\\"1\\",\\"checkbox_link_margin_apply_all\\":\\"1\\",\\"checkbox_link_border_apply_all\\":\\"1\\",\\"buttons_size\\":\\"normal\\",\\"display\\":\\"buttons-horizontal\\",\\"content_button\\":[{\\"label\\":\\"Shop Now\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-sport\\\\/shop\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"icon_alignment\\":\\"left\\",\\"button_color_bg\\":\\"tb_default_color\\"}],\\"buttons_shape\\":\\"normal\\"}}]}],\\"styling\\":{\\"background_type\\":\\"image\\",\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-sport\\\\/files\\\\/2021\\\\/03\\\\/bg-skater-1024x410-1.jpg\\",\\"background_repeat\\":\\"fullcover\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"50,50\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"18\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"18\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"row_width\\":\\"fullwidth\\",\\"background_zoom\\":false,\\"background_slider_speed\\":\\"2000\\"}}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 27,
  'post_date' => '2018-05-13 02:57:40',
  'post_date_gmt' => '2018-05-13 02:57:40',
  'post_content' => '<!--themify_builder_static--><h1>Contact</h1>
<p>We love to hear from you, whether a complaint or a compliment. Get in touch now.</p>
<form action="https://themify.me/demo/themes/ultra-sport/wp-admin/admin-ajax.php" class="builder-contact" id="tb_8244106-form" method="post" data-post-id="0" data-element-id="8244106" data-orig-id="" > <label for="tb_8244106-contact-name">Your Name </label> <input type="text" name="contact-name" id="tb_8244106-contact-name" value="" /> Your Name <label for="tb_8244106-contact-email">Your Email </label> <input type="text" name="contact-email" id="tb_8244106-contact-email" value="" /> Your Email <label for="tb_8244106-contact-subject">Subject *</label> <input type="text" name="contact-subject" id="tb_8244106-contact-subject" value="" required/> Subject * <label for="tb_8244106-contact-message">Message *</label> <textarea name="contact-message" id="tb_8244106-contact-message" rows="8" cols="45" required></textarea> Message * <label> <input type="checkbox" name="gdpr" value="1" required/> I consent to my submitted data being collected and stored * </label> <button type="submit"> Submit</button> </form>
<img loading="lazy" width="40" height="40" src="https://themify.me/demo/themes/ultra-sport/files/2021/03/office-icon.png" title="Office Address" alt="Oplication Block Street, Block 36, City, Australia 804538"> <h3> Office Address </h3> Oplication Block Street, Block 36, City, Australia 804538
<img loading="lazy" width="40" height="40" src="https://themify.me/demo/themes/ultra-sport/files/2021/03/offfice-hours.png" title="Office Hours" alt="MON - FRIDAY: 12 Noon to 9 PM SAT - SUN: 14 Noon to 12 PM"> <h3> Office Hours </h3> MON - FRIDAY: 12 Noon to 9 PM SAT - SUN: 14 Noon to 12 PM
<img loading="lazy" width="40" height="32" src="https://themify.me/demo/themes/ultra-sport/files/2021/03/office-mail.png" title="Contact" alt="Support: 1-800-268-8866 Email: info@skate.com"> <h3> Contact </h3> Support: 1-800-268-8866 Email: info@skate.com
Armoury St, Toronto, ON Canada<!--/themify_builder_static-->',
  'post_title' => 'Contact',
  'post_excerpt' => '',
  'post_name' => 'contact',
  'post_modified' => '2021-03-30 07:07:40',
  'post_modified_gmt' => '2021-03-30 07:07:40',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-sport/?page_id=193',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"zp6l97\\",\\"cols\\":[{\\"element_id\\":\\"ss1z103\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"gu6h104\\",\\"mod_settings\\":{\\"background_repeat\\":\\"repeat\\",\\"font_color\\":\\"#ffffff\\",\\"text_align\\":\\"center\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"content_text\\":\\"<h1>Contact<\\\\/h1>\\"}}]}],\\"styling\\":{\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-sport\\\\/files\\\\/2021\\\\/03\\\\/bg-contact-page.png\\",\\"background_repeat\\":\\"fullcover\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"50,50\\",\\"background_color\\":\\"#fcfcfc\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"12\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"22\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"row_width\\":\\"fullwidth\\",\\"breakpoint_mobile\\":{\\"background_repeat\\":\\"fullcover\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"center-center\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\"},\\"background_zoom\\":false,\\"background_gradient-circle-radial\\":false,\\"background_gradient-gradient-angle\\":\\"180\\",\\"background_gradient-gradient-type\\":\\"linear\\",\\"background_slider_speed\\":\\"2000\\",\\"background_type\\":\\"image\\"}},{\\"element_id\\":\\"e2sf97\\",\\"cols\\":[{\\"element_id\\":\\"b283106\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"icw1106\\",\\"mod_settings\\":{\\"background_repeat\\":\\"repeat\\",\\"text_align\\":\\"center\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"content_text\\":\\"<p>We love to hear from you, whether a complaint or a compliment. Get in touch now.<\\\\/p>\\"}},{\\"mod_name\\":\\"contact\\",\\"element_id\\":\\"8244106\\",\\"mod_settings\\":{\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"checkbox_border_inputs_apply_all\\":\\"1\\",\\"checkbox_border_send_apply_all\\":\\"1\\",\\"checkbox_padding_success_message_apply_all\\":\\"1\\",\\"checkbox_margin_success_message_apply_all\\":\\"1\\",\\"checkbox_border_success_message_apply_all\\":\\"1\\",\\"checkbox_padding_error_message_apply_all\\":\\"1\\",\\"checkbox_margin_error_message_apply_all\\":\\"1\\",\\"checkbox_border_error_message_apply_all\\":\\"1\\",\\"layout_contact\\":\\"animated-label\\",\\"gdpr\\":\\"accept\\",\\"field_name_label\\":\\"Your Name\\",\\"field_email_label\\":\\"Your Email\\",\\"field_subject_label\\":\\"Subject\\",\\"field_subject_require\\":\\"yes\\",\\"field_subject_active\\":\\"yes\\",\\"field_message_label\\":\\"Message\\",\\"field_extra\\":\\"{ \\\\\\"fields\\\\\\": [] }\\",\\"field_sendcopy_label\\":\\"Send a copy to myself\\",\\"field_order\\":\\"{}\\",\\"field_send_label\\":\\"Submit\\",\\"field_send_align\\":\\"left\\",\\"field_email_active\\":\\"yes\\",\\"field_name_active\\":\\"yes\\",\\"field_message_active\\":\\"yes\\",\\"field_sendcopy_active\\":false,\\"field_captcha_active\\":false,\\"field_email_require\\":false,\\"field_name_require\\":false,\\"contact_sent_from\\":\\"enable\\",\\"post_author\\":false,\\"send_to_admins\\":\\"true\\",\\"field_optin_active\\":false,\\"provider\\":\\"mailchimp\\",\\"user_role\\":\\"admin\\"}}],\\"styling\\":{\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_repeat\\":\\"repeat\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"center-center\\",\\"background_color\\":\\"#ffffff\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"8\\",\\"padding_top_unit\\":\\"%\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"margin_top_unit\\":\\"em\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"border_top_color\\":\\"#ededed\\",\\"border_top_width\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\"}}],\\"styling\\":{\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_repeat\\":\\"repeat\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"center-center\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"margin_top\\":\\"-18\\",\\"margin_top_unit\\":\\"%\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"row_width\\":\\"fullwidth\\",\\"breakpoint_mobile\\":{\\"background_repeat\\":\\"repeat\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"center-center\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"margin_top_unit\\":\\"%\\",\\"checkbox_border_apply_all\\":\\"1\\"}}},{\\"element_id\\":\\"ecqt97\\",\\"cols\\":[{\\"element_id\\":\\"jphr107\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"xqcp107\\",\\"mod_settings\\":{\\"background_repeat\\":\\"repeat\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"style_image\\":\\"image-left\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-sport\\\\/files\\\\/2021\\\\/03\\\\/office-icon.png\\",\\"title_image\\":\\"Office Address\\",\\"param_image\\":\\"regular\\",\\"caption_image\\":\\"Oplication Block Street, Block 36, \\\\nCity, Australia 804538\\",\\"image_zoom_icon\\":false,\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false}}],\\"styling\\":{\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_repeat\\":\\"repeat\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"center-center\\",\\"background_color\\":\\"#fafafa\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"4\\",\\"padding_top_unit\\":\\"%\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"border_right_color\\":\\"#dddddd\\",\\"border_right_width\\":\\"1\\",\\"breakpoint_mobile\\":{\\"background_repeat\\":\\"repeat\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"center-center\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top_unit\\":\\"%\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"border_right_style\\":\\"none\\"}}},{\\"element_id\\":\\"hy5h108\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"8c56108\\",\\"mod_settings\\":{\\"background_repeat\\":\\"repeat\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"style_image\\":\\"image-left\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-sport\\\\/files\\\\/2021\\\\/03\\\\/offfice-hours.png\\",\\"title_image\\":\\"Office Hours\\",\\"param_image\\":\\"regular\\",\\"caption_image\\":\\"MON - FRIDAY: 12 Noon to 9 PM\\\\nSAT - SUN: 14 Noon to 12 PM\\",\\"image_zoom_icon\\":false,\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false}}],\\"styling\\":{\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_repeat\\":\\"repeat\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"center-center\\",\\"background_color\\":\\"#fafafa\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"4\\",\\"padding_top_unit\\":\\"%\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"border_right_color\\":\\"#dddddd\\",\\"border_right_width\\":\\"1\\",\\"breakpoint_mobile\\":{\\"background_repeat\\":\\"repeat\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"center-center\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top_unit\\":\\"%\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"border_right_style\\":\\"none\\"}}},{\\"element_id\\":\\"imxk108\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"k4cz108\\",\\"mod_settings\\":{\\"background_repeat\\":\\"repeat\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"style_image\\":\\"image-left\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-sport\\\\/files\\\\/2021\\\\/03\\\\/office-mail.png\\",\\"title_image\\":\\"Contact\\",\\"param_image\\":\\"regular\\",\\"caption_image\\":\\"Support: 1-800-268-8866\\\\nEmail: info@skate.com\\",\\"image_zoom_icon\\":false,\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false}}],\\"styling\\":{\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_repeat\\":\\"repeat\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"center-center\\",\\"background_color\\":\\"#fafafa\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"4\\",\\"padding_top_unit\\":\\"%\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\"}}],\\"gutter\\":\\"gutter-none\\",\\"styling\\":{\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_repeat\\":\\"repeat\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"center-center\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"margin_top_unit\\":\\"em\\",\\"margin_bottom\\":\\"-80\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"custom_parallax_scroll_zindex\\":\\"1\\"}},{\\"element_id\\":\\"3bns98\\",\\"cols\\":[{\\"element_id\\":\\"0j8f109\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"maps-pro\\",\\"element_id\\":\\"tikf109\\",\\"mod_settings\\":{\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"map_display_type\\":\\"dynamic\\",\\"w_map\\":\\"100\\",\\"unit_w\\":\\"%\\",\\"w_map_static\\":\\"500\\",\\"h_map\\":\\"645\\",\\"type_map\\":\\"ROADMAP\\",\\"style_map\\":\\"greyscale\\",\\"scrollwheel_map\\":\\"disable\\",\\"draggable_map\\":\\"enable\\",\\"disable_map_ui\\":\\"no\\",\\"zoom_map\\":\\"17\\",\\"map_polyline\\":\\"no\\",\\"map_polyline_geodesic\\":\\"no\\",\\"map_center\\":\\"toronto\\",\\"markers\\":[{\\"address\\":\\"armoury St, Toronto, ON Canada\\",\\"latlng\\":\\"43.6533297,-79.3864873\\",\\"title\\":\\"Armoury St, Toronto, ON Canada\\",\\"image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-sport\\\\/files\\\\/2021\\\\/03\\\\/map-marker-icon.png\\"}],\\"w_map_unit\\":\\"%\\",\\"map_polyline_stroke\\":\\"2\\",\\"map_polyline_color\\":\\"#ff0000_1\\",\\"trigger\\":\\"click\\",\\"display\\":\\"text\\",\\"map_link\\":false}}]}],\\"styling\\":{\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_repeat\\":\\"repeat\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"center-center\\",\\"background_color\\":\\"#f0f0f0\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"row_width\\":\\"fullwidth-content\\"}}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 28,
  'post_date' => '2018-05-11 04:42:23',
  'post_date_gmt' => '2018-05-11 04:42:23',
  'post_content' => '<p><!--themify_builder_static--><img loading="lazy" src="https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard-806x970.png" width="806" height="970" title="skateboard" alt="skateboard" srcset="https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard.png 806w, https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard-249x300.png 249w, https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard-768x924.png 768w, https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard-600x722.png 600w" sizes="(max-width: 806px) 100vw, 806px" />
<h1>Skateboarding done right</h1> <h3>Strong &amp; comes in all size</h3>
<a href="https://themify.me/demo/themes/ultra-sport/shop/" > Shop Now </a>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-sport/files/2021/03/adio-logo-156x95.png" width="156" height="95" title="adio-logo" alt="adio-logo">
<img loading="lazy" src="https://themify.me/demo/themes/ultra-sport/files/2021/03/dgk-logo-171x58.png" width="171" height="58" title="dgk-logo" alt="dgk-logo">
<img loading="lazy" src="https://themify.me/demo/themes/ultra-sport/files/2021/03/rpm-logo-137x114.png" width="137" height="114" title="rpm-logo" alt="rpm-logo">
<img loading="lazy" src="https://themify.me/demo/themes/ultra-sport/files/2021/03/penny-australia-122x123.png" width="122" height="123" title="penny-australia" alt="penny-australia" srcset="https://themify.me/demo/themes/ultra-sport/files/2021/03/penny-australia.png 122w, https://themify.me/demo/themes/ultra-sport/files/2021/03/penny-australia-100x100.png 100w" sizes="(max-width: 122px) 100vw, 122px" />
<img loading="lazy" src="https://themify.me/demo/themes/ultra-sport/files/2021/03/vans-257x112.png" width="257" height="112" title="vans" alt="vans">
<img loading="lazy" src="https://themify.me/demo/themes/ultra-sport/files/2021/03/dc-logo-81x70.png" width="81" height="70" title="dc-logo" alt="dc-logo">
<h2>Features<br/></h2>
<p>Reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt.</p> <ul> <li>Magna aliqua. Ut enim ad minim veniam</li> <li>Fugiat nulla paria.</li> <li>Officia deserunt mollit ani.</li> <li>Magna aliqua. Ut enim ad minim veniam.</li> <li>Fugiat nulla paria</li> <li>Officia deserunt mollit ani</li> <li>Officia deserunt mollit anim</li> </ul>
<a href="https://themify.me/demo/themes/ultra-sport/shop/" > See More </a>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-sport/files/2021/03/skate-image-935x804.png" width="935" height="804" title="skate-image" alt="skate-image" srcset="https://themify.me/demo/themes/ultra-sport/files/2021/03/skate-image.png 935w, https://themify.me/demo/themes/ultra-sport/files/2021/03/skate-image-300x258.png 300w, https://themify.me/demo/themes/ultra-sport/files/2021/03/skate-image-768x661.png 768w, https://themify.me/demo/themes/ultra-sport/files/2021/03/skate-image-600x517.png 600w" sizes="(max-width: 935px) 100vw, 935px" />
<h2>Features<br/></h2>
<ul data-lazy="1"> <li> <figure> <a href="https://themify.me/demo/themes/ultra-sport/product/bob-marley-bamboo/" title="Bob Marley Bamboo"><img loading="lazy" src="https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard9-380x502.png" width="380" height="502" title="Bob Marley Bamboo" alt="Bob Marley Bamboo" srcset="https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard9-380x502.png 380w, https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard9-227x300.png 227w, https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard9-369x488.png 369w, https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard9.png 530w" sizes="(max-width: 380px) 100vw, 380px" /></a> </figure> <h3> <a href="https://themify.me/demo/themes/ultra-sport/product/bob-marley-bamboo/" title="Bob Marley Bamboo"> Bob Marley Bamboo </a> </h3> 
 <bdi>&pound;122.00</bdi> <p><a href="?add-to-cart=32" data-quantity="1" data-product_id="32" data-product_sku="" aria-label="Add &ldquo;Bob Marley Bamboo&rdquo; to your cart" rel="nofollow">Add to cart</a></p> </li> <li> <figure> <a href="https://themify.me/demo/themes/ultra-sport/product/robo-monster-chaos/" title="Robo Monster Chaos"><img loading="lazy" src="https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard8-380x502.png" width="380" height="502" title="Robo Monster Chaos" alt="Robo Monster Chaos" srcset="https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard8-380x502.png 380w, https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard8-227x300.png 227w, https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard8.png 530w" sizes="(max-width: 380px) 100vw, 380px" /></a> </figure> <h3> <a href="https://themify.me/demo/themes/ultra-sport/product/robo-monster-chaos/" title="Robo Monster Chaos"> Robo Monster Chaos </a> </h3> 
 <bdi>&pound;225.00</bdi> <p><a href="?add-to-cart=33" data-quantity="1" data-product_id="33" data-product_sku="" aria-label="Add &ldquo;Robo Monster Chaos&rdquo; to your cart" rel="nofollow">Add to cart</a></p> </li> <li> <figure> <a href="https://themify.me/demo/themes/ultra-sport/product/kryptonics-board/" title="Kryptonics Board"><img loading="lazy" src="https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard7-1-380x502.png" width="380" height="502" title="Kryptonics Board" alt="Kryptonics Board" srcset="https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard7-1-380x502.png 380w, https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard7-1-227x300.png 227w, https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard7-1-369x488.png 369w, https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard7-1.png 530w" sizes="(max-width: 380px) 100vw, 380px" /></a> </figure> <h3> <a href="https://themify.me/demo/themes/ultra-sport/product/kryptonics-board/" title="Kryptonics Board"> Kryptonics Board </a> </h3> 
 <bdi>&pound;125.00</bdi> <p><a href="?add-to-cart=34" data-quantity="1" data-product_id="34" data-product_sku="" aria-label="Add &ldquo;Kryptonics Board&rdquo; to your cart" rel="nofollow">Add to cart</a></p> </li> <li> <figure> <a href="https://themify.me/demo/themes/ultra-sport/product/ethnic-wood/" title="Ethnic Wood"><img loading="lazy" src="https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard6-380x502.png" width="380" height="502" title="Ethnic Wood" alt="Ethnic Wood" srcset="https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard6-380x502.png 380w, https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard6-227x300.png 227w, https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard6-369x488.png 369w, https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard6.png 530w" sizes="(max-width: 380px) 100vw, 380px" /></a> </figure> <h3> <a href="https://themify.me/demo/themes/ultra-sport/product/ethnic-wood/" title="Ethnic Wood"> Ethnic Wood </a> </h3> 
 <bdi>&pound;250.00</bdi> <p><a href="?add-to-cart=35" data-quantity="1" data-product_id="35" data-product_sku="" aria-label="Add &ldquo;Ethnic Wood&rdquo; to your cart" rel="nofollow">Add to cart</a></p> </li> <li> <figure> <a href="https://themify.me/demo/themes/ultra-sport/product/hero-clown/" title="Hero Clown"><img loading="lazy" src="https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard5-380x502.png" width="380" height="502" title="Hero Clown" alt="Hero Clown" srcset="https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard5-380x502.png 380w, https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard5-227x300.png 227w, https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard5-369x488.png 369w, https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard5.png 530w" sizes="(max-width: 380px) 100vw, 380px" /></a> </figure> <h3> <a href="https://themify.me/demo/themes/ultra-sport/product/hero-clown/" title="Hero Clown"> Hero Clown </a> </h3> 
 <bdi>&pound;275.00</bdi> <p><a href="?add-to-cart=36" data-quantity="1" data-product_id="36" data-product_sku="" aria-label="Add &ldquo;Hero Clown&rdquo; to your cart" rel="nofollow">Add to cart</a></p> </li> <li> <figure> <a href="https://themify.me/demo/themes/ultra-sport/product/futurio-board-v1/" title="Futurio Board V1"><img loading="lazy" src="https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard4-380x502.png" width="380" height="502" title="Futurio Board V1" alt="Futurio Board V1" srcset="https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard4-380x502.png 380w, https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard4-227x300.png 227w, https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard4-369x488.png 369w, https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard4.png 530w" sizes="(max-width: 380px) 100vw, 380px" /></a> </figure> <h3> <a href="https://themify.me/demo/themes/ultra-sport/product/futurio-board-v1/" title="Futurio Board V1"> Futurio Board V1 </a> </h3> 
 <bdi>&pound;345.00</bdi> <p><a href="?add-to-cart=37" data-quantity="1" data-product_id="37" data-product_sku="" aria-label="Add &ldquo;Futurio Board V1&rdquo; to your cart" rel="nofollow">Add to cart</a></p> </li> </ul>
<a href="https://www.youtube.com/watch?v=nFdVOdP9UGU" > <img loading="lazy" src="https://themify.me/demo/themes/ultra-sport/files/2021/03/skater-image-02-1024x989-800x772.png" width="800" height="772" title="skater-image-02" alt="skater-image-02" srcset="https://themify.me/demo/themes/ultra-sport/files/2021/03/skater-image-02-1024x989-800x772.png 800w, https://themify.me/demo/themes/ultra-sport/files/2021/03/skater-image-02-300x290.png 300w, https://themify.me/demo/themes/ultra-sport/files/2021/03/skater-image-02-1024x989.png 1024w, https://themify.me/demo/themes/ultra-sport/files/2021/03/skater-image-02-768x741.png 768w, https://themify.me/demo/themes/ultra-sport/files/2021/03/skater-image-02-600x579.png 600w, https://themify.me/demo/themes/ultra-sport/files/2021/03/skater-image-02.png 1043w" sizes="(max-width: 800px) 100vw, 800px" /> </a>
<h2>Testimonial<br/></h2>
<p>The best sport shop, I can find the board I need for the next competition, and they delivered free. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam</p> Tony Eagle 
 <p>Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?</p> Bam Blomqvist 
 <p>Vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate</p> Jonathan Exo
<h4>Free Delivery</h4> <p>Free delivery over $50 orders</p>
<a href="https://themify.me/demo/themes/ultra-sport/shop/" > Shop Now </a>
<h2>Latest News<br/></h2><!--/themify_builder_static--></p>

<!-- wp:themify-builder/canvas /-->',
  'post_title' => 'Home',
  'post_excerpt' => '',
  'post_name' => 'home',
  'post_modified' => '2021-03-30 07:03:56',
  'post_modified_gmt' => '2021-03-30 07:03:56',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-sport/?page_id=61',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"2e9829a\\",\\"cols\\":[{\\"element_id\\":\\"5c9f3b8\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"5fd604f\\",\\"mod_settings\\":{\\"background_image-type\\":\\"image\\",\\"background_repeat\\":\\"repeat\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"style_image\\":\\"image-center\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-sport\\\\/files\\\\/2021\\\\/03\\\\/skateboard.png\\",\\"width_image\\":\\"806\\",\\"param_image\\":\\"regular\\",\\"breakpoint_mobile\\":{\\"background_image-type\\":\\"image\\",\\"background_repeat\\":\\"repeat\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"margin_bottom\\":\\"30\\",\\"checkbox_border_apply_all\\":\\"1\\"},\\"image_zoom_icon\\":false,\\"lightbox_height_unit\\":\\"px\\",\\"lightbox_width_unit\\":\\"px\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false}}]},{\\"element_id\\":\\"5210b2a\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"948c013\\",\\"mod_settings\\":{\\"background_image-type\\":\\"image\\",\\"background_repeat\\":\\"repeat\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"margin_bottom\\":\\"1\\",\\"margin_bottom_unit\\":\\"em\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"content_text\\":\\"<h1>Skateboarding done right<\\\\/h1>\\\\n<h3>Strong &amp; comes in all size<\\\\/h3>\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"3e5953f\\",\\"mod_settings\\":{\\"background_image-type\\":\\"image\\",\\"background_repeat\\":\\"repeat\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"button_background_color\\":\\"#ec2e81\\",\\"link_color\\":\\"#ffffff\\",\\"checkbox_padding_link_apply_all\\":\\"1\\",\\"checkbox_link_margin_apply_all\\":\\"1\\",\\"checkbox_link_border_apply_all\\":\\"1\\",\\"buttons_size\\":\\"normal\\",\\"display\\":\\"buttons-horizontal\\",\\"content_button\\":[{\\"label\\":\\"Shop Now\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-sport\\\\/shop\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"icon_alignment\\":\\"left\\",\\"button_color_bg\\":\\"tb_default_color\\"}],\\"buttons_shape\\":\\"normal\\"}}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"styling\\":{\\"background_type\\":\\"image\\",\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-sport\\\\/files\\\\/2021\\\\/03\\\\/bg-top-1.png\\",\\"background_repeat\\":\\"fullcover\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"0,0\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"5\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"5\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"row_width\\":\\"fullwidth\\",\\"breakpoint_mobile\\":{\\"background_type\\":\\"image\\",\\"background_repeat\\":\\"fullcover\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"left-top\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"7\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"8\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\"},\\"background_zoom\\":false,\\"background_gradient-circle-radial\\":false,\\"background_gradient-gradient-angle\\":\\"180\\",\\"background_gradient-gradient-type\\":\\"linear\\",\\"background_slider_speed\\":\\"2000\\"}},{\\"element_id\\":\\"2700db8\\",\\"cols\\":[{\\"element_id\\":\\"cf08b6c\\",\\"grid_class\\":\\"col6-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"594c115\\",\\"mod_settings\\":{\\"background_image-type\\":\\"image\\",\\"background_repeat\\":\\"repeat\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"style_image\\":\\"image-center\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-sport\\\\/files\\\\/2021\\\\/03\\\\/adio-logo.png\\",\\"width_image\\":\\"156\\",\\"param_image\\":\\"regular\\",\\"image_zoom_icon\\":false,\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false}}]},{\\"element_id\\":\\"ee6b78f\\",\\"grid_class\\":\\"col6-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"679287a\\",\\"mod_settings\\":{\\"background_image-type\\":\\"image\\",\\"background_repeat\\":\\"repeat\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"style_image\\":\\"image-center\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-sport\\\\/files\\\\/2021\\\\/03\\\\/dgk-logo.png\\",\\"width_image\\":\\"171\\",\\"param_image\\":\\"regular\\",\\"image_zoom_icon\\":false,\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false}}]},{\\"element_id\\":\\"5335e7b\\",\\"grid_class\\":\\"col6-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"c203fbe\\",\\"mod_settings\\":{\\"background_image-type\\":\\"image\\",\\"background_repeat\\":\\"repeat\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"style_image\\":\\"image-center\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-sport\\\\/files\\\\/2021\\\\/03\\\\/rpm-logo.png\\",\\"width_image\\":\\"137\\",\\"param_image\\":\\"regular\\",\\"image_zoom_icon\\":false,\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false}}]},{\\"element_id\\":\\"e6974ae\\",\\"grid_class\\":\\"col6-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"dc0c49f\\",\\"mod_settings\\":{\\"background_image-type\\":\\"image\\",\\"background_repeat\\":\\"repeat\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"style_image\\":\\"image-center\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-sport\\\\/files\\\\/2021\\\\/03\\\\/penny-australia.png\\",\\"width_image\\":\\"122\\",\\"param_image\\":\\"regular\\",\\"image_zoom_icon\\":false,\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false}}]},{\\"element_id\\":\\"46753af\\",\\"grid_class\\":\\"col6-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"941d9e1\\",\\"mod_settings\\":{\\"background_image-type\\":\\"image\\",\\"background_repeat\\":\\"repeat\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"style_image\\":\\"image-top\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-sport\\\\/files\\\\/2021\\\\/03\\\\/vans.png\\",\\"width_image\\":\\"257\\",\\"param_image\\":\\"regular\\",\\"image_zoom_icon\\":false,\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false}}]},{\\"element_id\\":\\"150e078\\",\\"grid_class\\":\\"col6-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"821e740\\",\\"mod_settings\\":{\\"background_image-type\\":\\"image\\",\\"background_repeat\\":\\"repeat\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"style_image\\":\\"image-center\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-sport\\\\/files\\\\/2021\\\\/03\\\\/dc-logo.png\\",\\"width_image\\":\\"81\\",\\"param_image\\":\\"regular\\",\\"image_zoom_icon\\":false,\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false}}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"gutter\\":\\"gutter-narrow\\",\\"col_mobile\\":\\"column3-1 tb_3col\\",\\"styling\\":{\\"background_type\\":\\"image\\",\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_repeat\\":\\"repeat\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"center-center\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"5\\",\\"padding_top_unit\\":\\"%\\",\\"padding_right\\":\\"3\\",\\"padding_right_unit\\":\\"%\\",\\"padding_bottom\\":\\"5\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_left\\":\\"3\\",\\"padding_left_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"row_width\\":\\"fullwidth-content\\"}},{\\"element_id\\":\\"dd7327a\\",\\"cols\\":[{\\"element_id\\":\\"7ffb99d\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"fancy-heading\\",\\"element_id\\":\\"d67c625\\",\\"mod_settings\\":{\\"background_image-type\\":\\"image\\",\\"background_repeat\\":\\"repeat\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"heading\\":\\"Features\\",\\"heading_tag\\":\\"h2\\",\\"text_alignment\\":\\"themify-text-left\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"6f0bef8\\",\\"mod_settings\\":{\\"background_image-type\\":\\"image\\",\\"background_repeat\\":\\"repeat\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"margin_bottom\\":\\"1\\",\\"margin_bottom_unit\\":\\"em\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"content_text\\":\\"<p>Reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt.<\\\\/p>\\\\n<ul>\\\\n<li>Magna aliqua. Ut enim ad minim veniam<\\\\/li>\\\\n<li>Fugiat nulla paria.<\\\\/li>\\\\n<li>Officia deserunt mollit ani.<\\\\/li>\\\\n<li>Magna aliqua. Ut enim ad minim veniam.<\\\\/li>\\\\n<li>Fugiat nulla paria<\\\\/li>\\\\n<li>Officia deserunt mollit ani<\\\\/li>\\\\n<li>Officia deserunt mollit anim<\\\\/li>\\\\n<\\\\/ul>\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"74bc439\\",\\"mod_settings\\":{\\"background_image-type\\":\\"image\\",\\"background_repeat\\":\\"repeat\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"button_background_color\\":\\"#ec2e81\\",\\"link_color\\":\\"#ffffff\\",\\"checkbox_padding_link_apply_all\\":\\"1\\",\\"checkbox_link_margin_apply_all\\":\\"1\\",\\"checkbox_link_border_apply_all\\":\\"1\\",\\"buttons_size\\":\\"normal\\",\\"display\\":\\"buttons-horizontal\\",\\"content_button\\":[{\\"label\\":\\"See More\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-sport\\\\/shop\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"icon_alignment\\":\\"left\\",\\"button_color_bg\\":\\"tb_default_color\\"}],\\"buttons_shape\\":\\"normal\\"}}],\\"styling\\":{\\"background_type\\":\\"image\\",\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-sport\\\\/files\\\\/2021\\\\/03\\\\/number-02.png\\",\\"background_repeat\\":\\"repeat-none\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"0,0\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"5\\",\\"padding_top_unit\\":\\"%\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"background_zoom\\":false,\\"background_slider_speed\\":\\"2000\\"}},{\\"element_id\\":\\"ca2c0fa\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"e881fea\\",\\"mod_settings\\":{\\"background_image-type\\":\\"image\\",\\"background_repeat\\":\\"repeat\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"style_image\\":\\"image-center\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-sport\\\\/files\\\\/2021\\\\/03\\\\/skate-image.png\\",\\"width_image\\":\\"935\\",\\"param_image\\":\\"regular\\",\\"image_zoom_icon\\":false,\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false}},{\\"mod_name\\":\\"fancy-heading\\",\\"element_id\\":\\"4fb784d\\",\\"mod_settings\\":{\\"background_image-type\\":\\"image\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-sport\\\\/files\\\\/2021\\\\/03\\\\/number-03.png\\",\\"background_repeat\\":\\"no-repeat\\",\\"padding_top\\":\\"6\\",\\"padding_top_unit\\":\\"em\\",\\"padding_bottom\\":\\"9\\",\\"padding_bottom_unit\\":\\"em\\",\\"margin_top\\":\\"-7\\",\\"margin_top_unit\\":\\"em\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"heading\\":\\"Features\\",\\"heading_tag\\":\\"h2\\",\\"text_alignment\\":\\"themify-text-center\\",\\"divider\\":\\"no\\",\\"inline_text\\":false,\\"background_position\\":\\"50,50\\",\\"background_image-circle-radial\\":false}}]}],\\"styling\\":{\\"background_type\\":\\"image\\",\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_repeat\\":\\"repeat\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"center-center\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"row_width\\":\\"fullwidth-content\\",\\"breakpoint_mobile\\":{\\"background_type\\":\\"image\\",\\"background_repeat\\":\\"repeat\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"center-center\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_bottom\\":\\"5\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\"}}},{\\"element_id\\":\\"138991d\\",\\"cols\\":[{\\"element_id\\":\\"63db6f8\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"products\\",\\"element_id\\":\\"a1e42d1\\",\\"mod_settings\\":{\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"query_products\\":\\"all\\",\\"category_products\\":\\"0|multiple\\",\\"hide_child_products\\":\\"no\\",\\"hide_free_products\\":\\"no\\",\\"hide_outofstock_products\\":\\"no\\",\\"post_per_page_products\\":\\"6\\",\\"orderby_products\\":\\"date\\",\\"order_products\\":\\"desc\\",\\"template_products\\":\\"list\\",\\"layout_products\\":\\"grid3\\",\\"layout_slider\\":\\"slider-default\\",\\"visible_opt_slider\\":\\"1\\",\\"auto_scroll_opt_slider\\":\\"off\\",\\"scroll_opt_slider\\":\\"1\\",\\"speed_opt_slider\\":\\"normal\\",\\"effect_slider\\":\\"scroll\\",\\"pause_on_hover_slider\\":\\"resume\\",\\"wrap_slider\\":\\"yes\\",\\"show_nav_slider\\":\\"yes\\",\\"show_arrow_slider\\":\\"yes\\",\\"height_slider\\":\\"variable\\",\\"description_products\\":\\"none\\",\\"hide_feat_img_products\\":\\"no\\",\\"img_width_products\\":\\"380\\",\\"img_height_products\\":\\"502\\",\\"unlink_feat_img_products\\":\\"no\\",\\"hide_post_title_products\\":\\"no\\",\\"unlink_post_title_products\\":\\"no\\",\\"hide_price_products\\":\\"no\\",\\"hide_add_to_cart_products\\":\\"no\\",\\"hide_rating_products\\":\\"no\\",\\"hide_sales_badge\\":\\"no\\",\\"hide_page_nav_products\\":\\"yes\\"}}],\\"styling\\":{\\"background_type\\":\\"image\\",\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_repeat\\":\\"repeat-none\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"left-top\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top_unit\\":\\"%\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\"}}],\\"styling\\":{\\"background_type\\":\\"image\\",\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_repeat\\":\\"repeat-none\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"right-top\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"row_width\\":\\"fullwidth\\"}},{\\"element_id\\":\\"fd63626\\",\\"cols\\":[{\\"element_id\\":\\"6dc0d95\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"8b8db08\\",\\"mod_settings\\":{\\"background_image-type\\":\\"image\\",\\"background_repeat\\":\\"repeat\\",\\"background_position\\":\\"left-top\\",\\"font_color_type\\":\\"font_color_solid\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"border-type\\":\\"top\\",\\"checkbox_title_margin_apply_all\\":\\"1\\",\\"checkbox_i_t_p_apply_all\\":\\"1\\",\\"checkbox_i_t_m_apply_all\\":\\"1\\",\\"i_t_b-type\\":\\"top\\",\\"checkbox_c_p_apply_all\\":\\"1\\",\\"style_image\\":\\"image-center\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-sport\\\\/files\\\\/2021\\\\/03\\\\/skater-image-02.png\\",\\"width_image\\":\\"800\\",\\"auto_fullwidth\\":\\"1\\",\\"link_image\\":\\"https:\\\\/\\\\/www.youtube.com\\\\/watch?v=nFdVOdP9UGU\\",\\"param_image\\":\\"lightbox\\",\\"lightbox_width_unit\\":\\"%\\",\\"lightbox_height_unit\\":\\"%\\",\\"image_zoom_icon\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false}}]},{\\"element_id\\":\\"008381c\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"fancy-heading\\",\\"element_id\\":\\"a26e8c5\\",\\"mod_settings\\":{\\"background_image-type\\":\\"image\\",\\"background_image-gradient-angle\\":\\"0\\",\\"background_repeat\\":\\"no-repeat\\",\\"padding_top_unit\\":\\"em\\",\\"padding_bottom_unit\\":\\"em\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"margin_top\\":\\"2\\",\\"margin_top_unit\\":\\"em\\",\\"margin_bottom\\":\\"1\\",\\"margin_bottom_unit\\":\\"em\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"heading\\":\\"Testimonial\\",\\"heading_tag\\":\\"h2\\",\\"text_alignment\\":\\"themify-text-center\\"}},{\\"mod_name\\":\\"testimonial-slider\\",\\"element_id\\":\\"ed701e9\\",\\"mod_settings\\":{\\"font_size\\":\\"1.2\\",\\"font_size_unit\\":\\"em\\",\\"line_height\\":\\"1.5\\",\\"line_height_unit\\":\\"em\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"layout_testimonial\\":\\"image-top\\",\\"tab_content_testimonial\\":[{\\"content_testimonial\\":\\"<p>The best sport shop, I can find the board I need for the next competition, and they delivered free. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam<\\\\/p>\\",\\"person_name_testimonial\\":\\"Tony Eagle\\"},{\\"content_testimonial\\":\\"<p>Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?<\\\\/p>\\",\\"person_name_testimonial\\":\\"Bam Blomqvist\\"},{\\"content_testimonial\\":\\"<p>Vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate<\\\\/p>\\",\\"person_name_testimonial\\":\\"Jonathan Exo\\"}],\\"visible_opt_slider\\":\\"1\\",\\"auto_scroll_opt_slider\\":\\"off\\",\\"scroll_opt_slider\\":\\"1\\",\\"speed_opt_slider\\":\\"normal\\",\\"effect_slider\\":\\"scroll\\",\\"pause_on_hover_slider\\":\\"resume\\",\\"wrap_slider\\":\\"yes\\",\\"show_nav_slider\\":\\"yes\\",\\"show_arrow_slider\\":\\"no\\",\\"height_slider\\":\\"variable\\"}}],\\"styling\\":{\\"background_type\\":\\"image\\",\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-sport\\\\/files\\\\/2021\\\\/03\\\\/number-04.png\\",\\"background_repeat\\":\\"repeat-none\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"50,0\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"5\\",\\"padding_top_unit\\":\\"%\\",\\"padding_right\\":\\"5\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left\\":\\"5\\",\\"padding_left_unit\\":\\"%\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"background_zoom\\":false,\\"background_slider_speed\\":\\"2000\\"}}],\\"column_alignment\\":\\"col_align_middle\\",\\"styling\\":{\\"background_type\\":\\"image\\",\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_repeat\\":\\"repeat\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"center-center\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"row_width\\":\\"fullwidth-content\\"}},{\\"element_id\\":\\"a082b49\\",\\"cols\\":[{\\"element_id\\":\\"4109d21\\",\\"grid_class\\":\\"col4-1\\"},{\\"element_id\\":\\"b4dbae3\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"b408da8\\",\\"mod_settings\\":{\\"background_image-type\\":\\"image\\",\\"background_repeat\\":\\"repeat\\",\\"font_color\\":\\"#ffffff\\",\\"font_size\\":\\"1.3\\",\\"font_size_unit\\":\\"em\\",\\"text_align\\":\\"center\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"margin_bottom\\":\\"1\\",\\"margin_bottom_unit\\":\\"em\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"content_text\\":\\"<h4>Free Delivery<\\\\/h4>\\\\n<p>Free delivery over $50 orders<\\\\/p>\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"60e5bac\\",\\"mod_settings\\":{\\"background_image-type\\":\\"image\\",\\"background_repeat\\":\\"repeat\\",\\"text_align\\":\\"center\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"button_background_color\\":\\"#ec2e81\\",\\"link_color\\":\\"#ffffff\\",\\"checkbox_padding_link_apply_all\\":\\"1\\",\\"checkbox_link_margin_apply_all\\":\\"1\\",\\"checkbox_link_border_apply_all\\":\\"1\\",\\"buttons_size\\":\\"normal\\",\\"display\\":\\"buttons-horizontal\\",\\"content_button\\":[{\\"label\\":\\"Shop Now\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-sport\\\\/shop\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"icon_alignment\\":\\"left\\",\\"button_color_bg\\":\\"tb_default_color\\"}],\\"buttons_shape\\":\\"normal\\"}}]},{\\"element_id\\":\\"ecb5247\\",\\"grid_class\\":\\"col4-1\\"}],\\"styling\\":{\\"background_type\\":\\"image\\",\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-sport\\\\/files\\\\/2021\\\\/03\\\\/bg-free-delivery-05.jpg\\",\\"background_repeat\\":\\"builder-parallax-scrolling\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"50,0\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"10\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"10\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"row_width\\":\\"fullwidth-content\\",\\"background_zoom\\":false,\\"background_slider_speed\\":\\"2000\\"}},{\\"element_id\\":\\"e10fa57\\",\\"cols\\":[{\\"element_id\\":\\"dcf6b4a\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"fancy-heading\\",\\"element_id\\":\\"d6feadc\\",\\"mod_settings\\":{\\"background_image-type\\":\\"image\\",\\"background_image-gradient-angle\\":\\"0\\",\\"background_repeat\\":\\"no-repeat\\",\\"padding_top_unit\\":\\"em\\",\\"padding_bottom_unit\\":\\"em\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"margin_top_unit\\":\\"em\\",\\"margin_bottom\\":\\"2\\",\\"margin_bottom_unit\\":\\"em\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"heading\\":\\"Latest News\\",\\"heading_tag\\":\\"h2\\",\\"text_alignment\\":\\"themify-text-center\\"}},{\\"mod_name\\":\\"post\\",\\"element_id\\":\\"cca9578\\",\\"mod_settings\\":{\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"layout_post\\":\\"grid4\\",\\"post_type_post\\":\\"post\\",\\"content_layout\\":\\"boxed\\",\\"masonry_post\\":\\"yes\\",\\"type_query_post\\":\\"category\\",\\"category_post\\":\\"0|single\\",\\"post_tag_post\\":\\"0|multiple\\",\\"product_cat_post\\":\\"0|multiple\\",\\"product_tag_post\\":\\"0|multiple\\",\\"product_shipping_class_post\\":\\"0|multiple\\",\\"post_per_page_post\\":\\"4\\",\\"order_post\\":\\"desc\\",\\"orderby_post\\":\\"date\\",\\"display_post\\":\\"none\\",\\"img_width_post\\":\\"270\\",\\"img_height_post\\":\\"180\\",\\"hide_post_date_post\\":\\"no\\",\\"hide_post_meta_post\\":\\"no\\",\\"hide_page_nav_post\\":\\"yes\\",\\"unlink_post_title_post\\":\\"no\\",\\"hide_post_title_post\\":\\"no\\",\\"unlink_feat_img_post\\":\\"no\\",\\"auto_fullwidth_post\\":false,\\"hide_feat_img_post\\":\\"no\\",\\"post_filter\\":\\"no\\",\\"post_content_layout\\":\\"boxed\\",\\"sticky_post\\":\\"no\\",\\"term_type\\":\\"category\\"}}]}],\\"styling\\":{\\"background_type\\":\\"image\\",\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-sport\\\\/files\\\\/2021\\\\/03\\\\/number-06.png\\",\\"background_repeat\\":\\"repeat-none\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"50,0\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"5\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"5\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"background_zoom\\":false,\\"background_slider_speed\\":\\"2000\\"}}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 32,
  'post_date' => '2018-05-11 06:15:45',
  'post_date_gmt' => '2018-05-11 06:15:45',
  'post_content' => 'Perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.',
  'post_title' => 'Bob Marley Bamboo',
  'post_excerpt' => 'Beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores.',
  'post_name' => 'bob-marley-bamboo',
  'post_modified' => '2021-03-30 19:03:17',
  'post_modified_gmt' => '2021-03-30 19:03:17',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-sport/?post_type=product&#038;p=63',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_wc_review_count' => '0',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_edit_lock' => '1617131399:2',
    '_edit_last' => '2',
    '_thumbnail_id' => '64',
    '_regular_price' => '122',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_upsell_ids' => 
    array (
    ),
    '_crosssell_ids' => 
    array (
    ),
    '_default_attributes' => 
    array (
    ),
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_product_version' => '4.9.0',
    '_price' => '122',
    '_yoast_wpseo_primary_product_cat' => '16',
    '_yoast_wpseo_content_score' => '30',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"zgi4368\\",\\"cols\\":[{\\"element_id\\":\\"3icu368\\",\\"grid_class\\":\\"col-full\\"}]}]',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'skateboard',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard9.png',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 33,
  'post_date' => '2018-05-10 06:17:33',
  'post_date_gmt' => '2018-05-10 06:17:33',
  'post_content' => 'Inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur.',
  'post_title' => 'Robo Monster Chaos',
  'post_excerpt' => 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.',
  'post_name' => 'robo-monster-chaos',
  'post_modified' => '2021-03-30 07:09:25',
  'post_modified_gmt' => '2021-03-30 07:09:25',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-sport/?post_type=product&#038;p=73',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_wc_review_count' => '0',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_edit_lock' => '1526020287:172',
    '_edit_last' => '172',
    'content_width' => 'default_width',
    '_thumbnail_id' => '65',
    'post_image' => 'https://themify.me/demo/themes/shoppe-sport/files/2018/05/skateboard8.png',
    '_wp_old_date' => '2018-05-11',
    '_regular_price' => '225',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_upsell_ids' => 
    array (
    ),
    '_crosssell_ids' => 
    array (
    ),
    '_default_attributes' => 
    array (
    ),
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_product_version' => '3.3.5',
    '_price' => '225',
    '_yoast_wpseo_primary_product_cat' => '16',
    '_yoast_wpseo_content_score' => '30',
    '_themify_builder_settings_json' => '[{\\"cols\\":[{\\"grid_class\\":\\"col-full\\",\\"element_id\\":\\"tf4a400\\"}],\\"element_id\\":\\"1ipj470\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'skateboard',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard8.png',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 34,
  'post_date' => '2018-05-09 06:20:44',
  'post_date_gmt' => '2018-05-09 06:20:44',
  'post_content' => 'Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus. Et quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus omnis.',
  'post_title' => 'Kryptonics Board',
  'post_excerpt' => 'Et quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi.',
  'post_name' => 'kryptonics-board',
  'post_modified' => '2021-03-30 18:50:08',
  'post_modified_gmt' => '2021-03-30 18:50:08',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-sport/?post_type=product&#038;p=74',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_wc_review_count' => '0',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_edit_lock' => '1526375967:172',
    '_edit_last' => '172',
    'content_width' => 'default_width',
    'post_image' => 'https://themify.me/demo/themes/shoppe-sport/files/2018/05/skateboard7-1.png',
    '_regular_price' => '125',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_upsell_ids' => 
    array (
    ),
    '_crosssell_ids' => 
    array (
    ),
    '_default_attributes' => 
    array (
    ),
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_product_version' => '3.3.5',
    '_price' => '125',
    '_yoast_wpseo_primary_product_cat' => '16',
    '_yoast_wpseo_content_score' => '30',
    '_wp_old_date' => '2018-05-11',
    '_thumbnail_id' => '66',
    '_themify_builder_settings_json' => '[{\\"cols\\":[{\\"grid_class\\":\\"col-full\\",\\"element_id\\":\\"0xxp000\\"}],\\"element_id\\":\\"xokl942\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'skateboard',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard7-1.png',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 35,
  'post_date' => '2018-05-08 06:21:19',
  'post_date_gmt' => '2018-05-08 06:21:19',
  'post_content' => 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.',
  'post_title' => 'Ethnic Wood',
  'post_excerpt' => 'Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.',
  'post_name' => 'ethnic-wood',
  'post_modified' => '2021-03-30 18:53:18',
  'post_modified_gmt' => '2021-03-30 18:53:18',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-sport/?post_type=product&#038;p=75',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_wc_review_count' => '0',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_edit_lock' => '1526020287:172',
    '_edit_last' => '172',
    'content_width' => 'default_width',
    '_thumbnail_id' => '67',
    'post_image' => 'https://themify.me/demo/themes/shoppe-sport/files/2018/05/skateboard6.png',
    '_wp_old_date' => '2018-05-11',
    '_regular_price' => '250',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_upsell_ids' => 
    array (
    ),
    '_crosssell_ids' => 
    array (
    ),
    '_default_attributes' => 
    array (
    ),
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_product_version' => '3.3.5',
    '_price' => '250',
    '_yoast_wpseo_primary_product_cat' => '16',
    '_yoast_wpseo_content_score' => '30',
    '_themify_builder_settings_json' => '[{\\"cols\\":[{\\"grid_class\\":\\"col-full\\",\\"element_id\\":\\"0jpy705\\"}],\\"element_id\\":\\"xsm6508\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'skateboard',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard6.png',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 36,
  'post_date' => '2018-05-07 06:23:07',
  'post_date_gmt' => '2018-05-07 06:23:07',
  'post_content' => 'Ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.',
  'post_title' => 'Hero Clown',
  'post_excerpt' => 'Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia.',
  'post_name' => 'hero-clown',
  'post_modified' => '2021-04-03 01:39:11',
  'post_modified_gmt' => '2021-04-03 01:39:11',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-sport/?post_type=product&#038;p=76',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_wc_review_count' => '0',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_edit_lock' => '1526019711:172',
    '_edit_last' => '172',
    'content_width' => 'default_width',
    '_thumbnail_id' => '68',
    'post_image' => 'https://themify.me/demo/themes/shoppe-sport/files/2018/05/skateboard5.png',
    '_wp_old_date' => '2018-05-11',
    '_regular_price' => '275',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_upsell_ids' => 
    array (
    ),
    '_crosssell_ids' => 
    array (
    ),
    '_default_attributes' => 
    array (
    ),
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_product_version' => '3.3.5',
    '_price' => '275',
    '_yoast_wpseo_primary_product_cat' => '16',
    '_yoast_wpseo_content_score' => '30',
    '_themify_builder_settings_json' => '[{\\"cols\\":[{\\"grid_class\\":\\"col-full\\",\\"element_id\\":\\"0ksd321\\"}],\\"element_id\\":\\"p4wx033\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'skateboard',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard5.png',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 37,
  'post_date' => '2018-05-06 06:25:27',
  'post_date_gmt' => '2018-05-06 06:25:27',
  'post_content' => 'Laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit ess. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.',
  'post_title' => 'Futurio Board V1',
  'post_excerpt' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.',
  'post_name' => 'futurio-board-v1',
  'post_modified' => '2021-04-03 01:39:30',
  'post_modified_gmt' => '2021-04-03 01:39:30',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-sport/?post_type=product&#038;p=77',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_wc_review_count' => '0',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_edit_lock' => '1526019956:172',
    '_edit_last' => '172',
    'content_width' => 'default_width',
    '_thumbnail_id' => '69',
    'post_image' => 'https://themify.me/demo/themes/shoppe-sport/files/2018/05/skateboard4.png',
    '_regular_price' => '345',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_upsell_ids' => 
    array (
    ),
    '_crosssell_ids' => 
    array (
    ),
    '_default_attributes' => 
    array (
    ),
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_product_version' => '3.3.5',
    '_price' => '345',
    '_yoast_wpseo_primary_product_cat' => '16',
    '_yoast_wpseo_content_score' => '30',
    '_wp_old_date' => '2018-05-11',
    '_wp_attachment_metadata' => 
    array (
      'width' => 800,
      'height' => 772,
      'file' => '2018/05/skater-image-02-1024x989-800x772.png',
      'sizes' => 
      array (
        'resized-800x772' => 
        array (
          'file' => 'skater-image-02-1024x989-800x772-800x772.png',
          'width' => 800,
          'height' => 772,
          'mime-type' => 'image/png',
        ),
      ),
    ),
    '_themify_builder_settings_json' => '[{\\"cols\\":[{\\"grid_class\\":\\"col-full\\",\\"element_id\\":\\"0u7i056\\"}],\\"element_id\\":\\"zs3m640\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'skateboard',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard4.png',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 38,
  'post_date' => '2018-05-05 06:25:56',
  'post_date_gmt' => '2018-05-05 06:25:56',
  'post_content' => 'Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur? Vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate',
  'post_title' => 'Angry Orange',
  'post_excerpt' => 'Vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti',
  'post_name' => 'angry-orange',
  'post_modified' => '2021-03-30 18:50:42',
  'post_modified_gmt' => '2021-03-30 18:50:42',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-sport/?post_type=product&#038;p=78',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_wc_review_count' => '0',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_edit_lock' => '1526019899:172',
    '_edit_last' => '172',
    'content_width' => 'default_width',
    '_thumbnail_id' => '70',
    'post_image' => 'https://themify.me/demo/themes/shoppe-sport/files/2018/05/skateboard3.png',
    '_wp_old_date' => '2018-05-11',
    '_regular_price' => '156',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_upsell_ids' => 
    array (
    ),
    '_crosssell_ids' => 
    array (
    ),
    '_default_attributes' => 
    array (
    ),
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_product_version' => '3.3.5',
    '_price' => '156',
    '_yoast_wpseo_primary_product_cat' => '16',
    '_yoast_wpseo_content_score' => '30',
    '_themify_builder_settings_json' => '[{\\"cols\\":[{\\"grid_class\\":\\"col-full\\",\\"element_id\\":\\"r5ch600\\"}],\\"element_id\\":\\"flv3003\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'skateboard',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard3.png',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 39,
  'post_date' => '2018-05-04 06:28:26',
  'post_date_gmt' => '2018-05-04 06:28:26',
  'post_content' => 'Commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur.',
  'post_title' => 'TMNT Purple',
  'post_excerpt' => 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est.',
  'post_name' => 'tmnt-purple',
  'post_modified' => '2021-04-03 01:40:00',
  'post_modified_gmt' => '2021-04-03 01:40:00',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-sport/?post_type=product&#038;p=80',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_wc_review_count' => '0',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_edit_lock' => '1526020167:172',
    '_edit_last' => '172',
    'content_width' => 'default_width',
    '_thumbnail_id' => '71',
    'post_image' => 'https://themify.me/demo/themes/shoppe-sport/files/2018/05/skateboard1.png',
    '_wp_old_date' => '2018-05-11',
    '_regular_price' => '123',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_upsell_ids' => 
    array (
    ),
    '_crosssell_ids' => 
    array (
    ),
    '_default_attributes' => 
    array (
    ),
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_product_version' => '3.3.5',
    '_price' => '123',
    '_yoast_wpseo_primary_product_cat' => '16',
    '_yoast_wpseo_content_score' => '30',
    '_themify_builder_settings_json' => '[{\\"cols\\":[{\\"grid_class\\":\\"col-full\\",\\"element_id\\":\\"yrf9434\\"}],\\"element_id\\":\\"nuii224\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'skateboard',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard1.png',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 40,
  'post_date' => '2018-05-04 06:27:23',
  'post_date_gmt' => '2018-05-04 06:27:23',
  'post_content' => 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est. Laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
  'post_title' => 'UK Flag',
  'post_excerpt' => 'Laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit',
  'post_name' => 'uk-flag',
  'post_modified' => '2021-04-03 01:39:36',
  'post_modified_gmt' => '2021-04-03 01:39:36',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-sport/?post_type=product&#038;p=79',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_wc_review_count' => '0',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_edit_lock' => '1526019967:172',
    '_edit_last' => '172',
    'content_width' => 'default_width',
    '_thumbnail_id' => '72',
    'post_image' => 'https://themify.me/demo/themes/shoppe-sport/files/2018/05/skateboard2.png',
    '_wp_old_date' => '2018-05-11',
    '_regular_price' => '145',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_upsell_ids' => 
    array (
    ),
    '_crosssell_ids' => 
    array (
    ),
    '_default_attributes' => 
    array (
    ),
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_product_version' => '3.3.5',
    '_price' => '145',
    '_yoast_wpseo_primary_product_cat' => '16',
    '_yoast_wpseo_content_score' => '30',
    '_themify_builder_settings_json' => '[{\\"cols\\":[{\\"grid_class\\":\\"col-full\\",\\"element_id\\":\\"heke707\\"}],\\"element_id\\":\\"u921701\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'skateboard',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-sport/files/2021/03/skateboard2.png',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 41,
  'post_date' => '2018-05-13 02:58:53',
  'post_date_gmt' => '2018-05-13 02:58:53',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '198',
  'post_modified' => '2021-03-30 05:47:37',
  'post_modified_gmt' => '2021-03-30 05:47:37',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-sport/?p=198',
  'menu_order' => 1,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '28',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 101,
  'post_date' => '2021-03-30 05:47:37',
  'post_date_gmt' => '2021-03-30 05:47:37',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '101',
  'post_modified' => '2021-03-30 05:47:37',
  'post_modified_gmt' => '2021-03-30 05:47:37',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-sport/?p=101',
  'menu_order' => 2,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => 'shop',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 43,
  'post_date' => '2018-05-13 02:58:53',
  'post_date_gmt' => '2018-05-13 02:58:53',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '196',
  'post_modified' => '2021-03-30 05:47:37',
  'post_modified_gmt' => '2021-03-30 05:47:37',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-sport/?p=196',
  'menu_order' => 3,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '23',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 44,
  'post_date' => '2018-05-13 02:58:53',
  'post_date_gmt' => '2018-05-13 02:58:53',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '197',
  'post_modified' => '2021-03-30 05:47:37',
  'post_modified_gmt' => '2021-03-30 05:47:37',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-sport/?p=197',
  'menu_order' => 4,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '24',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 45,
  'post_date' => '2018-05-13 02:58:53',
  'post_date_gmt' => '2018-05-13 02:58:53',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '195',
  'post_modified' => '2021-03-30 05:47:37',
  'post_modified_gmt' => '2021-03-30 05:47:37',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-sport/?p=195',
  'menu_order' => 5,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '27',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 113,
  'post_date' => '2021-03-30 05:56:01',
  'post_date_gmt' => '2021-03-30 05:56:01',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '113',
  'post_modified' => '2021-03-30 07:00:34',
  'post_modified_gmt' => '2021-03-30 07:00:34',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-sport/?p=113',
  'menu_order' => 1,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => 'shop',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'my-account-menu',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 112,
  'post_date' => '2021-03-30 05:56:01',
  'post_date_gmt' => '2021-03-30 05:56:01',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '112',
  'post_modified' => '2021-03-30 07:00:34',
  'post_modified_gmt' => '2021-03-30 07:00:34',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-sport/?p=112',
  'menu_order' => 2,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => 'myaccount',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'my-account-menu',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 111,
  'post_date' => '2021-03-30 05:56:01',
  'post_date_gmt' => '2021-03-30 05:56:01',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '111',
  'post_modified' => '2021-03-30 07:00:34',
  'post_modified_gmt' => '2021-03-30 07:00:34',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-sport/?p=111',
  'menu_order' => 3,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => 'checkout',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'my-account-menu',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 110,
  'post_date' => '2021-03-30 05:56:01',
  'post_date_gmt' => '2021-03-30 05:56:01',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '110',
  'post_modified' => '2021-03-30 07:00:34',
  'post_modified_gmt' => '2021-03-30 07:00:34',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-sport/?p=110',
  'menu_order' => 4,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => 'cart',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'my-account-menu',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$widgets = get_option( "widget_nav_menu" );
$widgets[1002] = array (
  'title' => 'Shop Links',
  'nav_menu' => Themify_Import_Helper::get_term_id_by_slug( "my-account-menu", "nav_menu" ),
  'tf_search_ajax' => '',
);
update_option( "widget_nav_menu", $widgets );

$widgets = get_option( "widget_nav_menu" );
$widgets[1003] = array (
  'title' => 'Main Menu',
  'nav_menu' => Themify_Import_Helper::get_term_id_by_slug( "main-navigation", "nav_menu" ),
);
update_option( "widget_nav_menu", $widgets );

$widgets = get_option( "widget_text" );
$widgets[1004] = array (
  'title' => 'Contact',
  'text' => 'Contact us: +1 423-344-4409
<a href="#">noreply@domain.com</a>

288 Fifth Avenue
Toronto, Ontario',
  'filter' => true,
  'visual' => true,
);
update_option( "widget_text", $widgets );

$widgets = get_option( "widget_themify-feature-posts" );
$widgets[1005] = array (
  'title' => 'Recent Posts',
  'category' => '0',
  'show_count' => '5',
  'show_date' => NULL,
  'show_thumb' => NULL,
  'display' => 'none',
  'hide_title' => NULL,
  'thumb_width' => '50',
  'thumb_height' => '50',
  'excerpt_length' => '55',
  'orderby' => 'date',
  'order' => 'DESC',
);
update_option( "widget_themify-feature-posts", $widgets );

$widgets = get_option( "widget_themify-social-links" );
$widgets[1006] = array (
  'title' => '',
  'show_link_name' => NULL,
  'open_new_window' => NULL,
  'icon_size' => 'icon-medium',
  'orientation' => 'horizontal',
);
update_option( "widget_themify-social-links", $widgets );



$sidebars_widgets = array (
  'footer-widget-1' => 
  array (
    0 => 'nav_menu-1002',
  ),
  'footer-widget-2' => 
  array (
    0 => 'nav_menu-1003',
  ),
  'footer-widget-3' => 
  array (
    0 => 'text-1004',
  ),
  'sidebar-main' => 
  array (
    0 => 'themify-feature-posts-1005',
  ),
  'footer-social-widget' => 
  array (
    0 => 'themify-social-links-1006',
  ),
); 
update_option( "sidebars_widgets", $sidebars_widgets );

$homepage = get_posts( array( 'name' => 'home', 'post_type' => 'page' ) );
			if( is_array( $homepage ) && ! empty( $homepage ) ) {
				update_option( 'show_on_front', 'page' );
				update_option( 'page_on_front', $homepage[0]->ID );
			}
			$themify_data = array (
  'setting-search_post_type' => 'all',
  'setting-webfonts_list' => 'recommended',
  'setting-lazy-blur' => '25',
  'setting-cache-live' => '10080',
  'setting-default_layout' => 'sidebar-none',
  'setting-default_post_layout' => 'grid4',
  'setting-post_filter' => 'no',
  'setting-disable_masonry' => 'yes',
  'setting-post_gutter' => 'gutter',
  'setting-default_layout_display' => 'content',
  'setting-default_more_text' => 'More',
  'setting-index_orderby' => 'date',
  'setting-index_order' => 'DESC',
  'setting-default_media_position' => 'above',
  'setting-image_post_feature_size' => 'blank',
  'setting-default_page_post_layout' => 'sidebar-none',
  'setting-default_page_post_layout_type' => 'classic',
  'setting-default_page_single_media_position' => 'above',
  'setting-image_post_single_feature_size' => 'blank',
  'setting-search-result_layout' => 'sidebar-none',
  'setting-search-result_post_layout' => 'list-post',
  'setting-search-result_layout_display' => 'excerpt',
  'setting-search-result_post_meta' => 'yes',
  'setting-search-result_media_position' => 'above',
  'setting-default_page_layout' => 'sidebar-none',
  'setting-default_portfolio_index_layout' => 'sidebar-none',
  'setting-default_portfolio_index_post_layout' => 'grid3',
  'setting-portfolio_post_filter' => 'yes',
  'setting-portfolio_disable_masonry' => 'yes',
  'setting-portfolio_gutter' => 'gutter',
  'setting-default_portfolio_index_display' => 'none',
  'setting-default_portfolio_single_layout' => 'sidebar-none',
  'setting-default_portfolio_single_portfolio_layout_type' => 'fullwidth',
  'themify_portfolio_slug' => 'project',
  'themify_portfolio_category_slug' => 'portfolio-category',
  'setting-shop_layout' => 'sidebar-none',
  'setting-shop_archive_layout' => 'sidebar-none',
  'setting-products_layout' => 'grid3',
  'setting-product_disable_masonry' => 'yes',
  'setting-product_hover_image' => 'on',
  'setting-shop_products_per_page' => '6',
  'setting-product_shop_image_size' => 'custom',
  'setting-default_product_index_image_post_width' => '370',
  'setting-default_product_index_image_post_height' => '488',
  'setting-single_product_layout' => 'sidebar-none',
  'setting-product_single_image_size' => 'woocommerce',
  'setting-related_products_limit' => '3',
  'setting-product_description_type' => 'long',
  'setting-cart_show_seconds' => '1000',
  'setting-customizer_responsive_design_tablet_landscape' => '1280',
  'setting-customizer_responsive_design_tablet' => '768',
  'setting-customizer_responsive_design_mobile' => '680',
  'setting-mobile_menu_trigger_point' => '900',
  'setting-header_design' => 'header-horizontal',
  'setting-exclude_site_tagline' => 'on',
  'setting_search_form' => 'live_search',
  'setting-header_widgets' => 'headerwidget-3col',
  'setting-footer_design' => 'footer-left-col',
  'setting-use_float_back' => 'on',
  'setting-footer_widgets' => 'footerwidget-3col',
  'setting-footer_widget_position' => 'top',
  'setting-mega_menu_posts' => '5',
  'setting-mega_menu_image_width' => '180',
  'setting-mega_menu_image_height' => '120',
  'setting-mega_menu_post_count' => 'off',
  'setting-color_animation_speed' => '5',
  'setting-relationship_taxonomy' => 'category',
  'setting-relationship_taxonomy_entries' => '3',
  'setting-relationship_taxonomy_display_content' => 'none',
  'setting-single_slider_autoplay' => 'off',
  'setting-single_slider_speed' => 'normal',
  'setting-single_slider_effect' => 'slide',
  'setting-single_slider_height' => 'auto',
  'setting-more_posts' => 'pagination',
  'setting-entries_nav' => 'numbered',
  'setting-gallery_lightbox' => 'lightbox',
  'setting-img_php_base_size' => 'large',
  'setting-global_feature_size' => 'blank',
  'setting-link_icon_type' => 'font-icon',
  'setting-link_type_themify-link-0' => 'image-icon',
  'setting-link_title_themify-link-0' => 'Twitter',
  'setting-link_img_themify-link-0' => 'https://themify.me/demo/themes/shoppe-sport/wp-content/themes/themify-shoppe/themify/img/social/twitter.png',
  'setting-link_type_themify-link-1' => 'image-icon',
  'setting-link_title_themify-link-1' => 'Facebook',
  'setting-link_img_themify-link-1' => 'https://themify.me/demo/themes/shoppe-sport/wp-content/themes/themify-shoppe/themify/img/social/facebook.png',
  'setting-link_type_themify-link-2' => 'image-icon',
  'setting-link_title_themify-link-2' => 'Google+',
  'setting-link_img_themify-link-2' => 'https://themify.me/demo/themes/shoppe-sport/wp-content/themes/themify-shoppe/themify/img/social/google-plus.png',
  'setting-link_type_themify-link-3' => 'image-icon',
  'setting-link_title_themify-link-3' => 'YouTube',
  'setting-link_img_themify-link-3' => 'https://themify.me/demo/themes/shoppe-sport/wp-content/themes/themify-shoppe/themify/img/social/youtube.png',
  'setting-link_type_themify-link-4' => 'image-icon',
  'setting-link_title_themify-link-4' => 'Pinterest',
  'setting-link_img_themify-link-4' => 'https://themify.me/demo/themes/shoppe-sport/wp-content/themes/themify-shoppe/themify/img/social/pinterest.png',
  'setting-link_type_themify-link-6' => 'font-icon',
  'setting-link_title_themify-link-6' => 'Facebook',
  'setting-link_link_themify-link-6' => 'https://www.facebook.com/themify',
  'setting-link_ficon_themify-link-6' => 'fa-facebook',
  'setting-link_ficolor_themify-link-6' => '#ec2e81',
  'setting-link_type_themify-link-5' => 'font-icon',
  'setting-link_title_themify-link-5' => 'Twitter',
  'setting-link_link_themify-link-5' => 'https://twitter.com/themify',
  'setting-link_ficon_themify-link-5' => 'fa-twitter',
  'setting-link_ficolor_themify-link-5' => '#ec2e81',
  'setting-link_type_themify-link-8' => 'font-icon',
  'setting-link_title_themify-link-8' => 'Linkedin',
  'setting-link_link_themify-link-8' => 'https://www.linkedin.com/company/themify/',
  'setting-link_ficon_themify-link-8' => 'ti-linkedin',
  'setting-link_ficolor_themify-link-8' => '#ec2e81',
  'setting-link_type_themify-link-7' => 'font-icon',
  'setting-link_title_themify-link-7' => 'Google+',
  'setting-link_link_themify-link-7' => 'https://plus.google.com/109280316400365629341',
  'setting-link_ficon_themify-link-7' => 'fa-google-plus',
  'setting-link_ficolor_themify-link-7' => '#ec2e81',
  'setting-link_field_ids' => '{"themify-link-0":"themify-link-0","themify-link-1":"themify-link-1","themify-link-2":"themify-link-2","themify-link-3":"themify-link-3","themify-link-4":"themify-link-4","themify-link-6":"themify-link-6","themify-link-5":"themify-link-5","themify-link-8":"themify-link-8","themify-link-7":"themify-link-7"}',
  'setting-link_field_hash' => '10',
  'setting-page_builder_is_active' => 'enable',
  'setting-page_builder_animation_appearance' => 'none',
  'setting-page_builder_animation_parallax_bg' => 'none',
  'setting-page_builder_animation_scroll_effect' => 'none',
  'setting-page_builder_animation_sticky_scroll' => 'none',
  'skin' => 'sport',
  'import_images' => 'on',
);
themify_set_data( $themify_data );
$theme = get_option( 'stylesheet' );
$theme_mods = array (
  0 => false,
  'custom_css_post_id' => -1,
  'footerwrap_background' => '{"id":108,"src":"https://themify.me/demo/themes/ultra-sport/files/2021/03/ultra-sport-footer-bg.jpg","style":"fullcover"}',
);
update_option( "theme_mods_{$theme}", $theme_mods );
$menu_locations = array();
$menu = get_terms( "nav_menu", array( "slug" => "main-navigation" ) );
if( is_array( $menu ) && ! empty( $menu ) ) $menu_locations["main-nav"] = $menu[0]->term_id;
set_theme_mod( "nav_menu_locations", $menu_locations );



}
