<?php

function themify_do_demo_import() {
$term = array (
  'term_id' => 2,
  'name' => 'Main Navigation',
  'slug' => 'main-navigation',
  'term_group' => 0,
  'taxonomy' => 'nav_menu',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 3,
  'name' => 'simple',
  'slug' => 'simple',
  'term_group' => 0,
  'taxonomy' => 'product_type',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 17,
  'name' => 'Hair Treatment',
  'slug' => 'hair-treatment',
  'term_group' => 0,
  'taxonomy' => 'product_cat',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 18,
  'name' => 'Hair Vitamin',
  'slug' => 'hair-vitamin',
  'term_group' => 0,
  'taxonomy' => 'product_cat',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 19,
  'name' => 'Styling Gel',
  'slug' => 'styling-gel',
  'term_group' => 0,
  'taxonomy' => 'product_cat',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 20,
  'name' => 'Beard Oil',
  'slug' => 'beard-oil',
  'term_group' => 0,
  'taxonomy' => 'product_cat',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$post = array (
  'ID' => 76,
  'post_date' => '2021-04-21 09:41:36',
  'post_date_gmt' => '2021-04-21 09:41:36',
  'post_content' => '<!-- wp:themify-builder/canvas /--><!--themify_builder_static--><h1>About Ultra Salon</h1> <p>Found in 2010, we\'ve been providing salon &amp; spa services to more than 20k happy customers.</p>
<img loading="lazy" width="1158" height="600" src="https://themify.me/demo/themes/ultra-salon/files/2021/04/about-profile.jpg" title="about-profile" alt="about-profile" srcset="https://themify.me/demo/themes/ultra-salon/files/2021/04/about-profile.jpg 1158w, https://themify.me/demo/themes/ultra-salon/files/2021/04/about-profile-600x311.jpg 600w, https://themify.me/demo/themes/ultra-salon/files/2021/04/about-profile-768x398.jpg 768w" sizes="(max-width: 1158px) 100vw, 1158px" />
<img loading="lazy" width="495" height="600" src="https://themify.me/demo/themes/ultra-salon/files/2021/04/flawless.jpg" title="flawless" alt="flawless">
<h2>Prepare to be pampered at our salon. Freshen yourself with a relaxing salon &amp; spa experience.</h2>
<h3>10+</h3> <p>Years of experience</p>
<ul> <li>Hair cuts</li> <li>Coloring</li> <li>Treatments</li> <li>Make-up</li> </ul>
<h3>20k+</h3> <p>Happy customers</p>
<ul> <li>Beauty spa</li> <li>Facial</li> <li>Nails</li> <li>Barber services</li> </ul>
<h2>Top hair stylists &amp; make-up artists</h2> <p>Our team of stylists and artists are top notch in the field. We listen to your requests, assess your image, and achieve the best look to your desire. Book your appointment now to experience the ultra salon services.</p>
<img loading="lazy" width="267" height="280" src="https://themify.me/demo/themes/ultra-salon/files/2021/04/artist-1.jpg" title="Sandy Isbell" alt="Hair Stylist"> <h3> Sandy Isbell </h3> Hair Stylist
<img loading="lazy" width="267" height="280" src="https://themify.me/demo/themes/ultra-salon/files/2021/04/artist-2.jpg" title="Celine Li" alt="Hair Stylist"> <h3> Celine Li </h3> Hair Stylist
<img loading="lazy" width="267" height="280" src="https://themify.me/demo/themes/ultra-salon/files/2021/04/artist-3.jpg" title="Sara" alt="Makeup Artist"> <h3> Sara </h3> Makeup Artist
<img loading="lazy" width="267" height="280" src="https://themify.me/demo/themes/ultra-salon/files/2021/04/artist-4.jpg" title="Shawn" alt="Barber"> <h3> Shawn </h3> Barber
<h4>BOOK AN APPOINTMENT</h4> <h2>312-234-5789</h2> <p style="color: #494949; font-family: Quicksand, sans-serif; font-size: 16px; font-weight: 400; letter-spacing: normal; text-transform: none;">4096 North Street<br>New York City, NY</p> <p style="color: #494949; font-family: Quicksand, sans-serif; font-size: 16px; font-weight: 400; letter-spacing: normal; text-transform: none;">MON - FRI 11:00 am -  8:00 pm<br>SAT &amp; SUN 11:00 am -  9:00 pm</p>
<form action="https://themify.me/demo/themes/ultra-salon/wp-admin/admin-ajax.php" class="builder-contact" id="tb_592r877-form" method="post" data-post-id="0" data-element-id="592r877" data-orig-id="" > <label for="tb_592r877-contact-name"></label> <input type="text" name="contact-name" placeholder="Enter Name" id="tb_592r877-contact-name" value="" required> <label for="tb_592r877-contact-email"></label> <input type="text" name="contact-email" placeholder="Type e-mail address" id="tb_592r877-contact-email" value="" required> <label for="field_extra_tb_592r877_0"> <input type="hidden" name="field_extra_name_0" value=""> </label> <input type="text" name="field_extra_0" id="field_extra_tb_592r877_0" placeholder="Phone Number"> <label for="tb_592r877-contact-message"></label> <textarea name="contact-message" placeholder="Write a Message" id="tb_592r877-contact-message" required></textarea> <button type="submit">Send Message</button> </form><!--/themify_builder_static-->',
  'post_title' => 'About',
  'post_excerpt' => '',
  'post_name' => 'about',
  'post_modified' => '2021-10-04 20:15:21',
  'post_modified_gmt' => '2021-10-04 20:15:21',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-salon/?page_id=76',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'section_scrolling_mobile' => 'on',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"0xox465\\",\\"cols\\":[{\\"element_id\\":\\"bfue465\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"24go101\\",\\"mod_settings\\":{\\"content_text\\":\\"<h1>About Ultra Salon<\\\\/h1>\\\\n<p>Found in 2010, we\\\'ve been providing salon &amp; spa services to more than 20k happy customers.<\\\\/p>\\"}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"q7uu143\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_tag\\":\\"h3\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-salon\\\\/files\\\\/2021\\\\/04\\\\/about-profile.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"animation_effect\\":\\"fadeInUp\\"}},{\\"element_id\\":\\"6vhp26\\",\\"cols\\":[{\\"element_id\\":\\"dc4827\\",\\"grid_class\\":\\"col-full\\"}]}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"4\\",\\"padding_top\\":\\"8\\"}},{\\"element_id\\":\\"toam475\\",\\"cols\\":[{\\"element_id\\":\\"827n476\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"eze1477\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_tag\\":\\"h3\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-salon\\\\/files\\\\/2021\\\\/04\\\\/flawless.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"20\\",\\"margin_opp_bottom\\":false},\\"motion_effects\\":{\\"v\\":{\\"val\\":{\\"v_dir\\":\\"up\\"}}}}}]},{\\"element_id\\":\\"syao477\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"element_id\\":\\"rfmg477\\",\\"cols\\":[{\\"element_id\\":\\"8rig478\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"u8ox478\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Prepare to be pampered at our salon. Freshen yourself with a relaxing salon &amp; spa experience.<\\\\/h2>\\"}}]}]},{\\"element_id\\":\\"37oh479\\",\\"cols\\":[{\\"element_id\\":\\"x4np479\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"bgyz479\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>10+<\\\\/h3>\\\\n<p>Years of experience<\\\\/p>\\",\\"h3_margin_bottom\\":\\"0\\",\\"font_size_h3\\":\\"80\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"line_height_h3_unit\\":\\"em\\",\\"line_height_h3\\":\\"1\\",\\"margin_bottom\\":\\"10\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"w1ix536\\",\\"mod_settings\\":{\\"content_text\\":\\"<ul>\\\\n<li>Hair cuts<\\\\/li>\\\\n<li>Coloring<\\\\/li>\\\\n<li>Treatments<\\\\/li>\\\\n<li>Make-up<\\\\/li>\\\\n<\\\\/ul>\\"}}]},{\\"element_id\\":\\"r5p7480\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"cswr346\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>20k+<\\\\/h3>\\\\n<p>Happy customers<\\\\/p>\\",\\"h3_margin_bottom\\":\\"0\\",\\"font_size_h3\\":\\"80\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"line_height_h3_unit\\":\\"em\\",\\"line_height_h3\\":\\"1\\",\\"margin_bottom\\":\\"10\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"qvc9175\\",\\"mod_settings\\":{\\"content_text\\":\\"<ul>\\\\n<li>Beauty spa<\\\\/li>\\\\n<li>Facial<\\\\/li>\\\\n<li>Nails<\\\\/li>\\\\n<li>Barber services<\\\\/li>\\\\n<\\\\/ul>\\"}}]}],\\"col_mobile\\":\\"column4-2\\"}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"4\\",\\"padding_top\\":\\"4\\"}},{\\"element_id\\":\\"b2gr561\\",\\"cols\\":[{\\"element_id\\":\\"c8lv563\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"mdwm564\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Top hair stylists &amp; make-up artists<\\\\/h2>\\\\n<p>Our team of stylists and artists are top notch in the field. We listen to your requests, assess your image, and achieve the best look to your desire. <span style=\\\\\\"background-color: initial; font-size: 1em;\\\\\\">Book your appointment now to experience the ultra salon services.<\\\\/span><\\\\/p>\\"}}],\\"styling\\":{\\"padding_right_unit\\":\\"%\\",\\"padding_right\\":\\"6\\",\\"breakpoint_mobile\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_right_unit\\":\\"px\\",\\"padding_right\\":\\"0\\",\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false}}},{\\"element_id\\":\\"lmu8564\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"element_id\\":\\"34s0565\\",\\"cols\\":[{\\"element_id\\":\\"x2r4565\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"n4ws566\\",\\"mod_settings\\":{\\"caption_image\\":\\"Hair Stylist\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Sandy Isbell\\",\\"title_tag\\":\\"h3\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-salon\\\\/files\\\\/2021\\\\/04\\\\/artist-1.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"title_margin_opp_left\\":false,\\"title_margin_opp_bottom\\":false,\\"title_margin_top\\":\\"10\\",\\"font_size_title_unit\\":\\"em\\",\\"font_size_title\\":\\"1.2\\",\\"title_margin_bottom\\":\\"0\\",\\"animation_effect\\":\\"fadeInUp\\"}}]},{\\"element_id\\":\\"akwr566\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"1oub566\\",\\"mod_settings\\":{\\"caption_image\\":\\"Hair Stylist\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Celine Li\\",\\"title_tag\\":\\"h3\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-salon\\\\/files\\\\/2021\\\\/04\\\\/artist-2.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"title_margin_opp_left\\":false,\\"title_margin_opp_bottom\\":false,\\"title_margin_top\\":\\"10\\",\\"font_size_title_unit\\":\\"em\\",\\"font_size_title\\":\\"1.2\\",\\"title_margin_bottom\\":\\"0\\",\\"animation_effect\\":\\"fadeInUp\\"}}]}],\\"col_mobile\\":\\"column4-2\\"},{\\"element_id\\":\\"bnbm567\\",\\"cols\\":[{\\"element_id\\":\\"qsx9567\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"5png567\\",\\"mod_settings\\":{\\"caption_image\\":\\"Makeup Artist\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Sara\\",\\"title_tag\\":\\"h3\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-salon\\\\/files\\\\/2021\\\\/04\\\\/artist-3.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"title_margin_opp_left\\":false,\\"title_margin_opp_bottom\\":false,\\"title_margin_top\\":\\"10\\",\\"font_size_title_unit\\":\\"em\\",\\"font_size_title\\":\\"1.2\\",\\"title_margin_bottom\\":\\"0\\",\\"animation_effect\\":\\"fadeInUp\\"}}]},{\\"element_id\\":\\"duwh568\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"hqvc568\\",\\"mod_settings\\":{\\"caption_image\\":\\"Barber\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Shawn\\",\\"title_tag\\":\\"h3\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-salon\\\\/files\\\\/2021\\\\/04\\\\/artist-4.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"title_margin_opp_left\\":false,\\"title_margin_opp_bottom\\":false,\\"title_margin_top\\":\\"10\\",\\"font_size_title_unit\\":\\"em\\",\\"font_size_title\\":\\"1.2\\",\\"title_margin_bottom\\":\\"0\\",\\"animation_effect\\":\\"fadeInUp\\"}}]}],\\"col_mobile\\":\\"column4-2\\"}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"4\\",\\"padding_opp_bottom\\":\\"1\\",\\"padding_top\\":\\"4\\"}},{\\"element_id\\":\\"gy0z875\\",\\"cols\\":[{\\"element_id\\":\\"2qxr876\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"0u8l876\\",\\"mod_settings\\":{\\"content_text\\":\\"<h4>BOOK AN APPOINTMENT<\\\\/h4>\\\\n<h2>312-234-5789<\\\\/h2>\\\\n<p style=\\\\\\"color: #494949; font-family: Quicksand, sans-serif; font-size: 16px; font-weight: 400; letter-spacing: normal; text-transform: none;\\\\\\">4096 North Street<br>New York City, NY<\\\\/p>\\\\n<p style=\\\\\\"color: #494949; font-family: Quicksand, sans-serif; font-size: 16px; font-weight: 400; letter-spacing: normal; text-transform: none;\\\\\\">MON - FRI 11:00 am -  8:00 pm<br>SAT &amp; SUN 11:00 am -  9:00 pm<\\\\/p>\\",\\"margin_bottom\\":\\"50\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"17\\"}}],\\"styling\\":{\\"padding_left_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_left\\":\\"10\\",\\"padding_top\\":\\"10\\"}},{\\"element_id\\":\\"d8pv876\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"contact\\",\\"element_id\\":\\"592r877\\",\\"mod_settings\\":{\\"field_subject_label\\":\\"Subject\\",\\"field_sendcopy_label\\":\\"Send a copy to myself\\",\\"field_sendcopy_subject\\":\\"COPY:\\",\\"field_send_label\\":\\"Send Message\\",\\"gdpr_label\\":\\"I consent to my submitted data being collected and stored\\",\\"field_name_require\\":\\"yes\\",\\"field_email_require\\":\\"yes\\",\\"field_name_active\\":\\"yes\\",\\"field_email_active\\":\\"yes\\",\\"field_subject_active\\":false,\\"field_subject_require\\":\\"yes\\",\\"field_message_active\\":\\"yes\\",\\"field_send_align\\":\\"left\\",\\"field_extra\\":\\"{\\\\\\"fields\\\\\\":[{\\\\\\"type\\\\\\":\\\\\\"text\\\\\\",\\\\\\"order\\\\\\":3,\\\\\\"id\\\\\\":\\\\\\"ex3\\\\\\",\\\\\\"value\\\\\\":\\\\\\"Phone Number\\\\\\"}]}\\",\\"field_order\\":\\"{\\\\\\"field_name_label\\\\\\":0,\\\\\\"field_email_label\\\\\\":1,\\\\\\"field_subject_label\\\\\\":2,\\\\\\"field_message_label\\\\\\":4}\\",\\"field_optin_label\\":\\"Subscribe to my newsletter.\\",\\"field_optin_active\\":false,\\"provider\\":\\"mailchimp\\",\\"field_sendcopy_active\\":false,\\"field_captcha_active\\":false,\\"field_message_placeholder\\":\\"Write a Message\\",\\"field_email_placeholder\\":\\"Type e-mail address\\",\\"field_name_placeholder\\":\\"Enter Name\\",\\"include_name_mail\\":false,\\"contact_sent_from\\":\\"enable\\",\\"post_author\\":false,\\"user_role\\":\\"admin\\",\\"send_to_admins\\":\\"true\\",\\"layout_contact\\":\\"style1\\",\\"checkbox_r_c_sd_apply_all\\":\\"1\\",\\"r_c_sd_opp_left\\":false,\\"r_c_sd_opp_top\\":false,\\"r_c_sd_top\\":\\"0\\",\\"p_sd_right\\":\\"34\\",\\"p_sd_left\\":\\"34\\",\\"p_sd_opp_left\\":\\"1\\",\\"p_sd_bottom\\":\\"19\\",\\"p_sd_opp_bottom\\":\\"1\\",\\"p_sd_top\\":\\"19\\",\\"background_color_send_h\\":\\"#8d5822\\",\\"background_color_send\\":\\"#000000\\",\\"checkbox_in_r_c_apply_all\\":\\"1\\",\\"in_r_c_opp_left\\":false,\\"in_r_c_opp_top\\":false,\\"in_r_c_top\\":\\"0\\",\\"border_inputs-type\\":\\"left\\",\\"font_color_send\\":\\"#ffffff\\"}}],\\"styling\\":{\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"10\\"}}],\\"styling\\":{\\"border_inner-type\\":\\"top\\",\\"checkbox_padding_inner_apply_all\\":\\"1\\",\\"padding_inner_opp_left\\":false,\\"padding_inner_opp_bottom\\":false,\\"background_position_inner\\":\\"0,0\\",\\"background_attachment_inner\\":\\"scroll\\",\\"background_repeat_inner\\":\\"repeat-none\\",\\"background_image_inner\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-salon\\\\/files\\\\/2021\\\\/04\\\\/circle-bg.png\\",\\"padding_bottom\\":8,\\"padding_bottom_unit\\":\\"%\\"}}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 114,
  'post_date' => '2021-04-21 12:31:31',
  'post_date_gmt' => '2021-04-21 12:31:31',
  'post_content' => '<!-- wp:themify-builder/canvas /--><!--themify_builder_static--><h1>Contact</h1>
<h5>Shop Location</h5> <p>4096 North Street<br>New York City, NY</p>
<h5>Call Us</h5> <p><a href="tel:416-233-4499">416-233-4499</a></p>
<h5>Email Us</h5> <p><a href="mailto:hello@ultrasalon.com">hello@ultrasalon.com</a></p>
<img loading="lazy" width="1158" height="520" src="https://themify.me/demo/themes/ultra-salon/files/2021/04/contact-img.jpg" title="contact-img" alt="contact-img" srcset="https://themify.me/demo/themes/ultra-salon/files/2021/04/contact-img.jpg 1158w, https://themify.me/demo/themes/ultra-salon/files/2021/04/contact-img-600x269.jpg 600w, https://themify.me/demo/themes/ultra-salon/files/2021/04/contact-img-768x345.jpg 768w" sizes="(max-width: 1158px) 100vw, 1158px" />
<h4>Business Hours</h4> <p>MON – FRI 11:00 am –  8:00 pm<br>SAT &amp; SUN 11:00 am –  9:00 pm</p>
<img loading="lazy" width="764" height="832" src="https://themify.me/demo/themes/ultra-salon/files/2021/04/map.jpg" title="map" alt="map" srcset="https://themify.me/demo/themes/ultra-salon/files/2021/04/map.jpg 764w, https://themify.me/demo/themes/ultra-salon/files/2021/04/map-551x600.jpg 551w" sizes="(max-width: 764px) 100vw, 764px" />
<h3>Book an Appointment</h3> <form action="https://themify.me/demo/themes/ultra-salon/wp-admin/admin-ajax.php" class="builder-contact" id="tb_kbl5568-form" method="post" data-post-id="0" data-element-id="kbl5568" data-orig-id="" > <label for="tb_kbl5568-contact-name"></label> <input type="text" name="contact-name" placeholder="Enter Name" id="tb_kbl5568-contact-name" value="" required> <label for="tb_kbl5568-contact-email"></label> <input type="text" name="contact-email" placeholder="Type e-mail address" id="tb_kbl5568-contact-email" value="" required> <label for="tb_kbl5568-contact-message"></label> <textarea name="contact-message" placeholder="Write Message" id="tb_kbl5568-contact-message" required></textarea> <button type="submit">Send Message</button> </form>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-salon/files/2021/04/pexels-samantha-kandinsky-6470305-364x364.jpg" width="364" height="364" title="pexels-samantha-kandinsky-6470305" alt="pexels-samantha-kandinsky-6470305" srcset="https://themify.me/demo/themes/ultra-salon/files/2021/04/pexels-samantha-kandinsky-6470305.jpg 364w, https://themify.me/demo/themes/ultra-salon/files/2021/04/pexels-samantha-kandinsky-6470305-150x150.jpg 150w" sizes="(max-width: 364px) 100vw, 364px" />
<h2>For Her</h2>
<p>Hair Cuts</p> <p>Nails</p> <p>Make-up</p> <p>Spa</p> <p>Facial</p> <p>Massage</p>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-salon/files/2021/04/barber-cut-364x364.jpg" width="364" height="364" title="barber-cut" alt="barber-cut" srcset="https://themify.me/demo/themes/ultra-salon/files/2021/04/barber-cut-364x364.jpg 364w, https://themify.me/demo/themes/ultra-salon/files/2021/04/barber-cut-150x150.jpg 150w" sizes="(max-width: 364px) 100vw, 364px" />
<h2>For Him</h2>
<p>Hair Cut</p> <p>Bread Shave</p> <p>Waxing</p> <p>Hair Cut</p> <p>Bread Shave</p> <p>Waxing</p><!--/themify_builder_static-->',
  'post_title' => 'Contact',
  'post_excerpt' => '',
  'post_name' => 'contact',
  'post_modified' => '2021-10-04 20:19:49',
  'post_modified_gmt' => '2021-10-04 20:19:49',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-salon/?page_id=114',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'section_scrolling_mobile' => 'on',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"pvbf583\\",\\"cols\\":[{\\"element_id\\":\\"8wc1588\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"8x9w137\\",\\"cols\\":[{\\"element_id\\":\\"7j1t138\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"1tls139\\",\\"mod_settings\\":{\\"content_text\\":\\"<h1>Contact<\\\\/h1>\\",\\"margin_bottom\\":\\"20\\"}}]}]},{\\"element_id\\":\\"kx18914\\",\\"cols\\":[{\\"element_id\\":\\"xgij916\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"ae0q761\\",\\"mod_settings\\":{\\"content_text\\":\\"<h5>Shop Location<\\\\/h5>\\\\n<p>4096 North Street<br>New York City, NY<\\\\/p>\\",\\"margin_bottom\\":\\"20\\"}}]},{\\"element_id\\":\\"mk4r916\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"q42c467\\",\\"mod_settings\\":{\\"content_text\\":\\"<h5>Call Us<\\\\/h5>\\\\n<p><a href=\\\\\\"tel:416-233-4499\\\\\\">416-233-4499<\\\\/a><\\\\/p>\\"}}]},{\\"element_id\\":\\"o5gy917\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"jp1j856\\",\\"mod_settings\\":{\\"content_text\\":\\"<h5>Email Us<\\\\/h5>\\\\n<p><a href=\\\\\\"mailto:hello@ultrasalon.com\\\\\\">hello@ultrasalon.com<\\\\/a><\\\\/p>\\",\\"margin_bottom\\":\\"20\\"}}]}]},{\\"element_id\\":\\"zxcg400\\",\\"cols\\":[{\\"element_id\\":\\"n9fv401\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"1096127\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_tag\\":\\"h3\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-salon\\\\/files\\\\/2021\\\\/04\\\\/contact-img.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\"}}]}]},{\\"element_id\\":\\"qo9m853\\",\\"cols\\":[{\\"element_id\\":\\"sgzd854\\",\\"grid_class\\":\\"col3-1\\"},{\\"element_id\\":\\"sy98855\\",\\"grid_class\\":\\"col3-1\\"},{\\"element_id\\":\\"oxqt857\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"wv4239\\",\\"mod_settings\\":{\\"content_text\\":\\"<h4>Business Hours<\\\\/h4>\\\\n<p>MON – FRI 11:00 am –  8:00 pm<br>SAT &amp; SUN 11:00 am –  9:00 pm<\\\\/p>\\",\\"padding_opp_left\\":\\"1\\",\\"padding_opp_bottom\\":\\"1\\",\\"font_color\\":\\"#ffffff\\",\\"font_color_type\\":\\"font_color_solid\\",\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_color\\":\\"#8d5822\\",\\"background_image-type\\":\\"image\\",\\"padding_right\\":\\"25\\",\\"padding_left\\":\\"25\\",\\"padding_bottom\\":\\"20\\",\\"padding_top\\":\\"20\\",\\"font_size_unit\\":\\"em\\",\\"font_size\\":\\".9\\",\\"motion_effects\\":{\\"v\\":{\\"val\\":{\\"v_dir\\":\\"up\\"}}}}}],\\"styling\\":{\\"padding_right\\":\\"35\\",\\"breakpoint_mobile\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_right_unit\\":\\"px\\",\\"padding_right\\":\\"0\\",\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false},\\"breakpoint_tablet\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_right_unit\\":\\"px\\",\\"padding_right\\":\\"0\\",\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false}}}],\\"gutter\\":\\"gutter-none\\",\\"col_tablet\\":\\"column-full\\",\\"styling\\":{\\"margin_top\\":\\"-80\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_opp_left\\":false,\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\",\\"margin_top\\":\\"0\\"}}}]}],\\"styling\\":{\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"8\\"}},{\\"element_id\\":\\"cejz879\\",\\"cols\\":[{\\"element_id\\":\\"fac5880\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"y09d648\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_tag\\":\\"h3\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-salon\\\\/files\\\\/2021\\\\/04\\\\/map.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\"}}]},{\\"element_id\\":\\"qbye764\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"contact\\",\\"element_id\\":\\"kbl5568\\",\\"mod_settings\\":{\\"field_subject_label\\":\\"Subject\\",\\"field_sendcopy_label\\":\\"Send a copy to myself\\",\\"field_sendcopy_subject\\":\\"COPY:\\",\\"field_send_label\\":\\"Send Message\\",\\"gdpr_label\\":\\"I consent to my submitted data being collected and stored\\",\\"field_name_require\\":\\"yes\\",\\"field_email_require\\":\\"yes\\",\\"field_name_active\\":\\"yes\\",\\"field_email_active\\":\\"yes\\",\\"field_subject_active\\":false,\\"field_subject_require\\":\\"yes\\",\\"field_message_active\\":\\"yes\\",\\"field_send_align\\":\\"left\\",\\"field_extra\\":\\"{\\\\\\"fields\\\\\\":[]}\\",\\"field_order\\":\\"{\\\\\\"field_name_label\\\\\\":0,\\\\\\"field_email_label\\\\\\":1,\\\\\\"field_subject_label\\\\\\":2,\\\\\\"field_message_label\\\\\\":3}\\",\\"field_optin_label\\":\\"Subscribe to my newsletter.\\",\\"field_optin_active\\":false,\\"provider\\":\\"mailchimp\\",\\"field_sendcopy_active\\":false,\\"field_captcha_active\\":false,\\"field_message_placeholder\\":\\"Write Message\\",\\"field_email_placeholder\\":\\"Type e-mail address\\",\\"field_name_placeholder\\":\\"Enter Name\\",\\"include_name_mail\\":false,\\"contact_sent_from\\":\\"enable\\",\\"post_author\\":false,\\"user_role\\":\\"admin\\",\\"send_to_admins\\":false,\\"layout_contact\\":\\"style1\\",\\"p_sd_right\\":\\"36\\",\\"p_sd_left\\":\\"36\\",\\"p_sd_opp_left\\":\\"1\\",\\"p_sd_bottom\\":\\"19\\",\\"p_sd_opp_bottom\\":\\"1\\",\\"p_sd_top\\":\\"19\\",\\"font_color_send\\":\\"#ffffff\\",\\"background_color_send_h\\":\\"#8d5822\\",\\"background_color_send\\":\\"#000000\\",\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"b_ra_top\\":\\"0\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"8\\",\\"background_color\\":\\"#ffffff\\",\\"mod_title_contact\\":\\"Book an Appointment\\",\\"font_size_module_title\\":\\"30\\",\\"b_sh_color\\":\\"#000000_0.05\\",\\"b_sh_spread\\":\\"1\\",\\"b_sh_blur\\":\\"10\\",\\"b_sh_vOffset\\":\\"2\\",\\"b_sh_hOffset\\":\\"0\\",\\"in_m_opp_left\\":false,\\"in_m_bottom\\":\\"0\\",\\"in_m_opp_bottom\\":false,\\"margin_left\\":\\"-90\\",\\"w_auto_width\\":false,\\"w_unit\\":\\"px\\",\\"breakpoint_mobile\\":{\\"w_auto_width\\":false,\\"w_unit\\":\\"px\\",\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_left\\":\\"0\\",\\"margin_opp_left\\":false,\\"margin_opp_bottom\\":false},\\"template\\":\\"From: %name% @ %email%<br>\\\\n<b>Subject:<\\\\/b> %subject%\\\\n\\\\n%message%\\\\n<br>Sent from: %referer%<br>\\"}}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"8\\",\\"padding_top\\":\\"8\\"}},{\\"element_id\\":\\"0wze980\\",\\"cols\\":[{\\"element_id\\":\\"ma6u980\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"2fp9167\\",\\"cols\\":[{\\"element_id\\":\\"dbpg169\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"lt46219\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_tag\\":\\"h3\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":\\"circle\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-salon\\\\/files\\\\/2021\\\\/04\\\\/pexels-samantha-kandinsky-6470305.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"height_image\\":\\"364\\",\\"width_image\\":\\"364\\",\\"animation_effect\\":\\"fadeInLeft\\"}}],\\"styling\\":{\\"text_align\\":\\"right\\",\\"padding_right_unit\\":\\"%\\",\\"padding_right\\":\\"5\\"}},{\\"element_id\\":\\"zy1t170\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"ybok891\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>For Her<\\\\/h2>\\",\\"column_count\\":\\"0\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"q33e267\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>Hair Cuts<\\\\/p>\\\\n<p>Nails<\\\\/p>\\\\n<p>Make-up<\\\\/p>\\\\n<p><span style=\\\\\\"background-color: initial; font-size: 1em;\\\\\\">Spa<\\\\/span><\\\\/p>\\\\n<p><span style=\\\\\\"background-color: initial; font-size: 1em;\\\\\\">Facial<\\\\/span><\\\\/p>\\\\n<p>Massage<\\\\/p>\\",\\"column_count\\":\\"2\\",\\"margin_bottom_unit\\":\\"em\\",\\"margin_bottom\\":\\"1\\",\\"p_margin_bottom\\":\\"5\\",\\"text_transform\\":\\"uppercase\\",\\"font_color_type\\":\\"font_color_solid\\"}}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"styling\\":{\\"padding_right\\":\\"30\\",\\"padding_left\\":\\"30\\",\\"padding_opp_left\\":\\"1\\",\\"padding_bottom\\":8,\\"padding_top\\":\\"2.3\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"breakpoint_mobile\\":{\\"padding_bottom\\":8,\\"padding_bottom_unit\\":\\"%\\"}}},{\\"element_id\\":\\"ftu535\\",\\"cols\\":[{\\"element_id\\":\\"917k36\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"navt36\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_tag\\":\\"h3\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":\\"circle\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-salon\\\\/files\\\\/2021\\\\/04\\\\/barber-cut-364x364.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"height_image\\":\\"364\\",\\"width_image\\":\\"364\\",\\"animation_effect\\":\\"fadeInRight\\"}}],\\"styling\\":{\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"5\\",\\"breakpoint_tablet\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"5\\",\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false},\\"breakpoint_mobile\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"5\\",\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false}}},{\\"element_id\\":\\"ijzs37\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"r06l37\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>For Him<\\\\/h2>\\",\\"column_count\\":\\"0\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"2rlh37\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>Hair Cut<\\\\/p>\\\\n<p>Bread Shave<\\\\/p>\\\\n<p>Waxing<\\\\/p>\\\\n<p>Hair Cut<\\\\/p>\\\\n<p>Bread Shave<\\\\/p>\\\\n<p>Waxing<\\\\/p>\\",\\"column_count\\":\\"2\\",\\"margin_bottom_unit\\":\\"em\\",\\"margin_bottom\\":\\"1\\",\\"p_margin_bottom\\":\\"5\\",\\"text_transform\\":\\"uppercase\\",\\"font_color_type\\":\\"font_color_solid\\"}}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"desktop_dir\\":\\"rtl\\",\\"tablet_dir\\":\\"rtl\\",\\"tablet_landscape_dir\\":\\"rtl\\",\\"styling\\":{\\"padding_right\\":\\"30\\",\\"padding_left\\":\\"30\\",\\"padding_opp_left\\":\\"1\\",\\"padding_bottom\\":12,\\"padding_top\\":\\"5\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"breakpoint_mobile\\":{\\"padding_bottom\\":8,\\"padding_bottom_unit\\":\\"%\\"}}}]}],\\"column_alignment\\":\\"col_align_middle\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 7,
  'post_date' => '2021-04-19 13:02:37',
  'post_date_gmt' => '2021-04-19 13:02:37',
  'post_content' => '<!-- wp:themify-builder/canvas /--><!--themify_builder_static--><h1>It is more than just a cut &amp; style</h1>
<p>Ultra Salon is a full service hair salon and spa located in NYC. Come visit us for a relaxing yet luxurious experience. </p>
<a href="https://themify.me/" > Book Now </a>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-salon/files/2021/04/hero-home-1000x743.jpg" width="1000" height="743" title="hero-home" alt="hero-home" srcset="https://themify.me/demo/themes/ultra-salon/files/2021/04/hero-home-1000x743.jpg 1000w, https://themify.me/demo/themes/ultra-salon/files/2021/04/hero-home-600x446.jpg 600w, https://themify.me/demo/themes/ultra-salon/files/2021/04/hero-home-768x571.jpg 768w, https://themify.me/demo/themes/ultra-salon/files/2021/04/hero-home.jpg 1116w" sizes="(max-width: 1000px) 100vw, 1000px" />
<img loading="lazy" src="https://themify.me/demo/themes/ultra-salon/files/2021/04/woman-stylist-310x437.jpg" width="310" height="437" title="woman-stylist" alt="woman-stylist">
<img loading="lazy" src="https://themify.me/demo/themes/ultra-salon/files/2021/04/hair-treatment-310x280.jpg" width="310" height="280" title="hair-treatment" alt="hair-treatment">
<img loading="lazy" src="https://themify.me/demo/themes/ultra-salon/files/2021/04/haircut-310x280.jpg" width="310" height="280" title="haircut" alt="haircut">

<h2>Hair salon, spa &amp; make-up services</h2> <p>With more than 10-year in the industry, our team of hair stylists, colourists, and artists are specializing in hair cuts, colouring, extensions, make-up, and treatments.</p>
<h3>10+</h3>
<p>Years of Experience</p>
<h3>20K+</h3>
<p>Happy Customers</p>
<h2>Barber services</h2> <p>For the guys out there, we have a dedicated barber team who can give cool cuts and hot shaves.</p>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-salon/files/2021/04/man-barber-310x437.jpg" width="310" height="437" title="man-barber" alt="man-barber">
<img loading="lazy" src="https://themify.me/demo/themes/ultra-salon/files/2021/04/barber-cut-310x280.jpg" width="310" height="280" title="barber-cut" alt="barber-cut">
<img loading="lazy" src="https://themify.me/demo/themes/ultra-salon/files/2021/04/man-stylish-310x280.jpg" width="310" height="280" title="man-stylish" alt="man-stylish">
<img loading="lazy" width="393" height="565" src="https://themify.me/demo/themes/ultra-salon/files/2021/04/natasha.jpg" title="natasha" alt="natasha">
<img loading="lazy" width="389" height="272" src="https://themify.me/demo/themes/ultra-salon/files/2021/04/rianna.jpg" title="rianna" alt="rianna">
<img loading="lazy" width="389" height="272" src="https://themify.me/demo/themes/ultra-salon/files/2021/04/sthephany.jpg" title="sthephany" alt="sthephany">
<p>Got my hair extension done today. The service and quality is amazing. The extension matches with my hair seamlessly. Highly recommended.</p> Wendy 
 <p>I\'ve been going to this salon for a few years. The services and attention to details are perfect. The staffs are clean and courteous. </p> Stephanie Z. 
 <p>I\'m impressed with my first experience with this salon. Will definitely come back again with my friends to their facial and spa services.</p> Chole
<h2>Price List</h2> <p>Our experienced team offers a wide range of services from hair cut to styling/make-up, coloring, spa and barber services.</p>
<a href="https://themify.me/" > Book Now </a>
<h4 class=\'tb-menu-title\'>Junior Cut</h4> Hair cut by a junior stylist, included wash & dry. 
 $50+ <br/>
<h4 class=\'tb-menu-title\'>Senior Cut</h4> Hair cut by a senior stylist, included wash & dry. 
 $80+ <br/>
<h4 class=\'tb-menu-title\'>Hair Coloring</h4> Balayage, highlight, creative colors, blending. 
 $140+ <br/>
<h4 class=\'tb-menu-title\'>Hair Treatments</h4> Intense treatments to repair all hair types. 
 $100+ <br/>
<h4 class=\'tb-menu-title\'>Styling</h4> Freshen your look by our experienced stylists. 
 $60+ <br/>
<h4 class=\'tb-menu-title\'>Make-up</h4> Our beauty artists are by appointment only. 
 $50+ <br/>
<h4 class=\'tb-menu-title\'>Nail Services</h4> We cover head to toe - don\'t forget your nails. 
 $30+ <br/>
<h4 class=\'tb-menu-title\'>Men Cuts & Shaves</h4> Male hair cuts, beard shaves and trims.  
 $40+ <br/>
<h4>Book an Appointment</h4> <h2>312-234-5789</h2> <p>4096 North Street<br>New York City, NY</p> <p>MON - FRI 11:00 am -  8:00 pm<br>SAT &amp; SUN 11:00 am -  9:00 pm</p>
<form action="https://themify.me/demo/themes/ultra-salon/wp-admin/admin-ajax.php" class="builder-contact" id="tb_plnw312-form" method="post" data-post-id="0" data-element-id="plnw312" data-orig-id="" > <label for="tb_plnw312-contact-name"></label> <input type="text" name="contact-name" placeholder="Enter Name" id="tb_plnw312-contact-name" value="" required> <label for="tb_plnw312-contact-email"></label> <input type="text" name="contact-email" placeholder="Type e-mail address" id="tb_plnw312-contact-email" value="" required> <label for="field_extra_tb_plnw312_0"> <input type="hidden" name="field_extra_name_0" value=""> </label> <input type="text" name="field_extra_0" id="field_extra_tb_plnw312_0" placeholder="Phone Number"> <label for="tb_plnw312-contact-message"></label> <textarea name="contact-message" placeholder="Write a Message" id="tb_plnw312-contact-message" required></textarea> <button type="submit">Send Message</button> </form>
<h2>Our Shop</h2> <p>High quality hair and skin care products</p>
<ul data-lazy="1"> <li> <figure> <a href="https://themify.me/demo/themes/ultra-salon/product/woman-hair-vitamin-180/" title="Woman Hair Vitamin 180"><img loading="lazy" src="https://themify.me/demo/themes/ultra-salon/files/2021/04/zotos-180pro-265x285.jpg" width="265" height="285" title="zotos-180pro" alt="zotos-180pro"></a> </figure> <h3> <a href="https://themify.me/demo/themes/ultra-salon/product/woman-hair-vitamin-180/" title="Woman Hair Vitamin 180"> Woman Hair Vitamin 180 </a> </h3> 
 <bdi>&#36;15.00</bdi> <p><a href="?add-to-cart=236" data-quantity="1" data-product_id="236" data-product_sku="" aria-label="Add &ldquo;Woman Hair Vitamin 180&rdquo; to your cart" rel="nofollow">Add to cart</a></p> </li> <li> <figure> <a href="https://themify.me/demo/themes/ultra-salon/product/hairdyer-serum/" title="Hairdyer Serum"><img loading="lazy" src="https://themify.me/demo/themes/ultra-salon/files/2021/04/spun-satin-hairdyer-265x285.jpg" width="265" height="285" title="spun-satin-hairdyer" alt="spun-satin-hairdyer"></a> </figure> <h3> <a href="https://themify.me/demo/themes/ultra-salon/product/hairdyer-serum/" title="Hairdyer Serum"> Hairdyer Serum </a> </h3> 
 <bdi>&#36;15.00</bdi> <p><a href="?add-to-cart=234" data-quantity="1" data-product_id="234" data-product_sku="" aria-label="Add &ldquo;Hairdyer Serum&rdquo; to your cart" rel="nofollow">Add to cart</a></p> </li> <li> <figure> <a href="https://themify.me/demo/themes/ultra-salon/product/hair-vitamin-serum/" title="Hair Vitamin Serum"><img loading="lazy" src="https://themify.me/demo/themes/ultra-salon/files/2021/04/moss-chandler-265x285.jpg" width="265" height="285" title="moss-chandler" alt="moss-chandler"></a> </figure> <h3> <a href="https://themify.me/demo/themes/ultra-salon/product/hair-vitamin-serum/" title="Hair Vitamin Serum"> Hair Vitamin Serum </a> </h3> 
 <bdi>&#36;20.00</bdi> <p><a href="?add-to-cart=232" data-quantity="1" data-product_id="232" data-product_sku="" aria-label="Add &ldquo;Hair Vitamin Serum&rdquo; to your cart" rel="nofollow">Add to cart</a></p> </li> <li> <figure> <a href="https://themify.me/demo/themes/ultra-salon/product/woman-hair-vitamin/" title="Woman Hair Vitamin"><img loading="lazy" src="https://themify.me/demo/themes/ultra-salon/files/2021/04/clinique-hair-gel-265x285.jpg" width="265" height="285" title="clinique-hair-gel" alt="clinique-hair-gel"></a> </figure> <h3> <a href="https://themify.me/demo/themes/ultra-salon/product/woman-hair-vitamin/" title="Woman Hair Vitamin"> Woman Hair Vitamin </a> </h3> 
 <bdi>&#36;25.00</bdi> <p><a href="?add-to-cart=230" data-quantity="1" data-product_id="230" data-product_sku="" aria-label="Add &ldquo;Woman Hair Vitamin&rdquo; to your cart" rel="nofollow">Add to cart</a></p> </li> </ul><!--/themify_builder_static-->',
  'post_title' => 'Home',
  'post_excerpt' => '',
  'post_name' => 'home',
  'post_modified' => '2021-10-04 20:12:58',
  'post_modified_gmt' => '2021-10-04 20:12:58',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-salon/?page_id=7',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'section_scrolling_mobile' => 'on',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"tx1a159\\",\\"cols\\":[{\\"element_id\\":\\"nw9q160\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"jhwe998\\",\\"mod_settings\\":{\\"content_text\\":\\"<h1>It is more than just a cut &amp; style<\\\\/h1>\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"muf995\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>Ultra Salon is a full service hair salon and spa located in NYC. Come visit us for a relaxing yet luxurious experience. <\\\\/p>\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"ea1h389\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"Book Now\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"button_color_bg\\":\\"black\\",\\"icon_alignment\\":\\"left\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_shape\\":\\"squared\\",\\"buttons_size\\":\\"normal\\",\\"link_border_top_width\\":\\"1\\",\\"link_border_top_color\\":\\"#000000\\",\\"link_border-type\\":\\"all\\",\\"buttons_style\\":\\"outline\\"}}],\\"styling\\":{\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"12\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"5\\"}},{\\"element_id\\":\\"zpwc685\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"u0s637\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_tag\\":\\"h3\\",\\"auto_fullwidth\\":\\"1\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-salon\\\\/files\\\\/2021\\\\/04\\\\/hero-home.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"width_image\\":\\"1000\\",\\"animation_effect\\":\\"fadeInRight\\"}}]}],\\"column_alignment\\":\\"col_align_bottom\\",\\"styling\\":{\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"7\\",\\"background_color\\":\\"#f4f3ef\\",\\"background_position\\":\\"50,50\\",\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"row_width\\":\\"fullwidth-content\\"}},{\\"element_id\\":\\"aka338\\",\\"cols\\":[{\\"element_id\\":\\"fk5z39\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"element_id\\":\\"wctf775\\",\\"cols\\":[{\\"element_id\\":\\"0j3w776\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"rbws314\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_tag\\":\\"h3\\",\\"height_image\\":\\"437\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"310\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-salon\\\\/files\\\\/2021\\\\/04\\\\/woman-stylist.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"font_color_type\\":\\"font_color_solid\\",\\"breakpoint_mobile\\":{\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\",\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"20\\",\\"margin_opp_bottom\\":false,\\"margin_left\\":\\"0\\"},\\"margin_left_unit\\":\\"%\\",\\"margin_left\\":\\"20\\",\\"motion_effects\\":{\\"v\\":{\\"val\\":{\\"v_dir\\":\\"up\\"}}}}}]},{\\"element_id\\":\\"kxn3777\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"dadq446\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_tag\\":\\"h3\\",\\"height_image\\":\\"280\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"310\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-salon\\\\/files\\\\/2021\\\\/04\\\\/hair-treatment.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"margin_bottom\\":\\"20\\",\\"font_color_type\\":\\"font_color_solid\\",\\"margin_right_unit\\":\\"%\\",\\"margin_right\\":\\"20\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"%\\",\\"margin_right\\":\\"0\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"20\\",\\"margin_opp_bottom\\":false},\\"motion_effects\\":{\\"v\\":{\\"val\\":{\\"v_speed\\":\\"2\\",\\"v_dir\\":\\"up\\"}}}}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"pd1v55\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_tag\\":\\"h3\\",\\"height_image\\":\\"280\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"310\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-salon\\\\/files\\\\/2021\\\\/04\\\\/haircut.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"margin_right_unit\\":\\"%\\",\\"margin_right\\":\\"20\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"%\\",\\"margin_right\\":\\"0\\",\\"margin_opp_left\\":false,\\"margin_opp_bottom\\":false},\\"motion_effects\\":{\\"v\\":{\\"val\\":{\\"v_dir\\":\\"up\\"}}}}}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"col_mobile\\":\\"column4-2\\",\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"10\\",\\"padding_opp_bottom\\":\\"1\\",\\"padding_top\\":\\"10\\",\\"margin_left\\":150,\\"breakpoint_tablet_landscape\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_left\\":\\"90\\",\\"margin_opp_left\\":false,\\"margin_opp_bottom\\":false},\\"breakpoint_tablet\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_left\\":\\"40\\",\\"margin_opp_left\\":false,\\"margin_opp_bottom\\":false},\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_left\\":\\"0\\",\\"margin_opp_left\\":false,\\"margin_opp_bottom\\":false,\\"checkbox_padding_apply_all\\":false,\\"padding_right_unit\\":\\"%\\",\\"padding_right\\":\\"5\\",\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"5\\",\\"padding_opp_left\\":\\"1\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"10\\",\\"padding_opp_bottom\\":\\"1\\",\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"10\\"}}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"25st278\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_tag\\":\\"h3\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\"}}],\\"styling\\":{\\"background_color\\":\\"#eae4dd\\",\\"background_position\\":\\"50,50\\",\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}},{\\"element_id\\":\\"0qs7529\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"m1v6303\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Hair salon, spa &amp; make-up services<\\\\/h2>\\\\n<p>With more than 10-year in the industry, our team of hair stylists, colourists, and artists are specializing in hair cuts, colouring, extensions, make-up, and treatments.<\\\\/p>\\",\\"margin_bottom\\":\\"50\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"pw6i320\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>10+<\\\\/h3>\\",\\"line_height_h3\\":\\"1\\",\\"font_size_h3\\":\\"80\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"rpb1983\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>Years of Experience<\\\\/p>\\",\\"margin_bottom\\":40}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"9uf7480\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>20K+<\\\\/h3>\\",\\"line_height_h3\\":\\"1\\",\\"font_size_h3\\":\\"80\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"riov771\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>Happy Customers<\\\\/p>\\",\\"margin_bottom\\":\\"20\\"}}],\\"styling\\":{\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_right\\":\\"8\\",\\"padding_left\\":\\"12\\",\\"padding_bottom\\":\\"50\\",\\"padding_top\\":\\"50\\"}}],\\"column_alignment\\":\\"col_align_middle\\",\\"gutter\\":\\"gutter-none\\",\\"styling\\":{\\"row_width\\":\\"fullwidth-content\\"}},{\\"element_id\\":\\"86g634\\",\\"cols\\":[{\\"element_id\\":\\"hje635\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"iwc538\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Barber services<\\\\/h2>\\\\n<p>For the guys out there, we have a dedicated barber team who can give cool cuts and hot shaves.<\\\\/p>\\",\\"margin_bottom\\":\\"50\\"}}],\\"styling\\":{\\"background_position\\":\\"50,50\\",\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_right\\":\\"12\\",\\"padding_left\\":\\"8\\",\\"breakpoint_mobile\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_right_unit\\":\\"%\\",\\"padding_right\\":\\"12\\",\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"8\\",\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false,\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"10\\"}}},{\\"element_id\\":\\"omky37\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"element_id\\":\\"y7f935\\",\\"cols\\":[{\\"element_id\\":\\"1let36\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"c8m736\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_tag\\":\\"h3\\",\\"height_image\\":\\"437\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"310\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-salon\\\\/files\\\\/2021\\\\/04\\\\/man-barber.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"20\\",\\"margin_opp_bottom\\":false,\\"margin_left\\":\\"0\\"},\\"margin_left_unit\\":\\"%\\",\\"margin_left\\":\\"20\\",\\"motion_effects\\":{\\"v\\":{\\"val\\":{\\"v_speed\\":\\"1\\",\\"v_dir\\":\\"up\\"}}}}}]},{\\"element_id\\":\\"qbul36\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"by9p37\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_tag\\":\\"h3\\",\\"height_image\\":\\"280\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"310\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-salon\\\\/files\\\\/2021\\\\/04\\\\/barber-cut.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"margin_bottom\\":\\"20\\",\\"margin_right_unit\\":\\"%\\",\\"margin_right\\":\\"20\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"%\\",\\"margin_right\\":\\"0\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"20\\",\\"margin_opp_bottom\\":false},\\"motion_effects\\":{\\"v\\":{\\"val\\":{\\"v_speed\\":\\"2\\",\\"v_dir\\":\\"up\\"}}}}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"d6er37\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_tag\\":\\"h3\\",\\"height_image\\":\\"280\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"310\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-salon\\\\/files\\\\/2021\\\\/04\\\\/man-stylish.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"margin_right_unit\\":\\"%\\",\\"margin_right\\":\\"20\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"%\\",\\"margin_right\\":\\"0\\",\\"margin_opp_left\\":false,\\"margin_opp_bottom\\":false},\\"motion_effects\\":{\\"v\\":{\\"val\\":{\\"v_dir\\":\\"up\\"}}}}}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"col_mobile\\":\\"column4-2\\",\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"10\\",\\"padding_opp_bottom\\":\\"1\\",\\"padding_top\\":\\"10\\",\\"margin_left\\":\\"-150\\",\\"breakpoint_tablet_landscape\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_left\\":\\"-90\\",\\"margin_opp_left\\":false,\\"margin_opp_bottom\\":false},\\"breakpoint_tablet\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_left\\":\\"-40\\",\\"margin_opp_left\\":false,\\"margin_opp_bottom\\":false},\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_left\\":\\"0\\",\\"margin_opp_left\\":false,\\"margin_opp_bottom\\":false,\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"5\\",\\"padding_opp_left\\":\\"1\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"10\\",\\"padding_opp_bottom\\":\\"1\\",\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"10\\",\\"padding_right_unit\\":\\"%\\",\\"padding_right\\":\\"5\\"}}}],\\"styling\\":{\\"background_color\\":\\"#f4f3ef\\",\\"background_position\\":\\"50,50\\",\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}}],\\"column_alignment\\":\\"col_align_middle\\",\\"gutter\\":\\"gutter-none\\",\\"mobile_dir\\":\\"rtl\\",\\"styling\\":{\\"row_width\\":\\"fullwidth-content\\"}},{\\"element_id\\":\\"61qb289\\",\\"cols\\":[{\\"element_id\\":\\"m5dm290\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"element_id\\":\\"zhx1544\\",\\"cols\\":[{\\"element_id\\":\\"uc8j546\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"tzac606\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_tag\\":\\"h3\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-salon\\\\/files\\\\/2021\\\\/04\\\\/natasha.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"margin_bottom\\":\\"0\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"10\\",\\"margin_opp_bottom\\":false},\\"animation_effect\\":\\"fadeInLeft\\"}}],\\"styling\\":{\\"padding_opp_bottom\\":\\"1\\"}},{\\"element_id\\":\\"ulqo546\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"o162239\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_tag\\":\\"h3\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-salon\\\\/files\\\\/2021\\\\/04\\\\/rianna.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"margin_bottom\\":\\"10\\",\\"animation_effect\\":\\"fadeInRight\\"}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"ou6i98\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_tag\\":\\"h3\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-salon\\\\/files\\\\/2021\\\\/04\\\\/sthephany.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"margin_bottom\\":\\"0\\",\\"animation_effect\\":\\"fadeInRight\\"}}]}],\\"col_mobile\\":\\"column4-2\\"}]},{\\"element_id\\":\\"9l1c139\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"testimonial-slider\\",\\"element_id\\":\\"6g3a310\\",\\"mod_settings\\":{\\"layout_testimonial\\":\\"image-top\\",\\"img_h_slider\\":\\"100\\",\\"img_w_slider\\":\\"100\\",\\"visible_opt_slider\\":\\"1\\",\\"auto_scroll_opt_slider\\":\\"off\\",\\"tab_content_testimonial\\":[{\\"content_testimonial\\":\\"<p>Got my hair extension done today. The service and quality is amazing. The extension matches with my hair seamlessly. Highly recommended.<\\\\/p>\\",\\"person_name_testimonial\\":\\"Wendy\\"},{\\"content_testimonial\\":\\"<p>I\\\'ve been going to this salon for a few years. The services and attention to details are perfect. The staffs are clean and courteous. <\\\\/p>\\",\\"person_name_testimonial\\":\\"Stephanie Z.\\"},{\\"content_testimonial\\":\\"<p>I\\\'m impressed with my first experience with this salon. Will definitely come back again with my friends to their facial and spa services.<\\\\/p>\\",\\"person_name_testimonial\\":\\"Chole\\"}],\\"height_slider\\":\\"variable\\",\\"show_arrow_buttons_vertical\\":false,\\"show_arrow_slider\\":\\"yes\\",\\"show_nav_slider\\":\\"yes\\",\\"wrap_slider\\":\\"yes\\",\\"play_pause_control\\":\\"no\\",\\"pause_on_hover_slider\\":\\"resume\\",\\"speed_opt_slider\\":\\"normal\\",\\"scroll_opt_slider\\":\\"1\\",\\"mob_visible_opt_slider\\":\\"1\\",\\"tab_visible_opt_slider\\":\\"1\\",\\"effect_slider\\":\\"scroll\\",\\"masonry\\":\\"disable\\",\\"grid_layout_testimonial\\":\\"list-post\\",\\"type_testimonial\\":\\"slider\\",\\"text_align\\":\\"left\\",\\"font_color_type\\":\\"font_color_solid\\",\\"text_transform_person_name\\":\\"uppercase\\",\\"font_size_person_name_unit\\":\\"em\\",\\"font_size_person_name\\":\\".8\\",\\"font_size_content_unit\\":\\"em\\",\\"font_size_content\\":\\"1.1\\",\\"font_size_unit\\":\\"em\\"}}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":\\"1\\",\\"padding_bottom\\":\\"8\\",\\"padding_opp_bottom\\":\\"1\\",\\"padding_top\\":\\"8\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_right\\":\\"6\\",\\"padding_left\\":\\"6\\"}}],\\"column_alignment\\":\\"col_align_middle\\",\\"styling\\":{\\"background_color\\":\\"#eae4dd\\",\\"background_position\\":\\"50,50\\",\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_top\\":30,\\"padding_opp_top\\":\\"1\\",\\"padding_bottom\\":30,\\"padding_opp_bottom\\":\\"1\\"}},{\\"element_id\\":\\"h5su294\\",\\"cols\\":[{\\"element_id\\":\\"l9xk295\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"7nz8956\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Price List<\\\\/h2>\\\\n<p>Our experienced team offers a wide range of services from hair cut to styling\\\\/make-up, coloring, spa and barber services.<\\\\/p>\\",\\"padding_top\\":\\"20\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"hcyc526\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"Book Now\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"button_color_bg\\":\\"black\\",\\"icon_alignment\\":\\"left\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_shape\\":\\"squared\\",\\"buttons_size\\":\\"normal\\",\\"link_border_top_width\\":\\"1\\",\\"link_border_top_color\\":\\"#000000\\",\\"link_border-type\\":\\"all\\",\\"buttons_style\\":\\"outline\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"30\\",\\"margin_opp_bottom\\":false}}}]},{\\"element_id\\":\\"m53f466\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"glbm289\\",\\"mod_settings\\":{\\"title_tag\\":\\"h4\\",\\"title_service_menu\\":\\"Junior Cut\\",\\"description_service_menu\\":\\"Hair cut by a junior stylist, included wash & dry.\\",\\"price_service_menu\\":\\"$50+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border-type\\":\\"bottom\\",\\"global_styles\\":\\"tb_gs238614\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"nsnr624\\",\\"mod_settings\\":{\\"title_tag\\":\\"h4\\",\\"title_service_menu\\":\\"Senior Cut\\",\\"description_service_menu\\":\\"Hair cut by a senior stylist, included wash & dry.\\",\\"price_service_menu\\":\\"$80+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border-type\\":\\"bottom\\",\\"global_styles\\":\\"tb_gs238614\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"rwyn164\\",\\"mod_settings\\":{\\"title_tag\\":\\"h4\\",\\"title_service_menu\\":\\"Hair Coloring\\",\\"description_service_menu\\":\\"Balayage, highlight, creative colors, blending.\\",\\"price_service_menu\\":\\"$140+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border-type\\":\\"bottom\\",\\"global_styles\\":\\"tb_gs238614\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"ika4289\\",\\"mod_settings\\":{\\"title_tag\\":\\"h4\\",\\"title_service_menu\\":\\"Hair Treatments\\",\\"description_service_menu\\":\\"Intense treatments to repair all hair types.\\",\\"price_service_menu\\":\\"$100+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border-type\\":\\"bottom\\",\\"global_styles\\":\\"tb_gs238614\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}}]},{\\"element_id\\":\\"w8pd466\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"fewu800\\",\\"mod_settings\\":{\\"title_tag\\":\\"h4\\",\\"title_service_menu\\":\\"Styling\\",\\"description_service_menu\\":\\"Freshen your look by our experienced stylists.\\",\\"price_service_menu\\":\\"$60+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border-type\\":\\"bottom\\",\\"global_styles\\":\\"tb_gs238614\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"lkse76\\",\\"mod_settings\\":{\\"title_tag\\":\\"h4\\",\\"title_service_menu\\":\\"Make-up\\",\\"description_service_menu\\":\\"Our beauty artists are by appointment only.\\",\\"price_service_menu\\":\\"$50+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border-type\\":\\"bottom\\",\\"global_styles\\":\\"tb_gs238614\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"a62h441\\",\\"mod_settings\\":{\\"title_tag\\":\\"h4\\",\\"title_service_menu\\":\\"Nail Services\\",\\"description_service_menu\\":\\"We cover head to toe - don\\\'t forget your nails.\\",\\"price_service_menu\\":\\"$30+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border-type\\":\\"bottom\\",\\"global_styles\\":\\"tb_gs238614\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"mexc328\\",\\"mod_settings\\":{\\"title_tag\\":\\"h4\\",\\"title_service_menu\\":\\"Men Cuts & Shaves\\",\\"description_service_menu\\":\\"Male hair cuts, beard shaves and trims. \\",\\"price_service_menu\\":\\"$40+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border-type\\":\\"bottom\\",\\"global_styles\\":\\"tb_gs238614\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}}]}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":\\"1\\",\\"padding_bottom\\":\\"8\\",\\"padding_opp_bottom\\":\\"1\\",\\"padding_top\\":\\"8\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_right\\":\\"8\\",\\"padding_left\\":\\"8\\"}},{\\"element_id\\":\\"egwq435\\",\\"cols\\":[{\\"element_id\\":\\"fqdv437\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"q1us678\\",\\"mod_settings\\":{\\"content_text\\":\\"<h4>Book an Appointment<\\\\/h4>\\\\n<h2>312-234-5789<\\\\/h2>\\\\n<p>4096 North Street<br>New York City, NY<\\\\/p>\\\\n<p>MON - FRI 11:00 am -  8:00 pm<br>SAT &amp; SUN 11:00 am -  9:00 pm<\\\\/p>\\",\\"margin_bottom\\":\\"50\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"17\\"}}],\\"styling\\":{\\"padding_left_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_left\\":\\"10\\",\\"padding_top\\":\\"10\\"}},{\\"element_id\\":\\"cfs5392\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"contact\\",\\"element_id\\":\\"plnw312\\",\\"mod_settings\\":{\\"field_subject_label\\":\\"Subject\\",\\"field_sendcopy_label\\":\\"Send a copy to myself\\",\\"field_sendcopy_subject\\":\\"COPY:\\",\\"field_send_label\\":\\"Send Message\\",\\"gdpr_label\\":\\"I consent to my submitted data being collected and stored\\",\\"field_name_require\\":\\"yes\\",\\"field_email_require\\":\\"yes\\",\\"field_name_active\\":\\"yes\\",\\"field_email_active\\":\\"yes\\",\\"field_subject_active\\":false,\\"field_subject_require\\":\\"yes\\",\\"field_message_active\\":\\"yes\\",\\"field_send_align\\":\\"left\\",\\"field_extra\\":\\"{\\\\\\"fields\\\\\\":[{\\\\\\"type\\\\\\":\\\\\\"text\\\\\\",\\\\\\"order\\\\\\":3,\\\\\\"id\\\\\\":\\\\\\"ex3\\\\\\",\\\\\\"value\\\\\\":\\\\\\"Phone Number\\\\\\"}]}\\",\\"field_order\\":\\"{\\\\\\"field_name_label\\\\\\":0,\\\\\\"field_email_label\\\\\\":1,\\\\\\"field_subject_label\\\\\\":2,\\\\\\"field_message_label\\\\\\":4}\\",\\"field_optin_label\\":\\"Subscribe to my newsletter.\\",\\"field_optin_active\\":false,\\"provider\\":\\"mailchimp\\",\\"field_sendcopy_active\\":false,\\"field_captcha_active\\":false,\\"field_message_placeholder\\":\\"Write a Message\\",\\"field_email_placeholder\\":\\"Type e-mail address\\",\\"field_name_placeholder\\":\\"Enter Name\\",\\"include_name_mail\\":false,\\"contact_sent_from\\":\\"enable\\",\\"post_author\\":false,\\"user_role\\":\\"admin\\",\\"send_to_admins\\":\\"true\\",\\"layout_contact\\":\\"style1\\",\\"checkbox_r_c_sd_apply_all\\":\\"1\\",\\"r_c_sd_opp_left\\":false,\\"r_c_sd_opp_top\\":false,\\"r_c_sd_top\\":\\"0\\",\\"p_sd_right\\":\\"34\\",\\"p_sd_left\\":\\"34\\",\\"p_sd_opp_left\\":\\"1\\",\\"p_sd_bottom\\":\\"19\\",\\"p_sd_opp_bottom\\":\\"1\\",\\"p_sd_top\\":\\"19\\",\\"background_color_send_h\\":\\"#8d5822\\",\\"background_color_send\\":\\"#000000\\",\\"checkbox_in_r_c_apply_all\\":\\"1\\",\\"in_r_c_opp_left\\":false,\\"in_r_c_opp_top\\":false,\\"in_r_c_top\\":\\"0\\",\\"border_inputs-type\\":\\"left\\",\\"font_color_send\\":\\"#ffffff\\"}}],\\"styling\\":{\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"10\\"}}],\\"styling\\":{\\"border_inner-type\\":\\"top\\",\\"checkbox_padding_inner_apply_all\\":\\"1\\",\\"padding_inner_opp_left\\":false,\\"padding_inner_opp_bottom\\":false,\\"background_position_inner\\":\\"0,0\\",\\"background_attachment_inner\\":\\"scroll\\",\\"background_repeat_inner\\":\\"repeat-none\\",\\"background_image_inner\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-salon\\\\/files\\\\/2021\\\\/04\\\\/circle-bg.png\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"8\\"}},{\\"element_id\\":\\"2m8u176\\",\\"cols\\":[{\\"element_id\\":\\"igwd176\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"k4bt150\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Our Shop<\\\\/h2>\\\\n<p>High quality hair and skin care products<\\\\/p>\\",\\"padding_top\\":\\"20\\",\\"margin_bottom\\":\\"72\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\",\\"margin_right_unit\\":\\"%\\",\\"margin_left_unit\\":\\"%\\",\\"margin_right\\":\\"20\\",\\"margin_left\\":\\"20\\",\\"margin_opp_left\\":\\"1\\"}},{\\"mod_name\\":\\"products\\",\\"element_id\\":\\"bkdb36\\",\\"mod_settings\\":{\\"post_per_page_products\\":\\"4\\",\\"hide_page_nav_products\\":\\"yes\\",\\"pause_on_hover_slider\\":\\"resume\\",\\"layout_products\\":\\"grid4\\",\\"post_type\\":\\"product\\",\\"hide_sales_badge\\":\\"no\\",\\"show_empty_rating\\":false,\\"hide_rating_products\\":\\"no\\",\\"hide_add_to_cart_products\\":\\"no\\",\\"hide_price_products\\":\\"no\\",\\"show_product_tags\\":\\"no\\",\\"show_product_categories\\":\\"no\\",\\"unlink_post_title_products\\":\\"no\\",\\"title_tag\\":\\"h3\\",\\"hide_post_title_products\\":\\"no\\",\\"unlink_feat_img_products\\":\\"no\\",\\"img_height_products\\":\\"285\\",\\"img_width_products\\":\\"265\\",\\"hide_feat_img_products\\":\\"no\\",\\"description_products\\":\\"none\\",\\"height_slider\\":\\"variable\\",\\"show_arrow_buttons_vertical\\":false,\\"show_arrow_slider\\":\\"yes\\",\\"show_nav_slider\\":\\"yes\\",\\"wrap_slider\\":\\"yes\\",\\"play_pause_control\\":\\"no\\",\\"speed_opt_slider\\":\\"normal\\",\\"scroll_opt_slider\\":\\"1\\",\\"auto_scroll_opt_slider\\":\\"1\\",\\"mob_visible_opt_slider\\":\\"1\\",\\"tab_visible_opt_slider\\":\\"1\\",\\"visible_opt_slider\\":\\"1\\",\\"effect_slider\\":\\"scroll\\",\\"layout_slider\\":\\"slider-default\\",\\"template_products\\":\\"list\\",\\"order_products\\":\\"desc\\",\\"orderby_products\\":\\"date\\",\\"hide_outofstock_products\\":\\"no\\",\\"hide_free_products\\":\\"no\\",\\"hide_child_products\\":\\"no\\",\\"product_cat_terms\\":\\"0|single\\",\\"query_type\\":\\"product_cat\\",\\"query_products\\":\\"all\\"}}]}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"8\\"}}]',
    'themify_used_global_styles' => 
    array (
      0 => 'tb_gs238614',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 165,
  'post_date' => '2021-04-26 07:52:36',
  'post_date_gmt' => '2021-04-26 07:52:36',
  'post_content' => '<!-- wp:themify-builder/canvas /--><!--themify_builder_static--><h1>Services</h1>
<h4 class=\'tb-menu-title\'>Junior Cut</h4> Hair cut by a junior stylist, included wash & dry. 
 $50+ <br/>
<h4 class=\'tb-menu-title\'>Senior Cut</h4> Hair cut by a junior stylist, included wash & dry. 
 $80+ <br/>
<h4 class=\'tb-menu-title\'>Hair Coloring</h4> Balayage, highlight, creative colors, blending. 
 $140+ <br/>
<h4 class=\'tb-menu-title\'>Hair Treatments</h4> Intense treatments to repair all hair types. 
 $100+ <br/>
<h4 class=\'tb-menu-title\'>Styling</h4> Freshen your look by our experienced stylists. 
 $50+ <br/>
<h4 class=\'tb-menu-title\'>Make-up</h4> Our beauty artists are by appointment only. 
 $50+ <br/>
<h4 class=\'tb-menu-title\'>Nail Services</h4> We cover head to toe - don\'t forget your nails. 
 $50+ <br/>
<h4 class=\'tb-menu-title\'>Men Cuts & Shaves</h4> Male hair cuts, beard shaves and trims.  
 $50+ <br/>
<h2>Spa Packages</h2>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-salon/files/2021/04/pexels-samantha-kandinsky-6470305-364x364.jpg" width="364" height="364" title="pexels-samantha-kandinsky-6470305" alt="pexels-samantha-kandinsky-6470305" srcset="https://themify.me/demo/themes/ultra-salon/files/2021/04/pexels-samantha-kandinsky-6470305.jpg 364w, https://themify.me/demo/themes/ultra-salon/files/2021/04/pexels-samantha-kandinsky-6470305-150x150.jpg 150w" sizes="(max-width: 364px) 100vw, 364px" />
<h3 class=\'tb-menu-title\'>Facial & Body Massage</h3> Full 2-hour of facial and massage relaxation. Your choice of facial cream, massage oil and music. 
 $200+ <br/>
<h3 class=\'tb-menu-title\'>Deep Tissue Facial Massage</h3> Facial treatment & massage focus specifically on the face to restore youthful tone and contour. 
 $120+ <br/>
<h3 class=\'tb-menu-title\'>Two-for-one Spa Package </h3> Bring your special person to enjoy our special 2-for-1 spa package. 
 $200+ <br/>
<h2>Hair Treatments</h2>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-salon/files/2021/04/contact-img-364x364.jpg" width="364" height="364" title="contact-img" alt="contact-img" srcset="https://themify.me/demo/themes/ultra-salon/files/2021/04/contact-img-364x364.jpg 364w, https://themify.me/demo/themes/ultra-salon/files/2021/04/contact-img-150x150.jpg 150w" sizes="(max-width: 364px) 100vw, 364px" />
<h3 class=\'tb-menu-title\'>Basic Treatment</h3> Repair your damaged hair and restore its natural definition.  
 $80+ <br/>
<h3 class=\'tb-menu-title\'>Deep Conditioning</h3> Deep conditioning treatments are essential to help repairing severe damaged hair, 
 $120+ <br/>
<h3 class=\'tb-menu-title\'>Multiple-sessions</h3> Sometimes it takes more than a session to ensure damaged hair is fully repaired. 
 $160+ <br/>
<h2>Men Services</h2>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-salon/files/2021/04/f-slide3-364x364.jpg" width="364" height="364" title="f-slide3" alt="f-slide3" srcset="https://themify.me/demo/themes/ultra-salon/files/2021/04/f-slide3-364x364.jpg 364w, https://themify.me/demo/themes/ultra-salon/files/2021/04/f-slide3-150x150.jpg 150w, https://themify.me/demo/themes/ultra-salon/files/2021/04/f-slide3.jpg 320w" sizes="(max-width: 364px) 100vw, 364px" />
<h3 class=\'tb-menu-title\'>Junior Men Cut</h3> Hair cut by a junior stylist, included wash & dry. 
 $50+ <br/>
<h3 class=\'tb-menu-title\'>Senior Men Cut</h3> Hair cut by a junior stylist, included wash & dry. 
 $75+ <br/>
<h3 class=\'tb-menu-title\'>Shaves</h3> Trim, shave, however you want to style it. 
 $40+ <br/><!--/themify_builder_static-->',
  'post_title' => 'Services',
  'post_excerpt' => '',
  'post_name' => 'services',
  'post_modified' => '2021-10-04 20:18:07',
  'post_modified_gmt' => '2021-10-04 20:18:07',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-salon/?page_id=165',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'section_scrolling_mobile' => 'on',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"yvy2155\\",\\"cols\\":[{\\"element_id\\":\\"h6lu158\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"5ezk493\\",\\"cols\\":[{\\"element_id\\":\\"myxc496\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"nk9s787\\",\\"mod_settings\\":{\\"content_text\\":\\"<h1>Services<\\\\/h1>\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\"}}]}]}]}],\\"styling\\":{\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"8\\"}},{\\"element_id\\":\\"zcqz633\\",\\"cols\\":[{\\"element_id\\":\\"wqew634\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"3vi7930\\",\\"cols\\":[{\\"element_id\\":\\"a4bn932\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"lgbp329\\",\\"mod_settings\\":{\\"title_tag\\":\\"h4\\",\\"title_service_menu\\":\\"Junior Cut\\",\\"description_service_menu\\":\\"Hair cut by a junior stylist, included wash & dry.\\",\\"price_service_menu\\":\\"$50+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border-type\\":\\"bottom\\",\\"global_styles\\":\\"tb_gs238614\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"li7v768\\",\\"mod_settings\\":{\\"title_tag\\":\\"h4\\",\\"title_service_menu\\":\\"Senior Cut\\",\\"description_service_menu\\":\\"Hair cut by a junior stylist, included wash & dry.\\",\\"price_service_menu\\":\\"$80+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border-type\\":\\"bottom\\",\\"global_styles\\":\\"tb_gs238614\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"bz2m349\\",\\"mod_settings\\":{\\"title_tag\\":\\"h4\\",\\"title_service_menu\\":\\"Hair Coloring\\",\\"description_service_menu\\":\\"Balayage, highlight, creative colors, blending.\\",\\"price_service_menu\\":\\"$140+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border-type\\":\\"bottom\\",\\"global_styles\\":\\"tb_gs238614\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"of0d79\\",\\"mod_settings\\":{\\"title_tag\\":\\"h4\\",\\"title_service_menu\\":\\"Hair Treatments\\",\\"description_service_menu\\":\\"Intense treatments to repair all hair types.\\",\\"price_service_menu\\":\\"$100+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border-type\\":\\"bottom\\",\\"global_styles\\":\\"tb_gs238614\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}}]},{\\"element_id\\":\\"d4sa146\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"9aw2815\\",\\"mod_settings\\":{\\"title_tag\\":\\"h4\\",\\"title_service_menu\\":\\"Styling\\",\\"description_service_menu\\":\\"Freshen your look by our experienced stylists.\\",\\"price_service_menu\\":\\"$50+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border-type\\":\\"bottom\\",\\"global_styles\\":\\"tb_gs238614\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"g1ze38\\",\\"mod_settings\\":{\\"title_tag\\":\\"h4\\",\\"title_service_menu\\":\\"Make-up\\",\\"description_service_menu\\":\\"Our beauty artists are by appointment only.\\",\\"price_service_menu\\":\\"$50+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border-type\\":\\"bottom\\",\\"global_styles\\":\\"tb_gs238614\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"v3nw507\\",\\"mod_settings\\":{\\"title_tag\\":\\"h4\\",\\"title_service_menu\\":\\"Nail Services\\",\\"description_service_menu\\":\\"We cover head to toe - don\\\'t forget your nails.\\",\\"price_service_menu\\":\\"$50+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border-type\\":\\"bottom\\",\\"global_styles\\":\\"tb_gs238614\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"fo2s865\\",\\"mod_settings\\":{\\"title_tag\\":\\"h4\\",\\"title_service_menu\\":\\"Men Cuts & Shaves\\",\\"description_service_menu\\":\\"Male hair cuts, beard shaves and trims. \\",\\"price_service_menu\\":\\"$50+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border-type\\":\\"bottom\\",\\"global_styles\\":\\"tb_gs238614\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}}]}]}]}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":8}},{\\"element_id\\":\\"etp5566\\",\\"cols\\":[{\\"element_id\\":\\"r5qf568\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"74xs66\\",\\"cols\\":[{\\"element_id\\":\\"d4qu67\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"veby129\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Spa Packages<\\\\/h2>\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\",\\"margin_bottom\\":\\"30\\"}}]}]},{\\"element_id\\":\\"vow4568\\",\\"cols\\":[{\\"element_id\\":\\"s2cm828\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"uf15828\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_tag\\":\\"h3\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":\\"circle\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-salon\\\\/files\\\\/2021\\\\/04\\\\/pexels-samantha-kandinsky-6470305.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"height_image\\":\\"364\\",\\"width_image\\":\\"364\\",\\"animation_effect\\":\\"fadeInLeft\\"}}],\\"styling\\":{\\"text_align\\":\\"right\\",\\"padding_right_unit\\":\\"%\\",\\"padding_right\\":\\"5\\"}},{\\"element_id\\":\\"0lbu570\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"5bkq570\\",\\"mod_settings\\":{\\"title_tag\\":\\"h3\\",\\"title_service_menu\\":\\"Facial & Body Massage\\",\\"description_service_menu\\":\\"Full 2-hour of facial and massage relaxation. Your choice of facial cream, massage oil and music.\\",\\"price_service_menu\\":\\"$200+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border_bottom_width\\":\\"1\\",\\"border_bottom_color\\":\\"#e5e5e5\\",\\"border-type\\":\\"bottom\\",\\"padding_bottom\\":\\"5\\",\\"padding_top\\":\\"20\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"tljg513\\",\\"mod_settings\\":{\\"title_tag\\":\\"h3\\",\\"title_service_menu\\":\\"Deep Tissue Facial Massage\\",\\"description_service_menu\\":\\"Facial treatment & massage focus specifically on the face to restore youthful tone and contour.\\",\\"price_service_menu\\":\\"$120+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border_bottom_width\\":\\"1\\",\\"border_bottom_color\\":\\"#e5e5e5\\",\\"border-type\\":\\"bottom\\",\\"padding_bottom\\":\\"5\\",\\"padding_top\\":\\"20\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"whmf904\\",\\"mod_settings\\":{\\"title_tag\\":\\"h3\\",\\"title_service_menu\\":\\"Two-for-one Spa Package \\",\\"description_service_menu\\":\\"Bring your special person to enjoy our special 2-for-1 spa package.\\",\\"price_service_menu\\":\\"$200+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border-type\\":\\"bottom\\",\\"padding_bottom\\":\\"5\\",\\"padding_top\\":\\"20\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}}]}]}]}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"8\\"}},{\\"element_id\\":\\"g0br175\\",\\"cols\\":[{\\"element_id\\":\\"xxj8176\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"kjuf177\\",\\"cols\\":[{\\"element_id\\":\\"qlfd178\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"g19e178\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Hair Treatments<\\\\/h2>\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\",\\"margin_bottom\\":\\"30\\"}}]}]},{\\"element_id\\":\\"jry1178\\",\\"cols\\":[{\\"element_id\\":\\"hmnt969\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"d7w6969\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_tag\\":\\"h3\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":\\"circle\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-salon\\\\/files\\\\/2021\\\\/04\\\\/contact-img-364x364.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"height_image\\":\\"364\\",\\"width_image\\":\\"364\\",\\"animation_effect\\":\\"fadeInRight\\"}}],\\"styling\\":{\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"5\\",\\"breakpoint_tablet\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"5\\",\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false},\\"breakpoint_mobile\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"5\\",\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false}}},{\\"element_id\\":\\"kzxk179\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"klw0179\\",\\"mod_settings\\":{\\"title_tag\\":\\"h3\\",\\"title_service_menu\\":\\"Basic Treatment\\",\\"description_service_menu\\":\\"Repair your damaged hair and restore its natural definition. \\",\\"price_service_menu\\":\\"$80+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border_bottom_width\\":\\"1\\",\\"border_bottom_color\\":\\"#e5e5e5\\",\\"border-type\\":\\"bottom\\",\\"padding_bottom\\":\\"5\\",\\"padding_top\\":\\"20\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"efye180\\",\\"mod_settings\\":{\\"title_tag\\":\\"h3\\",\\"title_service_menu\\":\\"Deep Conditioning\\",\\"description_service_menu\\":\\"Deep conditioning treatments are essential to help repairing severe damaged hair,\\",\\"price_service_menu\\":\\"$120+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border_bottom_width\\":\\"1\\",\\"border_bottom_color\\":\\"#e5e5e5\\",\\"border-type\\":\\"bottom\\",\\"padding_bottom\\":\\"5\\",\\"padding_top\\":\\"20\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"4w5s180\\",\\"mod_settings\\":{\\"title_tag\\":\\"h3\\",\\"title_service_menu\\":\\"Multiple-sessions\\",\\"description_service_menu\\":\\"Sometimes it takes more than a session to ensure damaged hair is fully repaired.\\",\\"price_service_menu\\":\\"$160+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border-type\\":\\"bottom\\",\\"padding_bottom\\":\\"5\\",\\"padding_top\\":\\"20\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}}]}],\\"desktop_dir\\":\\"rtl\\",\\"tablet_dir\\":\\"rtl\\",\\"tablet_landscape_dir\\":\\"rtl\\"}]}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"8\\"}},{\\"element_id\\":\\"gbx3174\\",\\"cols\\":[{\\"element_id\\":\\"czlu175\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"nxcn175\\",\\"cols\\":[{\\"element_id\\":\\"ok9h175\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"qv2t176\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Men Services<\\\\/h2>\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\",\\"margin_bottom\\":\\"30\\"}}]}]},{\\"element_id\\":\\"7z5s176\\",\\"cols\\":[{\\"element_id\\":\\"9yyd844\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"dniq845\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_tag\\":\\"h3\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":\\"circle\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-salon\\\\/files\\\\/2021\\\\/04\\\\/f-slide3-364x364.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"height_image\\":\\"364\\",\\"width_image\\":\\"364\\",\\"animation_effect\\":\\"fadeInLeft\\"}}],\\"styling\\":{\\"text_align\\":\\"right\\",\\"padding_right_unit\\":\\"%\\",\\"padding_right\\":\\"5\\"}},{\\"element_id\\":\\"2a3u177\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"pv2q177\\",\\"mod_settings\\":{\\"title_tag\\":\\"h3\\",\\"title_service_menu\\":\\"Junior Men Cut\\",\\"description_service_menu\\":\\"Hair cut by a junior stylist, included wash & dry.\\",\\"price_service_menu\\":\\"$50+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border_bottom_width\\":\\"1\\",\\"border_bottom_color\\":\\"#e5e5e5\\",\\"border-type\\":\\"bottom\\",\\"padding_bottom\\":\\"5\\",\\"padding_top\\":\\"20\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"7rmy177\\",\\"mod_settings\\":{\\"title_tag\\":\\"h3\\",\\"title_service_menu\\":\\"Senior Men Cut\\",\\"description_service_menu\\":\\"Hair cut by a junior stylist, included wash & dry.\\",\\"price_service_menu\\":\\"$75+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border_bottom_width\\":\\"1\\",\\"border_bottom_color\\":\\"#e5e5e5\\",\\"border-type\\":\\"bottom\\",\\"padding_bottom\\":\\"5\\",\\"padding_top\\":\\"20\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"m6z0177\\",\\"mod_settings\\":{\\"title_tag\\":\\"h3\\",\\"title_service_menu\\":\\"Shaves\\",\\"description_service_menu\\":\\"Trim, shave, however you want to style it.\\",\\"price_service_menu\\":\\"$40+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border-type\\":\\"bottom\\",\\"padding_bottom\\":\\"5\\",\\"padding_top\\":\\"20\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}}]}]}]}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":10}}]',
    'themify_used_global_styles' => 
    array (
      0 => 'tb_gs238614',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 78,
  'post_date' => '2021-04-21 10:08:23',
  'post_date_gmt' => '2021-04-21 10:08:23',
  'post_content' => '<!--themify_builder_static--><img src="https://themify.me/demo/themes/ultra-salon/files/2021/04/f-slide1-320x320.jpg" height="320" title="f-slide1" alt="f-slide1" srcset="https://themify.me/demo/themes/ultra-salon/files/2021/04/f-slide1.jpg 320w, https://themify.me/demo/themes/ultra-salon/files/2021/04/f-slide1-150x150.jpg 150w, https://themify.me/demo/themes/ultra-salon/files/2021/04/f-slide1-364x364.jpg 364w" sizes="(max-width: 320px) 100vw, 320px" /> <img src="https://themify.me/demo/themes/ultra-salon/files/2021/04/f-slide2-320x320.jpg" height="320" title="f-slide2" alt="f-slide2" srcset="https://themify.me/demo/themes/ultra-salon/files/2021/04/f-slide2.jpg 320w, https://themify.me/demo/themes/ultra-salon/files/2021/04/f-slide2-150x150.jpg 150w" sizes="(max-width: 320px) 100vw, 320px" /> <img src="https://themify.me/demo/themes/ultra-salon/files/2021/04/f-slide3-320x320.jpg" height="320" title="f-slide3" alt="f-slide3" srcset="https://themify.me/demo/themes/ultra-salon/files/2021/04/f-slide3.jpg 320w, https://themify.me/demo/themes/ultra-salon/files/2021/04/f-slide3-150x150.jpg 150w, https://themify.me/demo/themes/ultra-salon/files/2021/04/f-slide3-364x364.jpg 364w" sizes="(max-width: 320px) 100vw, 320px" /> <img src="https://themify.me/demo/themes/ultra-salon/files/2021/04/f-slide4-320x320.jpg" height="320" title="f-slide4" alt="f-slide4" srcset="https://themify.me/demo/themes/ultra-salon/files/2021/04/f-slide4.jpg 320w, https://themify.me/demo/themes/ultra-salon/files/2021/04/f-slide4-150x150.jpg 150w" sizes="(max-width: 320px) 100vw, 320px" /> <img src="https://themify.me/demo/themes/ultra-salon/files/2021/04/f-slide5-320x320.jpg" height="320" title="f-slide5" alt="f-slide5" srcset="https://themify.me/demo/themes/ultra-salon/files/2021/04/f-slide5.jpg 320w, https://themify.me/demo/themes/ultra-salon/files/2021/04/f-slide5-150x150.jpg 150w" sizes="(max-width: 320px) 100vw, 320px" /> <img src="https://themify.me/demo/themes/ultra-salon/files/2021/04/f-slide6-320x320.jpg" height="320" title="f-slide6" alt="f-slide6" srcset="https://themify.me/demo/themes/ultra-salon/files/2021/04/f-slide6.jpg 320w, https://themify.me/demo/themes/ultra-salon/files/2021/04/f-slide6-150x150.jpg 150w" sizes="(max-width: 320px) 100vw, 320px" /><!--/themify_builder_static-->',
  'post_title' => 'Footer Layout',
  'post_excerpt' => '',
  'post_name' => 'footer-layout',
  'post_modified' => '2021-10-01 01:03:49',
  'post_modified_gmt' => '2021-10-01 01:03:49',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-salon/?post_type=tbuilder_layout_part&#038;p=78',
  'menu_order' => 0,
  'post_type' => 'tbuilder_layout_part',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"6im2661\\",\\"cols\\":[{\\"element_id\\":\\"bj4r662\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"slider\\",\\"element_id\\":\\"ga8j725\\",\\"mod_settings\\":{\\"posts_per_page_slider\\":\\"4\\",\\"display_slider\\":\\"none\\",\\"img_h_slider\\":\\"320\\",\\"horizontal\\":\\"no\\",\\"visible_opt_slider\\":\\"6\\",\\"pause_on_hover_slider\\":\\"resume\\",\\"play_pause_control\\":\\"no\\",\\"show_arrow_slider\\":\\"no\\",\\"show_nav_slider\\":\\"no\\",\\"wrap_slider\\":\\"yes\\",\\"auto_scroll_opt_slider\\":\\"5\\",\\"post_type\\":\\"post\\",\\"hide_post_date\\":\\"yes\\",\\"height_slider\\":\\"variable\\",\\"show_arrow_buttons_vertical\\":false,\\"speed_opt_slider\\":\\"normal\\",\\"scroll_opt_slider\\":\\"1\\",\\"mob_visible_opt_slider\\":\\"3\\",\\"tab_visible_opt_slider\\":\\"4\\",\\"effect_slider\\":\\"continuously\\",\\"img_fullwidth_slider\\":false,\\"layout_slider\\":\\"slider-default\\",\\"img_content_slider\\":[{\\"img_url_slider\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-salon\\\\/files\\\\/2021\\\\/04\\\\/f-slide1.jpg\\",\\"img_title_tag\\":\\"h3\\"},{\\"img_url_slider\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-salon\\\\/files\\\\/2021\\\\/04\\\\/f-slide2.jpg\\",\\"img_title_tag\\":\\"h3\\"},{\\"img_url_slider\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-salon\\\\/files\\\\/2021\\\\/04\\\\/f-slide3.jpg\\",\\"img_title_tag\\":\\"h3\\"},{\\"img_url_slider\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-salon\\\\/files\\\\/2021\\\\/04\\\\/f-slide4.jpg\\",\\"img_title_tag\\":\\"h3\\"},{\\"img_url_slider\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-salon\\\\/files\\\\/2021\\\\/04\\\\/f-slide5.jpg\\",\\"img_title_tag\\":\\"h3\\"},{\\"img_url_slider\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-salon\\\\/files\\\\/2021\\\\/04\\\\/f-slide6.jpg\\",\\"img_title_tag\\":\\"h3\\"}],\\"open_link_new_tab_slider\\":\\"no\\",\\"unlink_feat_img_slider\\":\\"no\\",\\"hide_feat_img_slider\\":\\"no\\",\\"unlink_post_title_slider\\":\\"no\\",\\"hide_post_title_slider\\":\\"no\\",\\"orderby_slider\\":\\"date\\",\\"order_slider\\":\\"desc\\",\\"blog_category_slider\\":\\"0|single\\",\\"taxonomy\\":\\"category\\",\\"layout_display_slider\\":\\"image\\",\\"margin_bottom\\":\\"0\\",\\"i_m_opp_left\\":false,\\"i_m_bottom\\":\\"0\\",\\"i_m_opp_bottom\\":false,\\"i_p_opp_left\\":false,\\"i_p_opp_bottom\\":false,\\"css_slider\\":\\"ftr-slider\\",\\"video_content_slider\\":[{\\"video_title_tag\\":\\"h3\\"}]}}]}],\\"styling\\":{\\"row_width\\":\\"fullwidth-content\\"}}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 238,
  'post_date' => '2021-09-18 07:48:50',
  'post_date_gmt' => '2021-09-18 07:48:50',
  'post_content' => '',
  'post_title' => 'Price List Menu',
  'post_excerpt' => '',
  'post_name' => 'tb_gs238614',
  'post_modified' => '2021-09-18 07:48:50',
  'post_modified_gmt' => '2021-09-18 07:48:50',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-salon/tglobal-style/price-list-menu/',
  'menu_order' => 0,
  'post_type' => 'tglobal_style',
  'meta_input' => 
  array (
    'themify_global_style_type' => 'service-menu',
    'hide_page_title' => 'yes',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"row614599e208e8b\\",\\"styling\\":[],\\"cols\\":[{\\"element_id\\":\\"col614599e208e8b\\",\\"grid_class\\":\\"col-full\\",\\"styling\\":[],\\"modules\\":[{\\"element_id\\":\\"mod614599e208e8b\\",\\"mod_name\\":\\"service-menu\\",\\"mod_settings\\":{\\"title_tag\\":\\"h4\\",\\"title_service_menu\\":\\"Female Hair Cut\\",\\"description_service_menu\\":\\"Hair cut with wash & blow dry\\",\\"price_service_menu\\":\\"$50+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"image_service_menu\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/wp-content\\\\/uploads\\\\/addon-samples\\\\/menu-pizza.png\\",\\"width_service_menu\\":100,\\"highlight_color_service_menu\\":\\"tb_default_color\\",\\"highlight_service_menu\\":\\"false\\",\\"image_zoom_icon\\":\\"false\\",\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":\\"false\\",\\"add_price_check\\":\\"false\\",\\"b_ra_opp_left\\":\\"false\\",\\"b_ra_opp_top\\":\\"false\\",\\"border_bottom_width\\":\\"1\\",\\"border_bottom_color\\":\\"#e5e5e5\\",\\"border-type\\":\\"bottom\\",\\"padding_bottom\\":\\"5\\",\\"padding_top\\":\\"20\\"}}]}]}]',
    '_wp_old_slug' => 'price-list-menu',
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 236,
  'post_date' => '2021-04-28 16:09:15',
  'post_date_gmt' => '2021-04-28 16:09:15',
  'post_content' => 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur.',
  'post_title' => 'Woman Hair Vitamin 180',
  'post_excerpt' => 'Voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.',
  'post_name' => 'woman-hair-vitamin-180',
  'post_modified' => '2021-09-23 03:56:19',
  'post_modified_gmt' => '2021-09-23 03:56:19',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-salon/?post_type=product&#038;p=236',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1633073043:171',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"vbr4427\\",\\"cols\\":[{\\"element_id\\":\\"ewue427\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    '_thumbnail_id' => '237',
    '_regular_price' => '15',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '15',
    '_wp_old_slug' => 'zotos-180-pro',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'hair-vitamin',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-salon/files/2021/04/zotos-180pro.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 234,
  'post_date' => '2021-04-28 16:08:18',
  'post_date_gmt' => '2021-04-28 16:08:18',
  'post_content' => 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam.',
  'post_title' => 'Hairdyer Serum',
  'post_excerpt' => 'Aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam.',
  'post_name' => 'hairdyer-serum',
  'post_modified' => '2021-09-23 03:56:43',
  'post_modified_gmt' => '2021-09-23 03:56:43',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-salon/?post_type=product&#038;p=234',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1632371846:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"dsa1207\\",\\"cols\\":[{\\"element_id\\":\\"dex3208\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    '_thumbnail_id' => '235',
    '_regular_price' => '15',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '15',
    '_wp_old_slug' => 's-factor-hairdyer',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'hair-treatment, styling-gel',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-salon/files/2021/04/spun-satin-hairdyer.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 232,
  'post_date' => '2021-04-28 16:06:47',
  'post_date_gmt' => '2021-04-28 16:06:47',
  'post_content' => 'Teleniti atque corrupti ero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum  quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga.',
  'post_title' => 'Hair Vitamin  Serum',
  'post_excerpt' => 'Yeleniti atque corrupti olores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia.',
  'post_name' => 'hair-vitamin-serum',
  'post_modified' => '2021-09-23 03:57:01',
  'post_modified_gmt' => '2021-09-23 03:57:01',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-salon/?post_type=product&#038;p=232',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1632371796:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"jwbp472\\",\\"cols\\":[{\\"element_id\\":\\"vr0p474\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    '_thumbnail_id' => '233',
    '_regular_price' => '20',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '20',
    '_wp_old_slug' => 'moss-chandler-serum',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'hair-treatment, hair-vitamin',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-salon/files/2021/04/moss-chandler.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 230,
  'post_date' => '2021-04-28 16:05:50',
  'post_date_gmt' => '2021-04-28 16:05:50',
  'post_content' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit.',
  'post_title' => 'Woman Hair Vitamin',
  'post_excerpt' => 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.',
  'post_name' => 'woman-hair-vitamin',
  'post_modified' => '2021-09-23 03:57:19',
  'post_modified_gmt' => '2021-09-23 03:57:19',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-salon/?post_type=product&#038;p=230',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1632371881:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"8e4j913\\",\\"cols\\":[{\\"element_id\\":\\"9ue4914\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    '_thumbnail_id' => '231',
    '_regular_price' => '25',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '25',
    '_wp_old_slug' => 'clinique-hair-vitamin',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'hair-vitamin',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-salon/files/2021/04/clinique-hair-gel.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 228,
  'post_date' => '2021-04-28 16:04:45',
  'post_date_gmt' => '2021-04-28 16:04:45',
  'post_content' => ' Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur.',
  'post_title' => 'Woman Organic Serum',
  'post_excerpt' => 'Voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam.',
  'post_name' => 'woman-organic-serum',
  'post_modified' => '2021-09-23 03:57:36',
  'post_modified_gmt' => '2021-09-23 03:57:36',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-salon/?post_type=product&#038;p=228',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1632371810:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"45y5498\\",\\"cols\\":[{\\"element_id\\":\\"w4s3499\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    '_thumbnail_id' => '229',
    '_regular_price' => '15',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '15',
    '_wp_old_slug' => 'avalon-organic',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'hair-treatment, hair-vitamin',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-salon/files/2021/04/avalon-organics.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 226,
  'post_date' => '2021-04-28 16:03:21',
  'post_date_gmt' => '2021-04-28 16:03:21',
  'post_content' => 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur.',
  'post_title' => 'Hair Treatment Deluxe',
  'post_excerpt' => 'Voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est.',
  'post_name' => 'hair-treatment-deluxe',
  'post_modified' => '2021-09-23 03:57:53',
  'post_modified_gmt' => '2021-09-23 03:57:53',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-salon/?post_type=product&#038;p=226',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1632371611:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"zzo8629\\",\\"cols\\":[{\\"element_id\\":\\"8g0u630\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    '_thumbnail_id' => '227',
    '_regular_price' => '18',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '18',
    '_wp_old_slug' => 'argan-deluxe',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'hair-treatment, hair-vitamin',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-salon/files/2021/04/argan-deluxe.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 224,
  'post_date' => '2021-04-28 16:02:07',
  'post_date_gmt' => '2021-04-28 16:02:07',
  'post_content' => 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur.',
  'post_title' => 'Woman Treatment Shampoo',
  'post_excerpt' => 'Voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est qui dolorem ipsum quia dolor sit amet consectetur adipisci velit.',
  'post_name' => 'woman-treatment-shampoo',
  'post_modified' => '2021-09-23 03:58:22',
  'post_modified_gmt' => '2021-09-23 03:58:22',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-salon/?post_type=product&#038;p=224',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1632371491:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"4ahl809\\",\\"cols\\":[{\\"element_id\\":\\"ly8m810\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    '_thumbnail_id' => '225',
    '_regular_price' => '15',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '15',
    '_wp_old_slug' => 'capelli-shampoo',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'hair-treatment, hair-vitamin',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-salon/files/2021/04/capelli-shampoo.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 222,
  'post_date' => '2021-04-28 16:00:42',
  'post_date_gmt' => '2021-04-28 16:00:42',
  'post_content' => 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur.',
  'post_title' => 'Blacksheed Shampoo',
  'post_excerpt' => 'Voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.',
  'post_name' => 'blacksheed-shampoo',
  'post_modified' => '2021-09-23 03:59:54',
  'post_modified_gmt' => '2021-09-23 03:59:54',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-salon/?post_type=product&#038;p=222',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1633073658:171',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"rgem731\\",\\"cols\\":[{\\"element_id\\":\\"mxyw732\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    '_thumbnail_id' => '223',
    '_regular_price' => '14',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '14',
    '_wp_old_slug' => 'appeless-blacksheed-shampoo',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'hair-treatment, hair-vitamin',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-salon/files/2021/04/apple-sheed.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 220,
  'post_date' => '2021-04-28 15:58:18',
  'post_date_gmt' => '2021-04-28 15:58:18',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
  'post_title' => 'Men Hair Vitamin',
  'post_excerpt' => 'Eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.',
  'post_name' => 'men-hair-vitamin',
  'post_modified' => '2021-09-23 04:00:30',
  'post_modified_gmt' => '2021-09-23 04:00:30',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-salon/?post_type=product&#038;p=220',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1632371280:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"f0cl449\\",\\"cols\\":[{\\"element_id\\":\\"wwe4451\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    '_thumbnail_id' => '221',
    '_regular_price' => '15',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '15',
    '_wp_old_slug' => 'dove-men-care',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'hair-treatment, hair-vitamin',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-salon/files/2021/04/dove-men-care.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 218,
  'post_date' => '2021-04-28 15:56:19',
  'post_date_gmt' => '2021-04-28 15:56:19',
  'post_content' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus.',
  'post_title' => 'Treatment Shampoo',
  'post_excerpt' => 'Magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur.',
  'post_name' => 'treatment-shampoo',
  'post_modified' => '2021-09-23 04:00:58',
  'post_modified_gmt' => '2021-09-23 04:00:58',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-salon/?post_type=product&#038;p=218',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1632371163:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"uuqj392\\",\\"cols\\":[{\\"element_id\\":\\"dcgn393\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    '_thumbnail_id' => '219',
    '_regular_price' => '15',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '15',
    '_wp_old_slug' => 'garnier-watze-shampoo',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'hair-treatment, hair-vitamin',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-salon/files/2021/04/garniaer-watze.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 216,
  'post_date' => '2021-04-28 15:52:06',
  'post_date_gmt' => '2021-04-28 15:52:06',
  'post_content' => 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus.',
  'post_title' => 'Beard Oil',
  'post_excerpt' => 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.',
  'post_name' => 'beard-oil',
  'post_modified' => '2021-09-23 04:01:06',
  'post_modified_gmt' => '2021-09-23 04:01:06',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-salon/?post_type=product&#038;p=216',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1632371093:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"tawu617\\",\\"cols\\":[{\\"element_id\\":\\"7s5i620\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    '_thumbnail_id' => '217',
    '_regular_price' => '20',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '20',
    '_wp_old_slug' => 'lambert-beard-oil',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'beard-oil',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-salon/files/2021/04/lambert-beard-oil.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 214,
  'post_date' => '2021-04-28 15:51:03',
  'post_date_gmt' => '2021-04-28 15:51:03',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
  'post_title' => 'Gelatine Hair Styling',
  'post_excerpt' => 'Eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.',
  'post_name' => 'gelatine-hair-styling',
  'post_modified' => '2021-04-28 15:51:03',
  'post_modified_gmt' => '2021-04-28 15:51:03',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-salon/?post_type=product&#038;p=214',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1632371032:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"7x08912\\",\\"cols\\":[{\\"element_id\\":\\"qseu913\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    '_thumbnail_id' => '215',
    '_regular_price' => '14',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '14',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'styling-gel',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-salon/files/2021/04/gelatin-hair-spray.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 212,
  'post_date' => '2021-04-28 15:48:19',
  'post_date_gmt' => '2021-04-28 15:48:19',
  'post_content' => ' Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid.',
  'post_title' => 'Honey Shampoo',
  'post_excerpt' => 'Totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.',
  'post_name' => 'honey-shampoo',
  'post_modified' => '2021-09-23 04:01:21',
  'post_modified_gmt' => '2021-09-23 04:01:21',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-salon/?post_type=product&#038;p=212',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1632370892:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"5xq7769\\",\\"cols\\":[{\\"element_id\\":\\"ia2y770\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    '_thumbnail_id' => '213',
    '_regular_price' => '16',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '16',
    '_wp_old_slug' => 'garnier-honey-shampoo',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'hair-treatment',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-salon/files/2021/04/garnier-honey-shampoo.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 210,
  'post_date' => '2021-04-28 15:41:41',
  'post_date_gmt' => '2021-04-28 15:41:41',
  'post_content' => 'Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.',
  'post_title' => 'Woman Hair Perfume',
  'post_excerpt' => 'Nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam.',
  'post_name' => 'woman-hair-perfume',
  'post_modified' => '2021-09-23 04:01:33',
  'post_modified_gmt' => '2021-09-23 04:01:33',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-salon/?post_type=product&#038;p=210',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1632370845:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"k5jo969\\",\\"cols\\":[{\\"element_id\\":\\"7d7y971\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    '_thumbnail_id' => '211',
    '_regular_price' => '20',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '20',
    '_wp_old_slug' => 'mor-hair-perfume',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'hair-treatment',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-salon/files/2021/04/Mor-hair-perfume.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 208,
  'post_date' => '2021-04-28 15:39:52',
  'post_date_gmt' => '2021-04-28 15:39:52',
  'post_content' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid.',
  'post_title' => 'Men Styling Gel',
  'post_excerpt' => 'Totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.',
  'post_name' => 'men-styling-gel',
  'post_modified' => '2021-09-23 04:01:45',
  'post_modified_gmt' => '2021-09-23 04:01:45',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-salon/?post_type=product&#038;p=208',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1632370722:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"ikao231\\",\\"cols\\":[{\\"element_id\\":\\"h7p3232\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    '_thumbnail_id' => '209',
    '_regular_price' => '10',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '10',
    '_wp_old_slug' => 'rausch-styling-gel',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'styling-gel',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-salon/files/2021/04/rausch-styling-gel.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 206,
  'post_date' => '2021-04-28 15:35:15',
  'post_date_gmt' => '2021-04-28 15:35:15',
  'post_content' => 'Deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum. Excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum.',
  'post_title' => 'Damage Hair Shampoo',
  'post_excerpt' => 'Vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias.',
  'post_name' => 'damage-hair-shampoo',
  'post_modified' => '2021-09-23 04:01:57',
  'post_modified_gmt' => '2021-09-23 04:01:57',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-salon/?post_type=product&#038;p=206',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1632370661:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"pkb8585\\",\\"cols\\":[{\\"element_id\\":\\"nhf8585\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    '_thumbnail_id' => '207',
    '_regular_price' => '14',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '14',
    '_wp_old_slug' => 'pantene-damage-hair',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'hair-treatment',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-salon/files/2021/04/pantene-damage-hair.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 204,
  'post_date' => '2021-04-28 15:34:08',
  'post_date_gmt' => '2021-04-28 15:34:08',
  'post_content' => 'Molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae.Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus.',
  'post_title' => 'Woman Hair Serum',
  'post_excerpt' => 'Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo.',
  'post_name' => 'woman-hair-serum',
  'post_modified' => '2021-09-23 04:02:08',
  'post_modified_gmt' => '2021-09-23 04:02:08',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-salon/?post_type=product&#038;p=204',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1632370503:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"527x461\\",\\"cols\\":[{\\"element_id\\":\\"4daw461\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    '_thumbnail_id' => '205',
    '_regular_price' => '15',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '15',
    '_wp_old_slug' => 'perfect-hair-serum',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'hair-vitamin',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-salon/files/2021/04/perfect-hair-serum.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 202,
  'post_date' => '2021-04-28 15:32:56',
  'post_date_gmt' => '2021-04-28 15:32:56',
  'post_content' => 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur.',
  'post_title' => 'Soft Styling Gel',
  'post_excerpt' => 'Ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit sed quia.',
  'post_name' => 'soft-styling-gel',
  'post_modified' => '2021-09-23 04:04:56',
  'post_modified_gmt' => '2021-09-23 04:04:56',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-salon/?post_type=product&#038;p=202',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1632370345:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"mmt174\\",\\"cols\\":[{\\"element_id\\":\\"oqxe74\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    '_thumbnail_id' => '203',
    '_regular_price' => '14',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '14',
    '_wp_old_slug' => 'softsheen-carson-styling-gel',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'styling-gel',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-salon/files/2021/04/styling-gel.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 200,
  'post_date' => '2021-04-28 15:25:54',
  'post_date_gmt' => '2021-04-28 15:25:54',
  'post_content' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus.',
  'post_title' => 'Rebonding Serum',
  'post_excerpt' => 'Magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur.',
  'post_name' => 'rebonding-serum',
  'post_modified' => '2021-09-23 04:05:09',
  'post_modified_gmt' => '2021-09-23 04:05:09',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-salon/?post_type=product&#038;p=200',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1632371242:172',
    '_edit_last' => '172',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    '_thumbnail_id' => '201',
    '_regular_price' => '25',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '25',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"ubsd153\\",\\"cols\\":[{\\"element_id\\":\\"taez154\\",\\"grid_class\\":\\"col-full\\"}]}]',
    '_wp_old_slug' => 'makarizo-rebonding',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'hair-treatment',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-salon/files/2021/04/makarizo-rebonding.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 198,
  'post_date' => '2021-04-28 15:24:58',
  'post_date_gmt' => '2021-04-28 15:24:58',
  'post_content' => 'Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.',
  'post_title' => 'Men Hair Vitamin',
  'post_excerpt' => 'Nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur.',
  'post_name' => 'men-hair-vitamin-2',
  'post_modified' => '2021-09-23 04:05:22',
  'post_modified_gmt' => '2021-09-23 04:05:22',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-salon/?post_type=product&#038;p=198',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1632370015:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"7p40634\\",\\"cols\\":[{\\"element_id\\":\\"x1hf635\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    '_thumbnail_id' => '199',
    '_regular_price' => '15',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '15',
    '_wp_old_slug' => 'kevin-murphy-hair-vitamin',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'hair-treatment, hair-vitamin',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-salon/files/2021/04/kevin-murphy.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 144,
  'post_date' => '2021-10-01 01:04:30',
  'post_date_gmt' => '2021-04-26 05:17:39',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '144',
  'post_modified' => '2021-10-01 01:04:30',
  'post_modified_gmt' => '2021-10-01 01:04:30',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-salon/?p=144',
  'menu_order' => 1,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '7',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 256,
  'post_date' => '2021-10-01 01:04:30',
  'post_date_gmt' => '2021-09-18 14:14:46',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '256',
  'post_modified' => '2021-10-01 01:04:30',
  'post_modified_gmt' => '2021-10-01 01:04:30',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-salon/?p=256',
  'menu_order' => 2,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => 'shop',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 145,
  'post_date' => '2021-10-01 01:04:30',
  'post_date_gmt' => '2021-04-26 05:17:39',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '145',
  'post_modified' => '2021-10-01 01:04:30',
  'post_modified_gmt' => '2021-10-01 01:04:30',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-salon/?p=145',
  'menu_order' => 3,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '76',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 174,
  'post_date' => '2021-10-01 01:04:30',
  'post_date_gmt' => '2021-04-26 09:31:14',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '174',
  'post_modified' => '2021-10-01 01:04:30',
  'post_modified_gmt' => '2021-10-01 01:04:30',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-salon/?p=174',
  'menu_order' => 4,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '165',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 146,
  'post_date' => '2021-10-01 01:04:30',
  'post_date_gmt' => '2021-04-26 05:17:39',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '146',
  'post_modified' => '2021-10-01 01:04:30',
  'post_modified_gmt' => '2021-10-01 01:04:30',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-salon/?p=146',
  'menu_order' => 5,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '114',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$widgets = get_option( "widget_search" );
$widgets[1002] = array (
  'title' => '',
);
update_option( "widget_search", $widgets );

$widgets = get_option( "widget_recent-posts" );
$widgets[1003] = array (
  'title' => '',
  'number' => 5,
);
update_option( "widget_recent-posts", $widgets );

$widgets = get_option( "widget_recent-comments" );
$widgets[1004] = array (
  'title' => '',
  'number' => 5,
);
update_option( "widget_recent-comments", $widgets );

$widgets = get_option( "widget_archives" );
$widgets[1005] = array (
  'title' => '',
  'count' => 0,
  'dropdown' => 0,
);
update_option( "widget_archives", $widgets );

$widgets = get_option( "widget_categories" );
$widgets[1006] = array (
  'title' => '',
  'count' => 0,
  'hierarchical' => 0,
  'dropdown' => 0,
);
update_option( "widget_categories", $widgets );

$widgets = get_option( "widget_meta" );
$widgets[1007] = array (
  'title' => '',
);
update_option( "widget_meta", $widgets );



$sidebars_widgets = array (
  'sidebar-main' => 
  array (
    0 => 'search-1002',
    1 => 'recent-posts-1003',
    2 => 'recent-comments-1004',
  ),
  'sidebar-alt' => 
  array (
    0 => 'archives-1005',
    1 => 'categories-1006',
    2 => 'meta-1007',
  ),
); 
update_option( "sidebars_widgets", $sidebars_widgets );

$homepage = get_posts( array( 'name' => 'home', 'post_type' => 'page' ) );
			if( is_array( $homepage ) && ! empty( $homepage ) ) {
				update_option( 'show_on_front', 'page' );
				update_option( 'page_on_front', $homepage[0]->ID );
			}
			$themify_data = array (
  'setting-search_post_type' => 'all',
  'setting-webfonts_list' => 'recommended',
  'setting-customizer_responsive_design_tablet_landscape' => '1024',
  'setting-customizer_responsive_design_tablet' => '768',
  'setting-customizer_responsive_design_mobile' => '680',
  'setting-mobile_menu_trigger_point' => '900',
  'setting-header_design' => 'header-horizontal',
  'setting-exclude_search_form' => 'on',
  'setting_search_form' => 'live_search',
  'setting-header_widgets' => 'headerwidget-3col',
  'setting-footer_design' => 'footer-horizontal-left',
  'setting-use_float_back' => 'on',
  'setting-footer_widgets' => 'footerwidget-3col',
  'setting-mega_menu_posts' => '5',
  'setting-mega_menu_image_width' => '180',
  'setting-mega_menu_image_height' => '120',
  'setting-mega_menu_post_count' => 'off',
  'setting-color_animation_speed' => '5',
  'setting-relationship_taxonomy' => 'category',
  'setting-relationship_taxonomy_entries' => '3',
  'setting-relationship_taxonomy_display_content' => 'none',
  'setting-single_slider_autoplay' => 'off',
  'setting-single_slider_speed' => 'normal',
  'setting-single_slider_effect' => 'slide',
  'setting-single_slider_height' => 'auto',
  'setting-more_posts' => 'infinite',
  'setting-entries_nav' => 'numbered',
  'setting-gallery_lightbox' => 'lightbox',
  'setting-lazy-blur' => '25',
  'setting-cache-live' => '10080',
  'setting-webp-quality' => '5',
  'setting-default_layout' => 'sidebar1',
  'setting-default_post_layout' => 'list-post',
  'setting-post_filter' => 'no',
  'setting-disable_masonry' => 'yes',
  'setting-post_gutter' => 'gutter',
  'setting-default_layout_display' => 'content',
  'setting-default_more_text' => 'More',
  'setting-index_orderby' => 'date',
  'setting-index_order' => 'DESC',
  'setting-default_media_position' => 'above',
  'setting-image_post_feature_size' => 'blank',
  'setting-default_page_post_layout' => 'sidebar1',
  'setting-default_page_post_layout_type' => 'classic',
  'setting-default_page_single_media_position' => 'above',
  'setting-image_post_single_feature_size' => 'blank',
  'setting-search-result_layout_display' => 'excerpt',
  'setting-search-result_media_position' => 'above',
  'setting-default_page_layout' => 'sidebar1',
  'setting-default_portfolio_index_layout' => 'sidebar-none',
  'setting-default_portfolio_index_post_layout' => 'grid3',
  'setting-portfolio_post_filter' => 'yes',
  'setting-portfolio_disable_masonry' => 'yes',
  'setting-portfolio_gutter' => 'gutter',
  'setting-default_portfolio_index_display' => 'none',
  'setting-default_portfolio_single_layout' => 'sidebar-none',
  'setting-default_portfolio_single_portfolio_layout_type' => 'fullwidth',
  'themify_portfolio_slug' => 'project',
  'themify_portfolio_category_slug' => 'portfolio-category',
  'setting-shop_layout' => 'sidebar-none',
  'setting-shop_archive_layout' => 'sidebar-none',
  'setting-products_layout' => 'grid4',
  'setting-product_disable_masonry' => 'yes',
  'setting-product_hover_image' => 'on',
  'setting-product_shop_image_size' => 'woocommerce',
  'setting-single_product_layout' => 'sidebar-none',
  'setting-product_single_image_size' => 'woocommerce',
  'setting-related_products_limit' => '3',
  'setting-product_description_type' => 'long',
  'setting-cart_show_seconds' => 'off',
  'setting-img_php_base_size' => 'large',
  'setting-global_feature_size' => 'blank',
  'setting-link_icon_type' => 'font-icon',
  'setting-link_type_themify-link-0' => 'image-icon',
  'setting-link_title_themify-link-0' => 'Twitter',
  'setting-link_img_themify-link-0' => 'https://themify.me/demo/themes/ultra-salon/wp-content/themes/themify-ultra/themify/img/social/twitter.png',
  'setting-link_type_themify-link-1' => 'image-icon',
  'setting-link_title_themify-link-1' => 'Facebook',
  'setting-link_img_themify-link-1' => 'https://themify.me/demo/themes/ultra-salon/wp-content/themes/themify-ultra/themify/img/social/facebook.png',
  'setting-link_type_themify-link-2' => 'image-icon',
  'setting-link_title_themify-link-2' => 'YouTube',
  'setting-link_img_themify-link-2' => 'https://themify.me/demo/themes/ultra-salon/wp-content/themes/themify-ultra/themify/img/social/youtube.png',
  'setting-link_type_themify-link-3' => 'image-icon',
  'setting-link_title_themify-link-3' => 'Pinterest',
  'setting-link_img_themify-link-3' => 'https://themify.me/demo/themes/ultra-salon/wp-content/themes/themify-ultra/themify/img/social/pinterest.png',
  'setting-link_type_themify-link-4' => 'font-icon',
  'setting-link_title_themify-link-4' => 'Twitter',
  'setting-link_ficon_themify-link-4' => 'fa-twitter',
  'setting-link_type_themify-link-5' => 'font-icon',
  'setting-link_title_themify-link-5' => 'Facebook',
  'setting-link_ficon_themify-link-5' => 'fa-facebook',
  'setting-link_type_themify-link-6' => 'font-icon',
  'setting-link_title_themify-link-6' => 'YouTube',
  'setting-link_ficon_themify-link-6' => 'fa-youtube',
  'setting-link_type_themify-link-7' => 'font-icon',
  'setting-link_title_themify-link-7' => 'Pinterest',
  'setting-link_ficon_themify-link-7' => 'fa-pinterest',
  'setting-link_field_ids' => '{"themify-link-0":"themify-link-0","themify-link-1":"themify-link-1","themify-link-2":"themify-link-2","themify-link-3":"themify-link-3","themify-link-4":"themify-link-4","themify-link-5":"themify-link-5","themify-link-6":"themify-link-6","themify-link-7":"themify-link-7"}',
  'setting-link_field_hash' => '8',
  'setting-page_builder_is_active' => 'enable',
  'setting-page_builder_gallery_lightbox' => 'enable',
  'setting-page_builder_animation_appearance' => 'none',
  'setting-page_builder_animation_parallax_bg' => 'none',
  'setting-page_builder_animation_scroll_effect' => 'none',
  'setting-page_builder_animation_sticky_scroll' => 'none',
  'setting-hooks-1-location' => 'themify_layout_after',
  'setting-hooks-1-code' => '[themify_layout_part id="78"]',
  'setting-hooks_field_ids' => '[1]',
  'skin' => 'salon',
  'import_images' => 'on',
);
themify_set_data( $themify_data );
$theme = get_option( 'stylesheet' );
$theme_mods = array (
  0 => false,
  'custom_css_post_id' => -1,
);
update_option( "theme_mods_{$theme}", $theme_mods );
$menu_locations = array();
$menu = get_terms( "nav_menu", array( "slug" => "main-navigation" ) );
if( is_array( $menu ) && ! empty( $menu ) ) $menu_locations["main-nav"] = $menu[0]->term_id;
set_theme_mod( "nav_menu_locations", $menu_locations );



}
